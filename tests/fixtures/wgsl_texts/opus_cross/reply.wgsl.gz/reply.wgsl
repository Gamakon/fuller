// grid 16 16 4 4
struct Cfg { d: u32, m: u32, r_rows: u32, r_off: u32, };
@group(0) @binding(0) var<storage, read> phi: array<f32>;
@group(0) @binding(1) var<storage, read_write> h: array<f32>;
@group(0) @binding(2) var<uniform> cfg: Cfg;

var<workgroup> sA: array<f32, 1024>;
var<workgroup> sB: array<f32, 1024>;

@compute @workgroup_size(16, 16, 1)
fn main(@builtin(workgroup_id) wg: vec3<u32>, @builtin(local_invocation_id) lid3: vec3<u32>) {
    let tx = lid3.x;
    let ty = lid3.y;
    let lid = ty * 16u + tx;
    let d = cfg.d;
    let m = cfg.m;
    let col0 = wg.x * 64u;
    let row0 = wg.y * 64u;

    var e0: array<f32, 16>;
    var e1: array<f32, 16>;
    for (var i = 0u; i < 16u; i = i + 1u) {
        e0[i] = 0.0;
        e1[i] = 0.0;
    }

    var t0: u32 = 0u;
    loop {
        if (t0 >= m) { break; }
        for (var k = 0u; k < 4u; k = k + 1u) {
            let e = lid + 256u * k;
            let item = e >> 6u;
            let cc = e & 63u;
            let t = t0 + item;
            var va: f32 = 0.0;
            var vb: f32 = 0.0;
            if (t < m) {
                let base = t * d;
                let gc = col0 + cc;
                if (gc < d) { vb = phi[base + gc]; }
                let lr = row0 + cc;
                let gr = cfg.r_off + lr;
                if (lr < cfg.r_rows && gr < d) { va = phi[base + gr]; }
            }
            sA[e] = va;
            sB[e] = vb;
        }
        workgroupBarrier();
        for (var k = 0u; k < 16u; k = k + 2u) {
            let o = k * 64u;
            let p = o + 64u;

            let a0 = sA[o + ty];
            let a1 = sA[o + ty + 16u];
            let a2 = sA[o + ty + 32u];
            let a3 = sA[o + ty + 48u];
            let b0 = sB[o + tx];
            let b1 = sB[o + tx + 16u];
            let b2 = sB[o + tx + 32u];
            let b3 = sB[o + tx + 48u];

            let c0 = sA[p + ty];
            let c1 = sA[p + ty + 16u];
            let c2 = sA[p + ty + 32u];
            let c3 = sA[p + ty + 48u];
            let q0 = sB[p + tx];
            let q1 = sB[p + tx + 16u];
            let q2 = sB[p + tx + 32u];
            let q3 = sB[p + tx + 48u];

            e0[0] = e0[0] + a0 * b0;
            e0[1] = e0[1] + a0 * b1;
            e0[2] = e0[2] + a0 * b2;
            e0[3] = e0[3] + a0 * b3;
            e0[4] = e0[4] + a1 * b0;
            e0[5] = e0[5] + a1 * b1;
            e0[6] = e0[6] + a1 * b2;
            e0[7] = e0[7] + a1 * b3;
            e0[8] = e0[8] + a2 * b0;
            e0[9] = e0[9] + a2 * b1;
            e0[10] = e0[10] + a2 * b2;
            e0[11] = e0[11] + a2 * b3;
            e0[12] = e0[12] + a3 * b0;
            e0[13] = e0[13] + a3 * b1;
            e0[14] = e0[14] + a3 * b2;
            e0[15] = e0[15] + a3 * b3;

            e1[0] = e1[0] + c0 * q0;
            e1[1] = e1[1] + c0 * q1;
            e1[2] = e1[2] + c0 * q2;
            e1[3] = e1[3] + c0 * q3;
            e1[4] = e1[4] + c1 * q0;
            e1[5] = e1[5] + c1 * q1;
            e1[6] = e1[6] + c1 * q2;
            e1[7] = e1[7] + c1 * q3;
            e1[8] = e1[8] + c2 * q0;
            e1[9] = e1[9] + c2 * q1;
            e1[10] = e1[10] + c2 * q2;
            e1[11] = e1[11] + c2 * q3;
            e1[12] = e1[12] + c3 * q0;
            e1[13] = e1[13] + c3 * q1;
            e1[14] = e1[14] + c3 * q2;
            e1[15] = e1[15] + c3 * q3;
        }
        workgroupBarrier();
        t0 = t0 + 16u;
    }

    for (var i = 0u; i < 4u; i = i + 1u) {
        let lr = row0 + ty + 16u * i;
        let gr = cfg.r_off + lr;
        if (lr < cfg.r_rows && gr < d) {
            for (var j = 0u; j < 4u; j = j + 1u) {
                let c = col0 + tx + 16u * j;
                if (c < d) {
                    let idx = lr * d + c;
                    h[idx] = h[idx] + (e0[i * 4u + j] + e1[i * 4u + j]);
                }
            }
        }
    }
}
