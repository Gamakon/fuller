// passes 5
// Flat k-NN graph with beam search.
// Pass 0 stores the inverse norm of each new row.
// Passes 1 and 3 run a beam search from random entry points and write 16 forward links.
// Passes 2 and 4 add reverse links into an 8-slot ring per row, kept in the same arena.
// Search runs a beam of 64.

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const D4: u32 = 512u;
const CNT_BASE: u32 = 1048576u;

var<workgroup> wq: array<vec4<f32>, 512>;
var<workgroup> bs: array<f32, 64>;
var<workgroup> bid: array<u32, 64>;
var<workgroup> bexp: array<u32, 64>;
var<workgroup> cs: array<f32, 32>;
var<workgroup> cid: array<u32, 32>;
var<workgroup> wred: array<f32, 32>;
var<workgroup> sel: u32;

fn hash(x: u32) -> u32 {
    var v = x * 747796405u + 2891336453u;
    let w = ((v >> ((v >> 28u) + 4u)) ^ v) * 277803737u;
    return (w >> 22u) ^ w;
}

fn row_score(id: u32) -> f32 {
    let base = (id & 0x7FFFFu) * D4;
    var s = 0.0;
    for (var d = 0u; d < D4; d = d + 1u) {
        s = s + dot(keys[base + d], wq[d]);
    }
    return s * index_f32[id & 0x7FFFu];
}

fn beam(self_id: u32, L: u32, steps: u32, lim: u32, salt: u32, t: u32) {
    if (t < 32u) {
        bs[t] = NONE;
        bid[t] = PAD;
        bexp[t] = 0u;
        bs[t + 32u] = NONE;
        bid[t + 32u] = PAD;
        bexp[t + 32u] = 0u;
    }
    // entry points
    var id = hash(salt * 2654435761u + t * 40503u + 17u) % lim;
    if (id == self_id) {
        id = (id + 1u) % lim;
    }
    var sc = NONE;
    if (id != self_id) {
        sc = row_score(id);
        cs[t] = sc;
        cid[t] = id;
    } else {
        cs[t] = NONE;
        cid[t] = PAD;
    }
    workgroupBarrier();
    for (var s = 0u; s < steps + 1u; s = s + 1u) {
        if (t == 0u) {
            // insert the pending candidates
            for (var j = 0u; j < 32u; j = j + 1u) {
                let cj = cid[j];
                let sj = cs[j];
                if (cj != PAD && sj > bs[L - 1u]) {
                    var dup = false;
                    for (var i = 0u; i < 64u; i = i + 1u) {
                        if (i < L && bid[i] == cj) {
                            dup = true;
                        }
                    }
                    if (!dup) {
                        var p = L - 1u;
                        for (var k = 0u; k < 64u; k = k + 1u) {
                            if (p > 0u && bs[p - 1u] < sj) {
                                bs[p] = bs[p - 1u];
                                bid[p] = bid[p - 1u];
                                bexp[p] = bexp[p - 1u];
                                p = p - 1u;
                            }
                        }
                        bs[p] = sj;
                        bid[p] = cj;
                        bexp[p] = 0u;
                    }
                }
            }
            // select next to expand
            var pick = PAD;
            for (var i = 0u; i < 64u; i = i + 1u) {
                if (pick == PAD && i < L && bid[i] != PAD && bexp[i] == 0u) {
                    pick = bid[i];
                    bexp[i] = 1u;
                }
            }
            sel = pick;
        }
        workgroupBarrier();
        let e = sel;
        var ns = NONE;
        var nid = PAD;
        if (e != PAD && t < 24u) {
            let w = atomicLoad(&index_u32[(e & 0x7FFFu) * 24u + t]);
            if (w != 0u && (w - 1u) != self_id) {
                nid = w - 1u;
                ns = row_score(nid);
            }
        }
        cs[t] = ns;
        cid[t] = nid;
        workgroupBarrier();
    }
}

@compute @workgroup_size(32)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = cfg.arrived_begin + wid.x;
    let p = cfg.pass_index;
    if (p == 0u) {
        var s = 0.0;
        for (var i = 0u; i < 16u; i = i + 1u) {
            let v = keys[(row & 0x7FFFFu) * D4 + i * 32u + t];
            s = s + dot(v, v);
        }
        wred[t] = s;
        workgroupBarrier();
        if (t == 0u) {
            var tot = 0.0;
            for (var i = 0u; i < 32u; i = i + 1u) {
                tot = tot + wred[i];
            }
            var inv = 0.0;
            if (tot > 0.0) {
                inv = 1.0 / sqrt(tot);
            }
            index_f32[row & 0x7FFFu] = inv;
        }
    } else if (p == 1u || p == 3u) {
        for (var i = 0u; i < 16u; i = i + 1u) {
            wq[i * 32u + t] = keys[(row & 0x7FFFFu) * D4 + i * 32u + t];
        }
        workgroupBarrier();
        var lim = cfg.arrived_end;
        if (cfg.arrived_begin > 0u && p == 1u) {
            lim = cfg.arrived_begin;
        }
        beam(row, 32u, 12u, lim, row * 7u + p, t);
        workgroupBarrier();
        if (t < 16u) {
            var w = 0u;
            if (bid[t] != PAD) {
                w = bid[t] + 1u;
            }
            atomicStore(&index_u32[(row & 0x7FFFu) * 24u + t], w);
        }
    } else {
        if (t < 16u) {
            let w = atomicLoad(&index_u32[(row & 0x7FFFu) * 24u + t]);
            if (w != 0u) {
                let n = (w - 1u) & 0x7FFFu;
                var has = false;
                for (var i = 0u; i < 8u; i = i + 1u) {
                    if (atomicLoad(&index_u32[n * 24u + 16u + i]) == row + 1u) {
                        has = true;
                    }
                }
                if (!has) {
                    let pos = atomicAdd(&index_u32[CNT_BASE + n], 1u) & 7u;
                    atomicStore(&index_u32[n * 24u + 16u + pos], row + 1u);
                }
            }
        }
    }
}

@compute @workgroup_size(32)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    if (q >= cfg.n_queries) {
        return;
    }
    for (var i = 0u; i < 16u; i = i + 1u) {
        wq[i * 32u + t] = queries[q * D4 + i * 32u + t];
    }
    workgroupBarrier();
    beam(PAD, 64u, 36u, cfg.arrived_end, q * 13u + 5u, t);
    workgroupBarrier();
    let a = bid[t];
    let b = bid[t + 32u];
    if (a != PAD && a < cfg.arrived_end) {
        cands[q * 64u + t] = a;
    }
    if (b != PAD && b < cfg.arrived_end) {
        cands[q * 64u + 32u + t] = b;
    }
}
