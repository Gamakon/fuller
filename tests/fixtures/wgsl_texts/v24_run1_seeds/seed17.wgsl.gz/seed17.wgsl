// passes 2
// Multi-probe LSH, one table, with data-bisector hyperplanes.
// Each of the 12 hash bits uses a hyperplane through the origin. The plane
// bisects two normalised rows drawn from the first microbatch:
// dir_h = a/|a| - b/|b|. Because the planes come from the data, the hash
// adapts to the skewed distribution. The sign of the plane is unchanged
// when a key is scaled, so the hash works on cosine.
// Pass 0: store each new row's inverse norm. At stage 1, workgroups 0..11
// also build the 12 hyperplanes.
// Pass 1: hash each new row to a 12-bit code and push it onto that bucket's
// list. The list is a linked list built with atomicExchange, plus a count.
// search: project the query, find its 6 least-confident bits (smallest
// normalised margin), and rank the 64 flip subsets of those bits by summed
// margin. Bucket members are gathered in probe order, capped at CAP rows.
// Each one is scored exactly by cosine against the query, and the top 64
// are kept.

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const C_MAX: u32 = 64u;
const D4: u32 = 512u;
const DIM: u32 = 2048u;
const H: u32 = 12u;
const NB_MASK: u32 = 4095u;
const PROBE_BITS: u32 = 6u;
const NPROBE: u32 = 64u;
const CAP: u32 = 768u;
const ROW_MASK: u32 = 0x7FFFu;
const ARENA_MASK: u32 = 0x7FFFFFu;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;

// index_u32 layout
const HEAD_OFF: u32 = 0u;
const COUNT_OFF: u32 = 4096u;
const NEXT_OFF: u32 = 8192u;
// index_f32 layout
const DIR_OFF: u32 = 0u;
const DNORM_OFF: u32 = 24576u;
const INVN_OFF: u32 = 32768u;

var<workgroup> red: array<f32, 256>;

var<workgroup> qw: array<vec4<f32>, 512>;
var<workgroup> wscore: array<f32, 768>;
var<workgroup> wrow: array<u32, 768>;
var<workgroup> pscore: array<f32, 64>;
var<workgroup> pbucket: array<u32, 64>;
var<workgroup> obucket: array<u32, 64>;
var<workgroup> ocnt: array<u32, 64>;
var<workgroup> ooff: array<u32, 64>;
var<workgroup> wcode: u32;
var<workgroup> wbits: array<u32, 6>;
var<workgroup> wmarg: array<f32, 6>;
var<workgroup> wtotal: u32;

fn hash(x: u32) -> u32 {
    let v = x * 747796405u + 2891336453u;
    let w = ((v >> ((v >> 28u) + 4u)) ^ v) * 277803737u;
    return (w >> 22u) ^ w;
}

fn dir4(h: u32, d: u32) -> vec4<f32> {
    let base = DIR_OFF + h * DIM + d * 4u;
    return vec4<f32>(
        index_f32[base & ARENA_MASK],
        index_f32[(base + 1u) & ARENA_MASK],
        index_f32[(base + 2u) & ARENA_MASK],
        index_f32[(base + 3u) & ARENA_MASK]);
}

fn wg_sum(v: f32, t: u32) -> f32 {
    red[t] = v;
    workgroupBarrier();
    for (var k = 0u; k < 8u; k = k + 1u) {
        let s = 128u >> k;
        if (t < s) {
            red[t] = red[t] + red[t + s];
        }
        workgroupBarrier();
    }
    let r = red[0];
    workgroupBarrier();
    return r;
}

@compute @workgroup_size(256)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = cfg.arrived_begin + wid.x;
    let rbase = (row & ROW_MASK) * D4;
    if (cfg.pass_index == 0u) {
        // Inverse norm of the arriving row.
        var acc = 0.0;
        for (var i = 0u; i < D4; i = i + 256u) {
            let d = i + t;
            let v = keys[rbase + d];
            acc = acc + dot(v, v);
        }
        let n2 = wg_sum(acc, t);
        if (t == 0u && row < cfg.arrived_end) {
            var inv = 0.0;
            if (n2 > 0.0) {
                inv = inverseSqrt(n2);
            }
            index_f32[(INVN_OFF + (row & ROW_MASK)) & ARENA_MASK] = inv;
        }
        // Hyperplane construction (only written at stage 1 by workgroups 0..11).
        let h = wid.x % H;
        let per = max(cfg.arrived_end - cfg.arrived_begin, 2u);
        let salt = cfg.seed_slot * 0x9E3779B9u;
        let ao = hash(h * 2u + 0x9E37u + salt) % per;
        let bo = (ao + 1u + hash(h * 2u + 1u + 0x51EDu + salt) % (per - 1u)) % per;
        let ra = ((cfg.arrived_begin + ao) & ROW_MASK) * D4;
        let rb = ((cfg.arrived_begin + bo) & ROW_MASK) * D4;
        var aa = 0.0;
        var bb = 0.0;
        for (var i = 0u; i < D4; i = i + 256u) {
            let d = i + t;
            let ka = keys[ra + d];
            let kb = keys[rb + d];
            aa = aa + dot(ka, ka);
            bb = bb + dot(kb, kb);
        }
        let na2 = wg_sum(aa, t);
        let nb2 = wg_sum(bb, t);
        var ia = 0.0;
        if (na2 > 0.0) { ia = inverseSqrt(na2); }
        var ib = 0.0;
        if (nb2 > 0.0) { ib = inverseSqrt(nb2); }
        let writer = cfg.stage == 1u && wid.x < H;
        var dd = 0.0;
        for (var i = 0u; i < D4; i = i + 256u) {
            let d = i + t;
            let dv = keys[ra + d] * ia - keys[rb + d] * ib;
            dd = dd + dot(dv, dv);
            if (writer) {
                let base = DIR_OFF + h * DIM + d * 4u;
                index_f32[base & ARENA_MASK] = dv.x;
                index_f32[(base + 1u) & ARENA_MASK] = dv.y;
                index_f32[(base + 2u) & ARENA_MASK] = dv.z;
                index_f32[(base + 3u) & ARENA_MASK] = dv.w;
            }
        }
        let dn2 = wg_sum(dd, t);
        if (writer && t == 0u) {
            index_f32[(DNORM_OFF + h) & ARENA_MASK] = sqrt(dn2);
        }
    } else {
        // Hash the row: 16 threads per bit, 32 vec4 each.
        var acc = 0.0;
        if (t < H * 16u) {
            let h = t >> 4u;
            let s = t & 15u;
            for (var j = 0u; j < 32u; j = j + 1u) {
                let d = s * 32u + j;
                acc = acc + dot(keys[rbase + d], dir4(h, d));
            }
        }
        red[t] = acc;
        workgroupBarrier();
        if (t == 0u && row < cfg.arrived_end) {
            var code = 0u;
            for (var h = 0u; h < H; h = h + 1u) {
                var p = 0.0;
                for (var k = 0u; k < 16u; k = k + 1u) {
                    p = p + red[h * 16u + k];
                }
                if (p > 0.0) {
                    code = code | (1u << h);
                }
            }
            code = code & NB_MASK;
            let old = atomicExchange(&index_u32[HEAD_OFF + code], row + 1u);
            atomicStore(&index_u32[NEXT_OFF + (row & ROW_MASK)], old);
            atomicAdd(&index_u32[COUNT_OFF + code], 1u);
        }
    }
}

@compute @workgroup_size(256)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let q = wid.x;
    let t = lid.x;
    let qbase = (q & 0xFFFFu) * D4;
    for (var i = 0u; i < D4; i = i + 256u) {
        qw[i + t] = queries[qbase + i + t];
    }
    for (var i = 0u; i < CAP; i = i + 256u) {
        let j = i + t;
        if (j < CAP) {
            wrow[j] = PAD;
            wscore[j] = NONE;
        }
    }
    workgroupBarrier();
    // Query projections, partials in wscore[0..256].
    var acc = 0.0;
    if (t < H * 16u) {
        let h = t >> 4u;
        let s = t & 15u;
        for (var j = 0u; j < 32u; j = j + 1u) {
            let d = s * 32u + j;
            acc = acc + dot(qw[d], dir4(h, d));
        }
    }
    wscore[t] = acc;
    workgroupBarrier();
    if (t == 0u) {
        var m: array<f32, 12>;
        var code = 0u;
        for (var h = 0u; h < H; h = h + 1u) {
            var p = 0.0;
            for (var k = 0u; k < 16u; k = k + 1u) {
                p = p + wscore[h * 16u + k];
            }
            if (p > 0.0) {
                code = code | (1u << h);
            }
            let dn = max(index_f32[(DNORM_OFF + h) & ARENA_MASK], 1e-20);
            m[h] = abs(p) / dn;
        }
        wcode = code & NB_MASK;
        var used = 0u;
        for (var pb = 0u; pb < PROBE_BITS; pb = pb + 1u) {
            var bi = 0u;
            var bm = 3.0e38;
            for (var h = 0u; h < H; h = h + 1u) {
                if (((used >> h) & 1u) == 0u && m[h] < bm) {
                    bm = m[h];
                    bi = h;
                }
            }
            used = used | (1u << bi);
            wbits[pb] = bi;
            wmarg[pb] = bm;
        }
    }
    workgroupBarrier();
    for (var i = 0u; i < CAP; i = i + 256u) {
        let j = i + t;
        if (j < CAP) {
            wscore[j] = NONE;
        }
    }
    if (t < NPROBE) {
        var b = wcode;
        var sc = 0.0;
        for (var pb = 0u; pb < PROBE_BITS; pb = pb + 1u) {
            if (((t >> pb) & 1u) == 1u) {
                b = b ^ (1u << wbits[pb]);
                sc = sc + wmarg[pb];
            }
        }
        pscore[t] = sc;
        pbucket[t] = b & NB_MASK;
    }
    workgroupBarrier();
    if (t < NPROBE) {
        let mine = pscore[t];
        var rank = 0u;
        for (var u = 0u; u < NPROBE; u = u + 1u) {
            let o = pscore[u];
            if (o < mine || (o == mine && u < t)) {
                rank = rank + 1u;
            }
        }
        let b = pbucket[t];
        obucket[rank & 63u] = b;
        ocnt[rank & 63u] = min(atomicLoad(&index_u32[COUNT_OFF + b]), CAP);
    }
    workgroupBarrier();
    if (t == 0u) {
        var run = 0u;
        for (var p = 0u; p < NPROBE; p = p + 1u) {
            ooff[p] = run;
            run = min(run + ocnt[p], CAP);
        }
        wtotal = run;
    }
    workgroupBarrier();
    // Gather the probes' members in probe-rank order.
    if (t < NPROBE) {
        let off = ooff[t];
        let cnt = ocnt[t];
        var node = atomicLoad(&index_u32[HEAD_OFF + obucket[t]]);
        for (var k = 0u; k < CAP; k = k + 1u) {
            if (node == 0u || k >= cnt) { break; }
            let r = node - 1u;
            let pos = off + k;
            if (pos >= CAP || r >= cfg.arrived_end) { break; }
            wrow[pos] = r;
            node = atomicLoad(&index_u32[NEXT_OFF + (r & ROW_MASK)]);
        }
    }
    workgroupBarrier();
    let tot = wtotal;
    // Exact cosine (query norm omitted: constant per query).
    for (var i = 0u; i < CAP; i = i + 256u) {
        let j = i + t;
        if (j < tot) {
            let r = wrow[j];
            if (r != PAD && r < cfg.arrived_end) {
                let kb = (r & ROW_MASK) * D4;
                var s = 0.0;
                for (var d = 0u; d < D4; d = d + 1u) {
                    s = s + dot(keys[kb + d], qw[d]);
                }
                let inv = index_f32[(INVN_OFF + (r & ROW_MASK)) & ARENA_MASK];
                var sc = NONE;
                if (inv > 0.0) {
                    sc = s * inv;
                }
                wscore[j] = sc;
            }
        }
    }
    workgroupBarrier();
    // Rank selection of the top C_MAX: unique ranks via index tie-break.
    for (var i = 0u; i < CAP; i = i + 256u) {
        let j = i + t;
        if (j < tot) {
            let r = wrow[j];
            if (r != PAD && r < cfg.arrived_end) {
                let mine = wscore[j];
                var rank = 0u;
                for (var u = 0u; u < CAP; u = u + 1u) {
                    if (u >= tot || rank >= C_MAX) { break; }
                    let o = wscore[u];
                    if (o > mine || (o == mine && u < j)) {
                        rank = rank + 1u;
                    }
                }
                if (rank < C_MAX && q < cfg.n_queries) {
                    cands[q * C_MAX + rank] = r;
                }
            }
        }
    }
}
