// passes 2

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const NC: u32 = 128u;
const CAP: u32 = 1024u;
const NPROBE: u32 = 8u;
const NORM_OFF: u32 = 262144u;
const BUCKET_OFF: u32 = 256u;

var<workgroup> srow: array<vec4<f32>, 512>;
var<workgroup> sred: array<f32, 64>;
var<workgroup> sidx: array<u32, 64>;

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = cfg.arrived_begin + wid.x;
    if (row >= cfg.arrived_end) {
        return;
    }
    let rbase = (row & 0x7FFFFu) * D4;
    if (cfg.pass_index == 0u) {
        if (cfg.stage == 1u && wid.x < NC) {
            let c = wid.x & 127u;
            var part = 0.0;
            for (var i = 0u; i < 8u; i += 1u) {
                let d = i * 64u + t;
                let v = keys[rbase + d];
                let b = (c * 2048u + d * 4u) & 0x3FFFFu;
                index_f32[b] = v.x;
                index_f32[b + 1u] = v.y;
                index_f32[b + 2u] = v.z;
                index_f32[b + 3u] = v.w;
                part += dot(v, v);
            }
            sred[t] = part;
            workgroupBarrier();
            if (t == 0u) {
                var s = 0.0;
                for (var i = 0u; i < 64u; i += 1u) {
                    s += sred[i];
                }
                var inv = 0.0;
                if (s > 0.0) {
                    inv = inverseSqrt(s);
                }
                index_f32[NORM_OFF + c] = inv;
            }
        }
        return;
    }
    // pass 1: assign to the nearest centre and append to its bucket
    for (var i = 0u; i < 8u; i += 1u) {
        let d = i * 64u + t;
        srow[d] = keys[rbase + d];
    }
    workgroupBarrier();
    var best = -3.0e38;
    var bc = 0u;
    for (var k = 0u; k < 2u; k += 1u) {
        let c = (t + k * 64u) & 127u;
        var s = 0.0;
        for (var d = 0u; d < D4; d += 1u) {
            let b = (c * 2048u + d * 4u) & 0x3FFFFu;
            let v = vec4<f32>(index_f32[b], index_f32[b + 1u], index_f32[b + 2u], index_f32[b + 3u]);
            s += dot(v, srow[d]);
        }
        let sc = s * index_f32[NORM_OFF + c];
        if (sc > best) {
            best = sc;
            bc = c;
        }
    }
    sred[t] = best;
    sidx[t] = bc;
    workgroupBarrier();
    if (t == 0u) {
        var bb = sred[0];
        var cc = sidx[0];
        for (var i = 1u; i < 64u; i += 1u) {
            if (sred[i] > bb) {
                bb = sred[i];
                cc = sidx[i];
            }
        }
        cc = cc & 127u;
        let slot = atomicAdd(&index_u32[cc], 1u);
        if (slot < CAP) {
            index_u32[BUCKET_OFF + cc * CAP + (slot & 1023u)] = row;
        }
    }
}

var<workgroup> cscore: array<f32, 128>;
var<workgroup> probe: array<u32, 8>;
var<workgroup> offs: array<u32, 8>;
var<workgroup> cnts: array<u32, 8>;
var<workgroup> wtotal: u32;
var<workgroup> cidx: array<u32, 1024>;
var<workgroup> csc: array<f32, 1024>;

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let q = wid.x;
    let t = lid.x;
    if (q >= cfg.n_queries) {
        return;
    }
    let qb = (q & 0x7FFFFu) * D4;
    for (var k = 0u; k < 2u; k += 1u) {
        let c = (t + k * 64u) & 127u;
        var s = 0.0;
        for (var d = 0u; d < D4; d += 1u) {
            let b = (c * 2048u + d * 4u) & 0x3FFFFu;
            let v = vec4<f32>(index_f32[b], index_f32[b + 1u], index_f32[b + 2u], index_f32[b + 3u]);
            s += dot(v, queries[qb + d]);
        }
        cscore[c] = s * index_f32[NORM_OFF + c];
    }
    workgroupBarrier();
    for (var k = 0u; k < 2u; k += 1u) {
        let c = t + k * 64u;
        let mine = cscore[c & 127u];
        var rank = 0u;
        for (var o = 0u; o < NC; o += 1u) {
            let v = cscore[o];
            if (v > mine || (v == mine && o < c)) {
                rank += 1u;
            }
        }
        if (rank < NPROBE) {
            probe[rank] = c & 127u;
        }
    }
    workgroupBarrier();
    if (t == 0u) {
        var acc = 0u;
        for (var p = 0u; p < NPROBE; p += 1u) {
            var n = atomicLoad(&index_u32[probe[p] & 127u]);
            n = min(n, CAP);
            n = min(n, CAP - acc);
            offs[p] = acc;
            cnts[p] = n;
            acc += n;
        }
        wtotal = acc;
    }
    workgroupBarrier();
    let total = wtotal;
    for (var j0 = 0u; j0 < CAP; j0 += 64u) {
        let j = j0 + t;
        if (j < total) {
            var bp = 0u;
            for (var p = 0u; p < NPROBE; p += 1u) {
                if (j >= offs[p] && j < offs[p] + cnts[p]) {
                    bp = p;
                }
            }
            let row = atomicLoad(&index_u32[BUCKET_OFF + (probe[bp] & 127u) * CAP + ((j - offs[bp]) & 1023u)]);
            let rb = (row & 0x7FFFFu) * D4;
            var s = 0.0;
            var kn = 0.0;
            for (var d = 0u; d < D4; d += 1u) {
                let k = keys[rb + d];
                s += dot(k, queries[qb + d]);
                kn += dot(k, k);
            }
            var sc = -3.0e38;
            if (kn > 0.0) {
                sc = s * inverseSqrt(kn);
            }
            cidx[j] = row;
            csc[j] = sc;
        }
    }
    workgroupBarrier();
    for (var j0 = 0u; j0 < CAP; j0 += 64u) {
        let j = j0 + t;
        if (j < total) {
            let mine = csc[j];
            var rank = 0u;
            for (var o = 0u; o < total; o += 1u) {
                let v = csc[o];
                if (v > mine || (v == mine && o < j)) {
                    rank += 1u;
                }
            }
            if (rank < 64u) {
                cands[q * 64u + rank] = cidx[j];
            }
        }
    }
}
