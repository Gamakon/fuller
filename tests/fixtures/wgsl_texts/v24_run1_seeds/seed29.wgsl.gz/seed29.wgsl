// passes 16
// v24 design: a learned-split tree. Pass 0 of each microbatch drops every
// arriving row down the tree into its leaf (storing its key norm). Then five
// rounds of three passes: an over-full leaf (more than LEAF_CAP members)
// estimates its principal direction by two centred power iterations over its
// members (round pass 1 also accumulates the member sum used for centring),
// then splits at the median projection, found by bisection; the left child
// keeps the parent's list slot (compacted in place, chunk by chunk), the right
// child takes a fresh slot. Search descends to its leaf, then flips the
// least-confident splits along its path for further leaves until a scan
// budget of rows is reached, scores those rows exactly, and picks the best 64
// by a shared-memory tournament.

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const DIM: u32 = 2048u;
const C_MAX: u32 = 64u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const ARENA_MASK: u32 = 0x7FFFFFu;
const ROW_MASK: u32 = 0x7FFFu;
const MAX_NODES: u32 = 1024u;
const NODE_MASK: u32 = 1023u;
const MAX_SLOTS: u32 = 512u;
const SLOT_MASK: u32 = 511u;
const LIST_CAP: u32 = 8192u;
const LIST_MASK: u32 = 8191u;
const LEAF_CAP: u32 = 160u;
const MAX_DEPTH: u32 = 40u;
const MAX_PROBES: u32 = 16u;
const BUDGET: u32 = 1536u;
// index_u32 layout
const HDR_NODES: u32 = 0u;
const HDR_SLOTS: u32 = 1u;
const LEFT_BASE: u32 = 64u;
const RIGHT_BASE: u32 = 1088u;
const SLOT_BASE: u32 = 2112u;
const CNT_BASE: u32 = 3136u;
const LIST_BASE: u32 = 8192u;
// index_f32 layout
const DIR_BASE: u32 = 0u;
const SUM_BASE: u32 = 2097152u;
const PROJ_BASE: u32 = 3145728u;
const THR_BASE: u32 = 7340032u;
const NORM_BASE: u32 = 7341056u;

var<workgroup> sh: array<f32, 2048>;
var<workgroup> shu: array<u32, 1536>;
var<workgroup> sh2: array<f32, 256>;
var<workgroup> shd: array<f32, 8>;
var<workgroup> s_pn: array<u32, 64>;
var<workgroup> s_pm: array<f32, 64>;
var<workgroup> s_misc: array<u32, 4>;

fn hash_u(x: u32) -> u32 {
    var h = x * 0x9E3779B1u;
    h = h ^ (h >> 15u);
    h = h * 0x85EBCA77u;
    h = h ^ (h >> 13u);
    h = h * 0xC2B2AE3Du;
    h = h ^ (h >> 16u);
    return h;
}

fn rnd_f(x: u32) -> f32 {
    return f32(hash_u(x) & 0xFFFFu) * (1.0 / 32768.0) - 1.0;
}

fn u_at(i: u32) -> u32 {
    return atomicLoad(&index_u32[i & ARENA_MASK]);
}

fn u_set(i: u32, v: u32) {
    atomicStore(&index_u32[i & ARENA_MASK], v);
}

fn u_add(i: u32, v: u32) -> u32 {
    return atomicAdd(&index_u32[i & ARENA_MASK], v);
}

fn f_at(i: u32) -> f32 {
    return index_f32[i & ARENA_MASK];
}

fn f_set(i: u32, v: f32) {
    index_f32[i & ARENA_MASK] = v;
}

fn wg_sum256(t: u32, v: f32) -> f32 {
    sh2[t] = v;
    workgroupBarrier();
    for (var k = 0u; k < 8u; k += 1u) {
        let st = 128u >> k;
        if (t < st) {
            sh2[t] = sh2[t] + sh2[t + st];
        }
        workgroupBarrier();
    }
    let r = sh2[0];
    workgroupBarrier();
    return r;
}

fn wg_sum128(t: u32, v: f32) -> f32 {
    sh2[t] = v;
    workgroupBarrier();
    for (var k = 0u; k < 7u; k += 1u) {
        let st = 64u >> k;
        if (t < st) {
            sh2[t] = sh2[t] + sh2[t + st];
        }
        workgroupBarrier();
    }
    let r = sh2[0];
    workgroupBarrier();
    return r;
}

fn wg_cnt256(t: u32, v: u32) -> u32 {
    shu[t] = v;
    workgroupBarrier();
    for (var k = 0u; k < 8u; k += 1u) {
        let st = 128u >> k;
        if (t < st) {
            shu[t] = shu[t] + shu[t + st];
        }
        workgroupBarrier();
    }
    let r = shu[0];
    workgroupBarrier();
    return r;
}

// Pass 0: the arriving row r descends the tree and joins its leaf's list.
fn assign_row(r: u32, t: u32) {
    let kb = (r & ROW_MASK) * D4 + t * 2u;
    let x0 = keys[kb];
    let x1 = keys[kb + 1u];
    let nrm2 = wg_sum256(t, dot(x0, x0) + dot(x1, x1));
    if (t == 0u) {
        f_set(NORM_BASE + r, sqrt(nrm2));
    }
    var node = 0u;
    for (var d = 0u; d < MAX_DEPTH; d += 1u) {
        let l = u_at(LEFT_BASE + node);
        if (l != 0u) {
            let db = DIR_BASE + node * DIM + t * 8u;
            let v0 = vec4<f32>(f_at(db), f_at(db + 1u), f_at(db + 2u), f_at(db + 3u));
            let v1 = vec4<f32>(f_at(db + 4u), f_at(db + 5u), f_at(db + 6u), f_at(db + 7u));
            let p = wg_sum256(t, dot(x0, v0) + dot(x1, v1));
            let thr = f_at(THR_BASE + node);
            let rgt = u_at(RIGHT_BASE + node);
            node = select(l, rgt, p > thr) & NODE_MASK;
        }
    }
    if (t == 0u) {
        let slot = u_at(SLOT_BASE + node) & SLOT_MASK;
        let idx = u_add(CNT_BASE + node, 1u);
        if (idx < LIST_CAP) {
            u_set(LIST_BASE + slot * LIST_CAP + idx, r);
        }
    }
}

// One centred power iteration over the members of leaf n (slot s, c members).
// Thread t owns dims 8t .. 8t+8. The first iteration starts from a hashed
// random direction and stores the member sum; later ones start from the
// stored direction and reuse the sum.
fn power_iter(n: u32, s: u32, c: u32, t: u32, first: bool) {
    let db = n * DIM + t * 8u;
    var v0 = vec4<f32>(0.0);
    var v1 = vec4<f32>(0.0);
    if (first) {
        v0 = vec4<f32>(rnd_f(db), rnd_f(db + 1u), rnd_f(db + 2u), rnd_f(db + 3u));
        v1 = vec4<f32>(rnd_f(db + 4u), rnd_f(db + 5u), rnd_f(db + 6u), rnd_f(db + 7u));
    } else {
        v0 = vec4<f32>(f_at(DIR_BASE + db), f_at(DIR_BASE + db + 1u), f_at(DIR_BASE + db + 2u), f_at(DIR_BASE + db + 3u));
        v1 = vec4<f32>(f_at(DIR_BASE + db + 4u), f_at(DIR_BASE + db + 5u), f_at(DIR_BASE + db + 6u), f_at(DIR_BASE + db + 7u));
    }
    var w0 = vec4<f32>(0.0);
    var w1 = vec4<f32>(0.0);
    var a0 = vec4<f32>(0.0);
    var a1 = vec4<f32>(0.0);
    var sump = 0.0;
    var x0: array<vec4<f32>, 8>;
    var x1: array<vec4<f32>, 8>;
    let lb = LIST_BASE + s * LIST_CAP;
    for (var b = 0u; b < c; b += 8u) {
        for (var m = 0u; m < 8u; m += 1u) {
            let i = b + m;
            var y0 = vec4<f32>(0.0);
            var y1 = vec4<f32>(0.0);
            if (i < c) {
                let row = u_at(lb + i) & ROW_MASK;
                let kb = row * D4 + t * 2u;
                y0 = keys[kb];
                y1 = keys[kb + 1u];
            }
            x0[m] = y0;
            x1[m] = y1;
            sh[m * 256u + t] = dot(y0, v0) + dot(y1, v1);
        }
        workgroupBarrier();
        {
            let mm = t >> 5u;
            let jj = t & 31u;
            var acc = 0.0;
            for (var e = 0u; e < 8u; e += 1u) {
                acc = acc + sh[mm * 256u + jj * 8u + e];
            }
            sh2[t] = acc;
        }
        workgroupBarrier();
        if (t < 8u) {
            var acc = 0.0;
            for (var e = 0u; e < 32u; e += 1u) {
                acc = acc + sh2[t * 32u + e];
            }
            shd[t] = acc;
        }
        workgroupBarrier();
        for (var m = 0u; m < 8u; m += 1u) {
            if (b + m < c) {
                let p = shd[m];
                w0 = w0 + p * x0[m];
                w1 = w1 + p * x1[m];
                a0 = a0 + x0[m];
                a1 = a1 + x1[m];
                sump = sump + p;
            }
        }
        workgroupBarrier();
    }
    let sb = SUM_BASE + s * DIM + t * 8u;
    var s0 = vec4<f32>(0.0);
    var s1 = vec4<f32>(0.0);
    if (first) {
        s0 = a0;
        s1 = a1;
        f_set(sb, a0.x);
        f_set(sb + 1u, a0.y);
        f_set(sb + 2u, a0.z);
        f_set(sb + 3u, a0.w);
        f_set(sb + 4u, a1.x);
        f_set(sb + 5u, a1.y);
        f_set(sb + 6u, a1.z);
        f_set(sb + 7u, a1.w);
    } else {
        s0 = vec4<f32>(f_at(sb), f_at(sb + 1u), f_at(sb + 2u), f_at(sb + 3u));
        s1 = vec4<f32>(f_at(sb + 4u), f_at(sb + 5u), f_at(sb + 6u), f_at(sb + 7u));
    }
    let mu = sump / f32(max(c, 1u));
    var n0 = w0 - mu * s0;
    var n1 = w1 - mu * s1;
    let nrm2 = wg_sum256(t, dot(n0, n0) + dot(n1, n1));
    if (nrm2 > 1.0e-30) {
        let inv = inverseSqrt(nrm2);
        n0 = n0 * inv;
        n1 = n1 * inv;
    } else {
        n0 = v0;
        n1 = v1;
    }
    f_set(DIR_BASE + db, n0.x);
    f_set(DIR_BASE + db + 1u, n0.y);
    f_set(DIR_BASE + db + 2u, n0.z);
    f_set(DIR_BASE + db + 3u, n0.w);
    f_set(DIR_BASE + db + 4u, n1.x);
    f_set(DIR_BASE + db + 5u, n1.y);
    f_set(DIR_BASE + db + 6u, n1.z);
    f_set(DIR_BASE + db + 7u, n1.w);
}

// Project the members of leaf n on its direction, find the median by
// bisection, and split: left child keeps slot s (compacted in place), right
// child takes a fresh slot.
fn split_node(n: u32, s: u32, c: u32, t: u32) {
    let db = DIR_BASE + n * DIM + t * 8u;
    let v0 = vec4<f32>(f_at(db), f_at(db + 1u), f_at(db + 2u), f_at(db + 3u));
    let v1 = vec4<f32>(f_at(db + 4u), f_at(db + 5u), f_at(db + 6u), f_at(db + 7u));
    let lb = LIST_BASE + s * LIST_CAP;
    let pb = PROJ_BASE + s * LIST_CAP;
    var pmin = 3.0e38;
    var pmax = -3.0e38;
    for (var b = 0u; b < c; b += 8u) {
        for (var m = 0u; m < 8u; m += 1u) {
            let i = b + m;
            var partial = 0.0;
            if (i < c) {
                let row = u_at(lb + i) & ROW_MASK;
                let kb = row * D4 + t * 2u;
                partial = dot(keys[kb], v0) + dot(keys[kb + 1u], v1);
            }
            sh[m * 256u + t] = partial;
        }
        workgroupBarrier();
        {
            let mm = t >> 5u;
            let jj = t & 31u;
            var acc = 0.0;
            for (var e = 0u; e < 8u; e += 1u) {
                acc = acc + sh[mm * 256u + jj * 8u + e];
            }
            sh2[t] = acc;
        }
        workgroupBarrier();
        if (t < 8u) {
            var acc = 0.0;
            for (var e = 0u; e < 32u; e += 1u) {
                acc = acc + sh2[t * 32u + e];
            }
            shd[t] = acc;
        }
        workgroupBarrier();
        if (t < 8u && b + t < c) {
            f_set(pb + b + t, shd[t]);
        }
        for (var m = 0u; m < 8u; m += 1u) {
            if (b + m < c) {
                let p = shd[m];
                pmin = min(pmin, p);
                pmax = max(pmax, p);
            }
        }
        workgroupBarrier();
    }
    storageBarrier();
    workgroupBarrier();
    // Median by bisection: count(p <= hi) >= c/2 is kept invariant.
    var lo = pmin;
    var hi = pmax;
    let half = c / 2u;
    for (var it = 0u; it < 24u; it += 1u) {
        let mid = 0.5 * (lo + hi);
        var cnt = 0u;
        for (var i = 0u; i < c; i += 256u) {
            let j = i + t;
            if (j < c) {
                if (f_at(pb + j) <= mid) {
                    cnt = cnt + 1u;
                }
            }
        }
        let total = wg_cnt256(t, cnt);
        if (total < half) {
            lo = mid;
        } else {
            hi = mid;
        }
    }
    let thr = hi;
    var cntl = 0u;
    for (var i = 0u; i < c; i += 256u) {
        let j = i + t;
        if (j < c) {
            if (f_at(pb + j) <= thr) {
                cntl = cntl + 1u;
            }
        }
    }
    let nleft = wg_cnt256(t, cntl);
    if (nleft == 0u || nleft == c) {
        // Degenerate: every member projects alike. Mark the leaf unsplittable.
        if (t == 0u) {
            u_set(RIGHT_BASE + n, PAD);
        }
        return;
    }
    if (t == 0u) {
        let nb = u_add(HDR_NODES, 2u);
        let sl = u_add(HDR_SLOTS, 1u) + 1u;
        let a = nb + 1u;
        let bch = nb + 2u;
        var ok = 0u;
        if (bch < MAX_NODES && sl < MAX_SLOTS) {
            ok = 1u;
        }
        s_misc[0] = a;
        s_misc[1] = bch;
        s_misc[2] = sl;
        s_misc[3] = ok;
    }
    workgroupBarrier();
    let a = s_misc[0] & NODE_MASK;
    let bch = s_misc[1] & NODE_MASK;
    let sl = s_misc[2] & SLOT_MASK;
    let ok = s_misc[3];
    workgroupBarrier();
    if (ok == 0u) {
        return;
    }
    let rb = LIST_BASE + sl * LIST_CAP;
    // In-place partition, chunk by chunk: every write lands at a position
    // already read by every thread of this workgroup.
    for (var base = 0u; base < c; base += 256u) {
        let i = base + t;
        var row = 0u;
        var p = 0.0;
        if (i < c) {
            row = u_at(lb + i);
            p = f_at(pb + i);
        }
        workgroupBarrier();
        if (i < c) {
            if (p > thr) {
                let j = u_add(CNT_BASE + bch, 1u);
                u_set(rb + (j & LIST_MASK), row);
            } else {
                let j = u_add(CNT_BASE + a, 1u);
                u_set(lb + (j & LIST_MASK), row);
            }
        }
        workgroupBarrier();
    }
    storageBarrier();
    workgroupBarrier();
    if (t == 0u) {
        u_set(SLOT_BASE + a, s);
        u_set(SLOT_BASE + bch, sl);
        f_set(THR_BASE + n, thr);
        u_set(RIGHT_BASE + n, bch);
        u_set(LEFT_BASE + n, a);
    }
}

fn process_node(n: u32, phase: u32, t: u32) {
    let ntotal = u_at(HDR_NODES) + 1u;
    if (n >= ntotal) {
        return;
    }
    if (u_at(LEFT_BASE + n) != 0u || u_at(RIGHT_BASE + n) != 0u) {
        return;
    }
    let c = min(u_at(CNT_BASE + n), LIST_CAP);
    if (c <= LEAF_CAP) {
        return;
    }
    if (u_at(HDR_SLOTS) + 1u >= MAX_SLOTS || u_at(HDR_NODES) + 3u > MAX_NODES) {
        return;
    }
    let s = u_at(SLOT_BASE + n) & SLOT_MASK;
    if (phase == 0u) {
        power_iter(n, s, c, t, true);
    } else if (phase == 1u) {
        power_iter(n, s, c, t, false);
    } else {
        split_node(n, s, c, t);
    }
}

@compute @workgroup_size(256)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let g = wid.x;
    let per = max(cfg.arrived_end - cfg.arrived_begin, 1u);
    if (cfg.pass_index == 0u) {
        let r = cfg.arrived_begin + g;
        if (r < cfg.arrived_end) {
            assign_row(r, t);
        }
        return;
    }
    let phase = (cfg.pass_index - 1u) % 3u;
    // Workgroup g owns nodes g, g + per, g + 2 per, ...
    for (var k = 0u; k < MAX_NODES; k += 1u) {
        let n = g + k * per;
        if (n < MAX_NODES) {
            process_node(n, phase, t);
        }
    }
}

// Append up to the remaining budget of leaf `node`'s rows to shu[total ..].
fn add_leaf(node: u32, total: u32, t: u32) -> u32 {
    let cnt = min(u_at(CNT_BASE + node), LIST_CAP);
    let room = BUDGET - min(total, BUDGET);
    let take = min(cnt, room);
    let lb = LIST_BASE + (u_at(SLOT_BASE + node) & SLOT_MASK) * LIST_CAP;
    for (var i = 0u; i < BUDGET; i += 128u) {
        let j = i + t;
        if (j < take) {
            shu[min(total + j, BUDGET - 1u)] = u_at(lb + j);
        }
    }
    workgroupBarrier();
    return total + take;
}

@compute @workgroup_size(128)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let q = wid.x;
    let t = lid.x;
    if (q >= cfg.n_queries) {
        return;
    }
    let qb = q * D4 + t * 4u;
    let q0 = queries[qb];
    let q1 = queries[qb + 1u];
    let q2 = queries[qb + 2u];
    let q3 = queries[qb + 3u];
    let qn2 = wg_sum128(t, dot(q0, q0) + dot(q1, q1) + dot(q2, q2) + dot(q3, q3));
    let qn = sqrt(qn2);
    // Descend, recording the sibling and the margin at each split.
    var node = 0u;
    var depth = 0u;
    for (var d = 0u; d < MAX_DEPTH; d += 1u) {
        let l = u_at(LEFT_BASE + node);
        if (l != 0u) {
            let db = DIR_BASE + node * DIM + t * 16u;
            let v0 = vec4<f32>(f_at(db), f_at(db + 1u), f_at(db + 2u), f_at(db + 3u));
            let v1 = vec4<f32>(f_at(db + 4u), f_at(db + 5u), f_at(db + 6u), f_at(db + 7u));
            let v2 = vec4<f32>(f_at(db + 8u), f_at(db + 9u), f_at(db + 10u), f_at(db + 11u));
            let v3 = vec4<f32>(f_at(db + 12u), f_at(db + 13u), f_at(db + 14u), f_at(db + 15u));
            let p = wg_sum128(t, dot(q0, v0) + dot(q1, v1) + dot(q2, v2) + dot(q3, v3));
            let thr = f_at(THR_BASE + node);
            let rgt = u_at(RIGHT_BASE + node) & NODE_MASK;
            let go_right = p > thr;
            if (t == 0u) {
                s_pn[depth & 63u] = select(rgt, l, go_right);
                s_pm[depth & 63u] = abs(p - thr);
            }
            node = select(l, rgt, go_right) & NODE_MASK;
            depth = depth + 1u;
        }
    }
    workgroupBarrier();
    var total = add_leaf(node, 0u, t);
    // Multi-probe: flip the least-confident path splits, one at a time.
    for (var k = 0u; k < MAX_PROBES; k += 1u) {
        if (t == 0u) {
            var best = PAD;
            var bm = 3.0e38;
            for (var d = 0u; d < MAX_DEPTH; d += 1u) {
                if (d < depth && s_pm[d & 63u] < bm) {
                    bm = s_pm[d & 63u];
                    best = d;
                }
            }
            s_misc[0] = best;
            if (best != PAD) {
                s_pm[best & 63u] = 3.0e38;
            }
        }
        workgroupBarrier();
        let bi = s_misc[0];
        workgroupBarrier();
        if (bi != PAD && total < BUDGET) {
            var alt = s_pn[bi & 63u] & NODE_MASK;
            for (var d = 0u; d < MAX_DEPTH; d += 1u) {
                let l = u_at(LEFT_BASE + alt);
                if (l != 0u) {
                    let db = DIR_BASE + alt * DIM + t * 16u;
                    let v0 = vec4<f32>(f_at(db), f_at(db + 1u), f_at(db + 2u), f_at(db + 3u));
                    let v1 = vec4<f32>(f_at(db + 4u), f_at(db + 5u), f_at(db + 6u), f_at(db + 7u));
                    let v2 = vec4<f32>(f_at(db + 8u), f_at(db + 9u), f_at(db + 10u), f_at(db + 11u));
                    let v3 = vec4<f32>(f_at(db + 12u), f_at(db + 13u), f_at(db + 14u), f_at(db + 15u));
                    let p = wg_sum128(t, dot(q0, v0) + dot(q1, v1) + dot(q2, v2) + dot(q3, v3));
                    let thr = f_at(THR_BASE + alt);
                    let rgt = u_at(RIGHT_BASE + alt) & NODE_MASK;
                    alt = select(l, rgt, p > thr) & NODE_MASK;
                }
            }
            total = add_leaf(alt, total, t);
        }
    }
    // Exact cosine over the gathered rows.
    let qrow = q * D4;
    for (var i = 0u; i < BUDGET; i += 128u) {
        let j = i + t;
        if (j < total) {
            let row = shu[j] & ROW_MASK;
            let kb = row * D4;
            var sacc = 0.0;
            for (var d = 0u; d < D4; d += 1u) {
                sacc = sacc + dot(keys[kb + d], queries[qrow + d]);
            }
            let kn = f_at(NORM_BASE + row);
            var score = NONE;
            let den = kn * qn;
            if (den > 0.0) {
                score = sacc / den;
            }
            sh[j] = score;
        }
    }
    workgroupBarrier();
    // Tournament: 64 rounds of a workgroup-wide argmax.
    for (var k = 0u; k < C_MAX; k += 1u) {
        var bs = NONE;
        var bj = PAD;
        for (var i = 0u; i < BUDGET; i += 128u) {
            let j = i + t;
            if (j < total) {
                let v = sh[j];
                if (v > bs) {
                    bs = v;
                    bj = j;
                }
            }
        }
        sh2[t] = bs;
        workgroupBarrier();
        if (t == 0u) {
            var w = 0u;
            var wv = NONE;
            for (var i = 0u; i < 128u; i += 1u) {
                if (sh2[i] > wv) {
                    wv = sh2[i];
                    w = i;
                }
            }
            s_misc[1] = w;
            s_misc[2] = select(0u, 1u, wv > NONE);
        }
        workgroupBarrier();
        let w = s_misc[1];
        let alive = s_misc[2];
        if (alive == 0u) {
            break;
        }
        if (t == w && bj != PAD) {
            cands[q * C_MAX + k] = shu[bj];
            sh[bj] = NONE;
        }
        workgroupBarrier();
    }
}
