// passes 1
// Cross-polytope hashing using a structured rotation in place of a dense
// Gaussian projection. Each of L = 6 tables folds the 2,048-D key into 64
// dimensions with a block-rotated count sketch. Within each block of 64 dims,
// dim (64b + c) goes to output (c + rot_t(b)) & 63 with a random sign. A
// 64-point Walsh-Hadamard transform then mixes the outputs. The bucket is
// argmax |y_j| plus its sign: 128 codes per table, 768 buckets in all. The
// hashes are salted by the seed slot, so the four seeds' indexes differ and the
// pooled candidates cover more rows. Ingest stores each row in its best code of
// every table, along with 1/|key|. Search hashes the query the same way and
// probes the best and second-best coordinate (each with its sign) in every
// table: 12 buckets. A workgroup bitmap removes duplicates. Every distinct
// member is scored exactly by cosine, each thread keeps its best 8, and a rank
// merge writes the best 64 to unique slots.

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const C_MAX: u32 = 64u;
const D4: u32 = 512u;
const WG: u32 = 64u;
const L: u32 = 6u;
const NCODE: u32 = 128u;
const NB: u32 = 768u;
const CAP: u32 = 8192u;
const CAP_SHIFT: u32 = 13u;
const BASE: u32 = 1024u;
const NPROBE: u32 = 12u;
const K: u32 = 8u;
const MERGE: u32 = 512u;
const F32_LAST: u32 = 8388607u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;

var<workgroup> wv: array<f32, 2048>;
var<workgroup> wr: array<u32, 512>;
var<workgroup> wy: array<f32, 64>;
var<workgroup> wn: array<f32, 64>;
var<workgroup> wb: array<u32, 16>;
var<workgroup> wseen: array<atomic<u32>, 1024>;

fn mix(x: u32) -> u32 {
    var h = x;
    h = h ^ (h >> 16u);
    h = h * 0x7feb352du;
    h = h ^ (h >> 15u);
    h = h * 0x846ca68bu;
    h = h ^ (h >> 16u);
    return h;
}

// Output j of table t's block-rotated, signed count sketch over wv.
fn sketch(t: u32, j: u32) -> f32 {
    let salt = (cfg.seed_slot + 1u) * 0x9E3779B9u + (t + 1u) * 0x85EBCA6Bu;
    var y = 0.0;
    for (var b = 0u; b < 32u; b = b + 1u) {
        let rot = mix(salt ^ ((b + 1u) * 0xC2B2AE35u)) & 63u;
        let c = (j + 64u - rot) & 63u;
        let d = b * 64u + c;
        let s = mix(salt + d * 0x27D4EB2Fu + 0x165667B1u);
        var v = wv[d & 2047u];
        if ((s & 1u) != 0u) {
            v = -v;
        }
        y = y + v;
    }
    return y;
}

fn member_at(bucket: u32, slot: u32) -> u32 {
    return BASE + (min(bucket, NB - 1u) << CAP_SHIFT) + (slot & (CAP - 1u));
}

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid3: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid3.x;
    let r = cfg.arrived_begin + wid.x;
    let live = r < cfg.arrived_end;
    let kb = (r & 0x7FFFu) * D4;
    var ss = 0.0;
    for (var i = 0u; i < D4; i = i + WG) {
        let k = i + t;
        var v = vec4<f32>(0.0);
        if (live) {
            v = keys[kb + k];
        }
        let o = (k * 4u) & 2047u;
        wv[o] = v.x;
        wv[o + 1u] = v.y;
        wv[o + 2u] = v.z;
        wv[o + 3u] = v.w;
        ss = ss + dot(v, v);
    }
    wn[t] = ss;
    workgroupBarrier();
    if (t == 0u && live) {
        var tot = 0.0;
        for (var j = 0u; j < WG; j = j + 1u) {
            tot = tot + wn[j];
        }
        var inv = 0.0;
        if (tot > 0.0) {
            inv = inverseSqrt(tot);
        }
        index_f32[min(r, F32_LAST)] = inv;
    }
    for (var tb = 0u; tb < L; tb = tb + 1u) {
        let y = sketch(tb, t);
        workgroupBarrier();
        wy[t] = y;
        workgroupBarrier();
        for (var s = 0u; s < 6u; s = s + 1u) {
            let h = 1u << s;
            if ((t & h) == 0u) {
                let a = wy[t];
                let b = wy[(t + h) & 63u];
                wy[t] = a + b;
                wy[(t + h) & 63u] = a - b;
            }
            workgroupBarrier();
        }
        if (t == 0u && live) {
            var bj = 0u;
            var bv = -1.0;
            for (var j = 0u; j < 64u; j = j + 1u) {
                let a = abs(wy[j]);
                if (a > bv) {
                    bv = a;
                    bj = j;
                }
            }
            var code = bj * 2u;
            if (wy[bj] < 0.0) {
                code = code + 1u;
            }
            let bucket = min(tb * NCODE + code, NB - 1u);
            let slot = atomicAdd(&index_u32[bucket], 1u);
            if (slot < CAP) {
                atomicStore(&index_u32[member_at(bucket, slot)], r);
            }
        }
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid3: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid3.x;
    let q = wid.x;
    let live = q < cfg.n_queries;
    let qb = q * D4;
    for (var i = 0u; i < D4; i = i + WG) {
        let k = i + t;
        var v = vec4<f32>(0.0);
        if (live) {
            v = queries[qb + k];
        }
        let o = (k * 4u) & 2047u;
        wv[o] = v.x;
        wv[o + 1u] = v.y;
        wv[o + 2u] = v.z;
        wv[o + 3u] = v.w;
    }
    for (var i = 0u; i < 1024u; i = i + WG) {
        atomicStore(&wseen[(i + t) & 1023u], 0u);
    }
    workgroupBarrier();
    for (var tb = 0u; tb < L; tb = tb + 1u) {
        let y = sketch(tb, t);
        workgroupBarrier();
        wy[t] = y;
        workgroupBarrier();
        for (var s = 0u; s < 6u; s = s + 1u) {
            let h = 1u << s;
            if ((t & h) == 0u) {
                let a = wy[t];
                let b = wy[(t + h) & 63u];
                wy[t] = a + b;
                wy[(t + h) & 63u] = a - b;
            }
            workgroupBarrier();
        }
        if (t == 0u) {
            var b1 = 0u;
            var v1 = -1.0;
            for (var j = 0u; j < 64u; j = j + 1u) {
                let a = abs(wy[j]);
                if (a > v1) {
                    v1 = a;
                    b1 = j;
                }
            }
            var b2 = 0u;
            var v2 = -1.0;
            for (var j = 0u; j < 64u; j = j + 1u) {
                let a = abs(wy[j]);
                if (j != b1 && a > v2) {
                    v2 = a;
                    b2 = j;
                }
            }
            var c1 = b1 * 2u;
            if (wy[b1] < 0.0) {
                c1 = c1 + 1u;
            }
            var c2 = b2 * 2u;
            if (wy[b2] < 0.0) {
                c2 = c2 + 1u;
            }
            wb[(tb * 2u) & 15u] = tb * NCODE + c1;
            wb[(tb * 2u + 1u) & 15u] = tb * NCODE + c2;
        }
    }
    workgroupBarrier();

    var best: array<f32, 8>;
    var rows: array<u32, 8>;
    for (var j = 0u; j < K; j = j + 1u) {
        best[j] = NONE;
        rows[j] = PAD;
    }
    if (live) {
        for (var p = 0u; p < NPROBE; p = p + 1u) {
            let bucket = min(wb[p & 15u], NB - 1u);
            let n = min(atomicLoad(&index_u32[bucket]), CAP);
            for (var i = 0u; i < n; i = i + WG) {
                let slot = i + t;
                if (slot < n) {
                    let r = atomicLoad(&index_u32[member_at(bucket, slot)]);
                    if (r < cfg.arrived_end) {
                        let bit = 1u << (r & 31u);
                        let old = atomicOr(&wseen[(r >> 5u) & 1023u], bit);
                        if ((old & bit) == 0u) {
                            let inv = index_f32[min(r, F32_LAST)];
                            if (inv > 0.0) {
                                let kb = (r & 0x7FFFu) * D4;
                                var sc = 0.0;
                                for (var d = 0u; d < D4; d = d + 1u) {
                                    let k = keys[kb + d];
                                    let o = (d * 4u) & 2047u;
                                    sc = sc + dot(k, vec4<f32>(wv[o], wv[o + 1u], wv[o + 2u], wv[o + 3u]));
                                }
                                let score = sc * inv;
                                if (score > best[K - 1u]) {
                                    var cs = score;
                                    var cr = r;
                                    for (var j = 0u; j < K; j = j + 1u) {
                                        if (cs > best[j]) {
                                            let ts = best[j];
                                            let tr = rows[j];
                                            best[j] = cs;
                                            rows[j] = cr;
                                            cs = ts;
                                            cr = tr;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    workgroupBarrier();
    for (var j = 0u; j < K; j = j + 1u) {
        let e = (t * K + j) & (MERGE - 1u);
        wv[e] = best[j];
        wr[e] = rows[j];
    }
    workgroupBarrier();
    if (live) {
        for (var k = 0u; k < K; k = k + 1u) {
            let i = (t * K + k) & (MERGE - 1u);
            let ri = wr[i];
            let si = wv[i];
            if (ri != PAD) {
                var rank = 0u;
                for (var j = 0u; j < MERGE; j = j + 1u) {
                    let rj = wr[j];
                    if (rj != PAD) {
                        let sj = wv[j];
                        if (sj > si || (sj == si && j < i)) {
                            rank = rank + 1u;
                        }
                    }
                }
                if (rank < C_MAX) {
                    cands[q * C_MAX + rank] = ri;
                }
            }
        }
    }
}
