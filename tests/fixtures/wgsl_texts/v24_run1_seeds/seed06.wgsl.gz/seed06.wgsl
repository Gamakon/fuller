// passes 3

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const MAXC: u32 = 512u;
const CAP: u32 = 256u;
const MEMBASE: u32 = 4096u;
const RI: u32 = 524288u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const NP: u32 = 4u;

var<workgroup> wkey: array<vec4<f32>, 512>;
var<workgroup> sv: array<f32, 64>;
var<workgroup> si: array<u32, 64>;
var<workgroup> sc: array<f32, 512>;
var<workgroup> msc: array<f32, 1024>;
var<workgroup> sel: array<u32, 4>;
var<workgroup> wc: u32;

fn red_max(t: u32, v: f32, i: u32) {
    workgroupBarrier();
    sv[t] = v;
    si[t] = i;
    workgroupBarrier();
    for (var k = 0u; k < 6u; k = k + 1u) {
        let s = 32u >> k;
        if (t < s) {
            let ov = sv[t + s];
            let oi = si[t + s];
            if (ov > sv[t] || (ov == sv[t] && oi < si[t])) {
                sv[t] = ov;
                si[t] = oi;
            }
        }
        workgroupBarrier();
    }
}

fn red_sum(t: u32, v: f32) -> f32 {
    workgroupBarrier();
    sv[t] = v;
    workgroupBarrier();
    for (var k = 0u; k < 6u; k = k + 1u) {
        let s = 32u >> k;
        if (t < s) {
            sv[t] = sv[t] + sv[t + s];
        }
        workgroupBarrier();
    }
    return sv[0];
}

fn write_centre(t: u32, c: u32, inv: f32) {
    for (var i = 0u; i < 8u; i = i + 1u) {
        let d4 = i * 64u + t;
        let v = wkey[d4] * inv;
        let base = (d4 * 4u) * MAXC + (c & 511u);
        index_f32[base & 0xFFFFFu] = v.x;
        index_f32[(base + MAXC) & 0xFFFFFu] = v.y;
        index_f32[(base + 2u * MAXC) & 0xFFFFFu] = v.z;
        index_f32[(base + 3u * MAXC) & 0xFFFFFu] = v.w;
    }
}

fn key_norm(t: u32) -> f32 {
    var p = 0.0;
    for (var i = 0u; i < 8u; i = i + 1u) {
        let v = wkey[i * 64u + t];
        p = p + dot(v, v);
    }
    return red_sum(t, p);
}

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = cfg.arrived_begin + wid.x;
    for (var i = 0u; i < 8u; i = i + 1u) {
        let d4 = i * 64u + t;
        wkey[d4] = keys[(row & 0x7FFFFu) * 512u + d4];
    }
    workgroupBarrier();

    if (cfg.pass_index == 0u) {
        if (cfg.stage == 1u && wid.x < 128u) {
            let n = key_norm(t);
            var inv = 0.0;
            if (n > 0.0) { inv = 1.0 / sqrt(n); }
            write_centre(t, wid.x, inv);
            if (t == 0u) {
                atomicAdd(&index_u32[0], 1u);
            }
        }
    } else if (cfg.pass_index == 1u) {
        let nc = min(atomicLoad(&index_u32[0]), MAXC);
        var bv = NONE;
        var bi = 0u;
        for (var i = 0u; i < 8u; i = i + 1u) {
            let c = i * 64u + t;
            if (c < nc) {
                var s = 0.0;
                for (var d4 = 0u; d4 < 512u; d4 = d4 + 1u) {
                    let v = wkey[d4];
                    let base = d4 * 4u * MAXC + c;
                    s = s + v.x * index_f32[base & 0xFFFFFu]
                          + v.y * index_f32[(base + MAXC) & 0xFFFFFu]
                          + v.z * index_f32[(base + 2u * MAXC) & 0xFFFFFu]
                          + v.w * index_f32[(base + 3u * MAXC) & 0xFFFFFu];
                }
                if (s > bv) { bv = s; bi = c; }
            }
        }
        red_max(t, bv, bi);
        if (t == 0u) {
            let b = si[0] & 511u;
            let slot = atomicAdd(&index_u32[1u + b], 1u);
            if (slot < CAP) {
                atomicStore(&index_u32[(MEMBASE + b * CAP + slot) & 0xFFFFFu], row);
            }
            atomicStore(&index_u32[(RI + (row & 0x7FFFu)) & 0xFFFFFu], b | (min(slot, 1000000u) << 10u));
        }
    } else {
        if (t == 0u) {
            wc = PAD;
            let info = atomicLoad(&index_u32[(RI + (row & 0x7FFFu)) & 0xFFFFFu]);
            let b = info & 511u;
            let slot = info >> 10u;
            let n = atomicLoad(&index_u32[1u + b]);
            let lim = min(MAXC, 128u + 128u * cfg.stage);
            if (n >= 48u && (slot & 15u) == 15u && slot < CAP) {
                let c = atomicAdd(&index_u32[0], 1u);
                if (c < lim) {
                    wc = c;
                } else {
                    atomicSub(&index_u32[0], 1u);
                }
            }
        }
        workgroupBarrier();
        let c = wc;
        if (c < MAXC) {
            let n = key_norm(t);
            var inv = 0.0;
            if (n > 0.0) { inv = 1.0 / sqrt(n); }
            write_centre(t, c, inv);
            if (t == 0u) {
                atomicStore(&index_u32[1u + c], 1u);
                atomicStore(&index_u32[(MEMBASE + c * CAP) & 0xFFFFFu], row);
            }
        } else {
            // keep barrier counts uniform
            let n = key_norm(t);
            if (n < -1.0) { wc = 0u; }
        }
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    for (var i = 0u; i < 8u; i = i + 1u) {
        let d4 = i * 64u + t;
        wkey[d4] = queries[(q & 0xFFFu) * 512u + d4];
    }
    workgroupBarrier();
    let nc = min(atomicLoad(&index_u32[0]), MAXC);
    for (var i = 0u; i < 8u; i = i + 1u) {
        let c = i * 64u + t;
        var s = NONE;
        if (c < nc) {
            s = 0.0;
            for (var d4 = 0u; d4 < 512u; d4 = d4 + 1u) {
                let v = wkey[d4];
                let base = d4 * 4u * MAXC + c;
                s = s + v.x * index_f32[base & 0xFFFFFu]
                      + v.y * index_f32[(base + MAXC) & 0xFFFFFu]
                      + v.z * index_f32[(base + 2u * MAXC) & 0xFFFFFu]
                      + v.w * index_f32[(base + 3u * MAXC) & 0xFFFFFu];
            }
        }
        sc[c] = s;
    }
    workgroupBarrier();
    for (var k = 0u; k < NP; k = k + 1u) {
        var bv = NONE;
        var bi = 0u;
        for (var i = 0u; i < 8u; i = i + 1u) {
            let c = i * 64u + t;
            if (sc[c] > bv) { bv = sc[c]; bi = c; }
        }
        red_max(t, bv, bi);
        if (t == 0u) {
            if (sv[0] > NONE) {
                sel[k] = si[0];
                sc[si[0]] = NONE;
            } else {
                sel[k] = PAD;
            }
        }
        workgroupBarrier();
    }
    // exact scan of the members of the chosen buckets
    for (var i = 0u; i < 16u; i = i + 1u) {
        let j = i * 64u + t;
        let k = j >> 8u;
        let s = j & 255u;
        let b = sel[k & 3u];
        var score = NONE;
        if (b != PAD) {
            let cnt = min(atomicLoad(&index_u32[1u + (b & 511u)]), CAP);
            if (s < cnt) {
                let r = atomicLoad(&index_u32[(MEMBASE + (b & 511u) * CAP + s) & 0xFFFFFu]);
                var dt = 0.0;
                var kn = 0.0;
                for (var d4 = 0u; d4 < 512u; d4 = d4 + 1u) {
                    let kv = keys[(r & 0x7FFFFu) * 512u + d4];
                    dt = dt + dot(kv, wkey[d4]);
                    kn = kn + dot(kv, kv);
                }
                if (kn > 0.0) { score = dt * inverseSqrt(kn); }
            }
        }
        msc[j] = score;
    }
    workgroupBarrier();
    for (var r = 0u; r < 64u; r = r + 1u) {
        var bv = NONE;
        var bi = 0u;
        for (var i = 0u; i < 16u; i = i + 1u) {
            let j = i * 64u + t;
            if (msc[j] > bv) { bv = msc[j]; bi = j; }
        }
        red_max(t, bv, bi);
        if (t == 0u) {
            if (sv[0] > NONE) {
                let j = si[0];
                let b = sel[(j >> 8u) & 3u] & 511u;
                let row = atomicLoad(&index_u32[(MEMBASE + b * CAP + (j & 255u)) & 0xFFFFFu]);
                if (q < cfg.n_queries) {
                    cands[(q * 64u + r) & 0x3FFFFFu] = row;
                }
                msc[j] = NONE;
            }
        }
        workgroupBarrier();
    }
}
