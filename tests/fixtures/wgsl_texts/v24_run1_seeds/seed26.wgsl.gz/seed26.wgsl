// passes 1
struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const THREADS: u32 = 8u;
const LOCAL_K: u32 = 8u;
const OUT_K: u32 = 32u;
const BUCKETS: u32 = 1024u;
const CAP: u32 = 32u;
const COUNT_BASE: u32 = 0u;
const DATA_BASE: u32 = 2048u;
const PAD: u32 = 0xFFFFFFFFu;
const NEG: f32 = -3.0e38;

var<workgroup> tail_scores: array<f32, 64>;
var<workgroup> tail_rows: array<u32, 64>;
var<workgroup> old_scores: array<f32, 64>;
var<workgroup> old_rows: array<u32, 64>;

fn signature_vec(v: vec4<f32>, lane: u32) -> f32 {
    if ((lane & 3u) == 0u) {
        return dot(v, vec4<f32>(1.0, -1.0, 1.0, -1.0));
    }
    if ((lane & 3u) == 1u) {
        return dot(v, vec4<f32>(1.0, 1.0, -1.0, -1.0));
    }
    if ((lane & 3u) == 2u) {
        return dot(v, vec4<f32>(1.0, -1.0, -1.0, 1.0));
    }
    return dot(v, vec4<f32>(1.0, 1.0, 1.0, -1.0));
}

fn row_bucket(r: u32) -> u32 {
    var h = 0u;
    for (var d = 0u; d < 10u; d = d + 1u) {
        let v = keys[(r & 0x7FFFFu) * D4 + d];
        if (signature_vec(v, d) > 0.0) {
            h = h | (1u << d);
        }
    }
    return h & 1023u;
}

fn query_bucket(q: u32) -> u32 {
    var h = 0u;
    for (var d = 0u; d < 10u; d = d + 1u) {
        let v = queries[(q & 0x7FFFFu) * D4 + d];
        if (signature_vec(v, d) > 0.0) {
            h = h | (1u << d);
        }
    }
    return h & 1023u;
}

fn query_norm(q: u32) -> f32 {
    var n = 0.0;
    for (var d = 0u; d < D4; d = d + 1u) {
        let v = queries[(q & 0x7FFFFu) * D4 + d];
        n = n + dot(v, v);
    }
    return n;
}

fn cosine(r: u32, q: u32, qn: f32) -> f32 {
    var s = 0.0;
    var kn = 0.0;
    for (var d = 0u; d < D4; d = d + 1u) {
        let a = keys[(r & 0x7FFFFu) * D4 + d];
        let b = queries[(q & 0x7FFFFu) * D4 + d];
        s = s + dot(a, b);
        kn = kn + dot(a, a);
    }
    let den = sqrt(kn * qn);
    if (den > 0.0) {
        return s / den;
    }
    return NEG;
}

@compute @workgroup_size(1)
fn ingest(@builtin(workgroup_id) wid: vec3<u32>) {
    let r = cfg.arrived_begin + wid.x;
    if (r < cfg.arrived_end) {
        let b = row_bucket(r);
        let p = atomicAdd(&index_u32[COUNT_BASE + b], 1u);
        if (p < CAP) {
            let dst = DATA_BASE + b * CAP + p;
            atomicStore(&index_u32[dst], r);
        }
    }
}

@compute @workgroup_size(8)
fn search(
    @builtin(local_invocation_id) lid3: vec3<u32>,
    @builtin(workgroup_id) wid: vec3<u32>
) {
    let lid = lid3.x;
    let q = wid.x;

    var tscore: array<f32, 8>;
    var trow: array<u32, 8>;
    var oscore: array<f32, 8>;
    var orow: array<u32, 8>;

    for (var j = 0u; j < LOCAL_K; j = j + 1u) {
        tscore[j] = NEG;
        trow[j] = PAD;
        oscore[j] = NEG;
        orow[j] = PAD;
    }

    if (q < cfg.n_queries) {
        let qn = query_norm(q);
        let fresh_n = cfg.arrived_end - cfg.arrived_begin;

        for (var i = 0u; i < fresh_n; i = i + THREADS) {
            let r = cfg.arrived_begin + i + lid;
            if (r < cfg.arrived_end) {
                let sc = cosine(r, q, qn);
                if (sc > tscore[LOCAL_K - 1u]) {
                    var carry_s = sc;
                    var carry_r = r;
                    for (var j = 0u; j < LOCAL_K; j = j + 1u) {
                        if (carry_s > tscore[j]) {
                            let swap_s = tscore[j];
                            let swap_r = trow[j];
                            tscore[j] = carry_s;
                            trow[j] = carry_r;
                            carry_s = swap_s;
                            carry_r = swap_r;
                        }
                    }
                }
            }
        }

        let base = query_bucket(q);
        let probe = base ^ (1u << lid);
        let count = min(atomicLoad(&index_u32[COUNT_BASE + probe]), CAP);
        for (var j = 0u; j < CAP; j = j + 1u) {
            if (j < count) {
                let loc = DATA_BASE + probe * CAP + j;
                let r = atomicLoad(&index_u32[loc]);
                if (r < cfg.arrived_begin) {
                    let sc = cosine(r, q, qn);
                    if (sc > oscore[LOCAL_K - 1u]) {
                        var carry_s = sc;
                        var carry_r = r;
                        for (var k = 0u; k < LOCAL_K; k = k + 1u) {
                            if (carry_s > oscore[k]) {
                                let swap_s = oscore[k];
                                let swap_r = orow[k];
                                oscore[k] = carry_s;
                                orow[k] = carry_r;
                                carry_s = swap_s;
                                carry_r = swap_r;
                            }
                        }
                    }
                }
            }
        }
    }

    for (var j = 0u; j < LOCAL_K; j = j + 1u) {
        tail_scores[lid * LOCAL_K + j] = tscore[j];
        tail_rows[lid * LOCAL_K + j] = trow[j];
        old_scores[lid * LOCAL_K + j] = oscore[j];
        old_rows[lid * LOCAL_K + j] = orow[j];
    }
    workgroupBarrier();

    if (lid == 0u && q < cfg.n_queries) {
        var best_s: array<f32, 32>;
        var best_r: array<u32, 32>;

        for (var j = 0u; j < OUT_K; j = j + 1u) {
            best_s[j] = NEG;
            best_r[j] = PAD;
        }
        for (var i = 0u; i < THREADS * LOCAL_K; i = i + 1u) {
            let sc = tail_scores[i];
            let r = tail_rows[i];
            if (r != PAD && sc > best_s[OUT_K - 1u]) {
                var carry_s = sc;
                var carry_r = r;
                for (var j = 0u; j < OUT_K; j = j + 1u) {
                    if (carry_s > best_s[j]) {
                        let swap_s = best_s[j];
                        let swap_r = best_r[j];
                        best_s[j] = carry_s;
                        best_r[j] = carry_r;
                        carry_s = swap_s;
                        carry_r = swap_r;
                    }
                }
            }
        }
        for (var j = 0u; j < OUT_K; j = j + 1u) {
            cands[q * 64u + j] = best_r[j];
            best_s[j] = NEG;
            best_r[j] = PAD;
        }
        for (var i = 0u; i < THREADS * LOCAL_K; i = i + 1u) {
            let sc = old_scores[i];
            let r = old_rows[i];
            if (r != PAD && sc > best_s[OUT_K - 1u]) {
                var carry_s = sc;
                var carry_r = r;
                for (var j = 0u; j < OUT_K; j = j + 1u) {
                    if (carry_s > best_s[j]) {
                        let swap_s = best_s[j];
                        let swap_r = best_r[j];
                        best_s[j] = carry_s;
                        best_r[j] = carry_r;
                        carry_s = swap_s;
                        carry_r = swap_r;
                    }
                }
            }
        }
        for (var j = 0u; j < OUT_K; j = j + 1u) {
            cands[q * 64u + OUT_K + j] = best_r[j];
        }
    }
}
