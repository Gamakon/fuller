// passes 2
// v24 design: centre buckets with score-gap early stop (population seed 1,
// launch kernel 30).
//
// Index: 256 centres copied from the first microbatch (row c * per_section / 256)
// into index_f32. Pass 0 of every ingest stores each arriving row's inverse
// norm (and, at stage 1, the centres and their inverse norms). Pass 1 assigns
// each arriving row to its nearest centre by cosine; a row whose best cosine
// is under ORPHAN_COS is an orphan and goes to an always-scanned overflow
// pool instead, which keeps the bucket angle bounds tight. Each bucket keeps
// an atomicMax of its members' angle to the centre (micro-radians, u32).
//
// Search: 256 threads a query. Phase A: thread t scores centre t, turns it
// into an upper bound on any member's cosine, cos(max(0, theta_qc - theta_max_c)),
// and the 256 bounds are rank-sorted in workgroup memory. Phase B: 16 groups
// of 16 lanes scan the overflow pool, then buckets in bound order, each lane
// holding its 32-vec4 slice of the query in registers. The scan stops when the
// next bucket's bound cannot beat a lower bound on the 64th best found (the
// max over the groups' 64th), or when a probe / row budget is spent.

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D: u32 = 2048u;
const D4: u32 = 512u;
const NC: u32 = 256u;
const CAP: u32 = 2048u;
const OVF_CAP: u32 = 2048u;
const MAX_PROBES: u32 = 48u;
const MAX_SCAN: u32 = 3072u;
const ORPHAN_COS: f32 = 0.1;
const C_MAX: u32 = 64u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const RMASK: u32 = 0x7FFFu;
const UMASK: u32 = 0x7FFFFFu;
const FMASK: u32 = 0x7FFFFFu;

// index_u32 layout
const U_COUNT: u32 = 0u;        // 256 bucket counts
const U_ANG: u32 = 256u;        // 256 bucket max angles (micro-radians)
const U_OVFN: u32 = 512u;       // overflow count
const U_BUCKETS: u32 = 1024u;   // 256 * CAP row ids
const U_OVF: u32 = 525312u;     // OVF_CAP row ids

// index_f32 layout
const F_CENT: u32 = 0u;         // 256 * 2048 centre keys
const F_CINV: u32 = 524288u;    // 256 centre inverse norms
const F_RINV: u32 = 524544u;    // 32768 row inverse norms

var<workgroup> wbuf: array<u32, 2048>;
var<workgroup> wred: array<f32, 256>;
var<workgroup> worder: array<u32, 256>;
var<workgroup> wbnd: array<f32, 256>;

@compute @workgroup_size(256)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let r = cfg.arrived_begin + wid.x;
    var valid = false;
    if (r < cfg.arrived_end && r < 32768u) {
        valid = true;
    }
    let rr = r & RMASK;

    if (cfg.pass_index == 0u) {
        // Row inverse norm.
        var acc = 0.0;
        for (var i = 0u; i < D4; i = i + 256u) {
            let d = i + t;
            if (d < D4) {
                let v = keys[rr * D4 + d];
                acc = acc + dot(v, v);
            }
        }
        wred[t] = acc;
        workgroupBarrier();
        if (t == 0u && valid) {
            var n = 0.0;
            for (var j = 0u; j < 256u; j = j + 1u) {
                n = n + wred[j];
            }
            var inv = 0.0;
            if (n > 0.0) {
                inv = inverseSqrt(n);
            }
            index_f32[(F_RINV + rr) & FMASK] = inv;
        }
        workgroupBarrier();

        // Stage 1: workgroups 0..255 each copy one centre from the first batch.
        var dc = false;
        if (cfg.stage == 1u && wid.x < NC && valid) {
            dc = true;
        }
        if (dc) {
            let per = cfg.arrived_end - cfg.arrived_begin;
            var src = (wid.x * per) / NC;
            if (src >= cfg.arrived_end) {
                src = 0u;
            }
            src = src & RMASK;
            let c = wid.x & 255u;
            var cacc = 0.0;
            for (var i = 0u; i < D4; i = i + 256u) {
                let d = i + t;
                if (d < D4) {
                    let v = keys[src * D4 + d];
                    let fb = F_CENT + c * D + d * 4u;
                    index_f32[fb & FMASK] = v.x;
                    index_f32[(fb + 1u) & FMASK] = v.y;
                    index_f32[(fb + 2u) & FMASK] = v.z;
                    index_f32[(fb + 3u) & FMASK] = v.w;
                    cacc = cacc + dot(v, v);
                }
            }
            wred[t] = cacc;
            workgroupBarrier();
            if (t == 0u) {
                var n = 0.0;
                for (var j = 0u; j < 256u; j = j + 1u) {
                    n = n + wred[j];
                }
                var inv = 0.0;
                if (n > 0.0) {
                    inv = inverseSqrt(n);
                }
                index_f32[(F_CINV + c) & FMASK] = inv;
            }
        }
    } else if (cfg.pass_index == 1u) {
        // Stash the row as scalars in workgroup memory.
        for (var i = 0u; i < D4; i = i + 256u) {
            let d = i + t;
            if (d < D4) {
                let v = keys[rr * D4 + d];
                wbuf[(d * 4u) & 2047u] = bitcast<u32>(v.x);
                wbuf[(d * 4u + 1u) & 2047u] = bitcast<u32>(v.y);
                wbuf[(d * 4u + 2u) & 2047u] = bitcast<u32>(v.z);
                wbuf[(d * 4u + 3u) & 2047u] = bitcast<u32>(v.w);
            }
        }
        workgroupBarrier();
        // Thread t scores centre t.
        var s = 0.0;
        let cb = F_CENT + t * D;
        for (var d = 0u; d < D; d = d + 1u) {
            s = s + bitcast<f32>(wbuf[d & 2047u]) * index_f32[(cb + d) & FMASK];
        }
        wred[t] = s * index_f32[(F_CINV + t) & FMASK];
        workgroupBarrier();
        if (t == 0u && valid) {
            var bc = 0u;
            var bs = NONE;
            for (var j = 0u; j < NC; j = j + 1u) {
                let v = wred[j];
                if (v > bs) {
                    bs = v;
                    bc = j;
                }
            }
            let cosv = clamp(bs * index_f32[(F_RINV + rr) & FMASK], -1.0, 1.0);
            var placed = false;
            if (cosv < ORPHAN_COS) {
                let o = atomicAdd(&index_u32[U_OVFN], 1u);
                if (o < OVF_CAP) {
                    atomicStore(&index_u32[(U_OVF + o) & UMASK], rr);
                    placed = true;
                }
            }
            if (!placed) {
                let slot = atomicAdd(&index_u32[(U_COUNT + bc) & UMASK], 1u);
                if (slot < CAP) {
                    atomicStore(&index_u32[(U_BUCKETS + bc * CAP + slot) & UMASK], rr);
                    let ang = u32(acos(cosv) * 1.0e6);
                    atomicMax(&index_u32[(U_ANG + bc) & UMASK], ang);
                } else {
                    let o = atomicAdd(&index_u32[U_OVFN], 1u);
                    if (o < OVF_CAP) {
                        atomicStore(&index_u32[(U_OVF + o) & UMASK], rr);
                    }
                }
            }
        }
    }
}

@compute @workgroup_size(256)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let q = wid.x;
    let t = lid.x;
    let g = t >> 4u;
    let lane = t & 15u;
    var qq = q;
    if (qq >= cfg.n_queries) {
        qq = 0u;
    }

    // Phase A: centre scores and bounds.
    var s = 0.0;
    var qn = 0.0;
    let cb = F_CENT + t * D;
    for (var d = 0u; d < D4; d = d + 1u) {
        let v = queries[qq * D4 + d];
        qn = qn + dot(v, v);
        let fb = cb + d * 4u;
        let cv = vec4<f32>(
            index_f32[fb & FMASK],
            index_f32[(fb + 1u) & FMASK],
            index_f32[(fb + 2u) & FMASK],
            index_f32[(fb + 3u) & FMASK]);
        s = s + dot(v, cv);
    }
    var qinv = 0.0;
    if (qn > 0.0) {
        qinv = inverseSqrt(qn);
    }
    let cq = clamp(s * qinv * index_f32[(F_CINV + t) & FMASK], -1.0, 1.0);
    let cnt = atomicLoad(&index_u32[(U_COUNT + t) & UMASK]);
    let ang = f32(atomicLoad(&index_u32[(U_ANG + t) & UMASK])) * 1.0e-6;
    var bound = -2.0;
    if (cnt > 0u) {
        bound = cos(max(acos(cq) - ang, 0.0));
    }
    wbnd[t] = bound;
    workgroupBarrier();
    var rank = 0u;
    for (var j = 0u; j < NC; j = j + 1u) {
        let o = wbnd[j];
        if (o > bound || (o == bound && j < t)) {
            rank = rank + 1u;
        }
    }
    worder[rank & 255u] = t;
    workgroupBarrier();

    var ovn = 0u;
    ovn = min(atomicLoad(&index_u32[U_OVFN]), OVF_CAP);

    // Phase B: lane holds its slice of the query.
    var qreg: array<vec4<f32>, 32>;
    for (var i = 0u; i < 32u; i = i + 1u) {
        qreg[i] = queries[qq * D4 + lane * 32u + i];
    }
    var best: array<f32, 64>;
    var rows: array<u32, 64>;
    for (var j = 0u; j < C_MAX; j = j + 1u) {
        best[j] = NONE;
        rows[j] = PAD;
    }
    var kth = NONE;
    var scanned = 0u;
    var probes = 0u;

    for (var k = 0u; k < NC + 1u; k = k + 1u) {
        var base = U_OVF;
        var n = ovn;
        var bnd = 2.0;
        var stop = false;
        if (k > 0u) {
            var c = 0u;
            c = worder[(k - 1u) & 255u];
            bnd = wbnd[c & 255u];
            n = min(atomicLoad(&index_u32[(U_COUNT + c) & UMASK]), CAP);
            base = U_BUCKETS + c * CAP;
            if (n == 0u || bnd <= kth || probes >= MAX_PROBES || scanned >= MAX_SCAN) {
                stop = true;
            }
        }
        if (stop) {
            break;
        }
        for (var i = 0u; i < n; i = i + 16u) {
            let idx = i + g;
            var partial = 0.0;
            var r = 0u;
            if (idx < n) {
                r = atomicLoad(&index_u32[(base + idx) & UMASK]) & RMASK;
                let kb = r * D4 + lane * 32u;
                for (var j = 0u; j < 32u; j = j + 1u) {
                    partial = partial + dot(qreg[j], keys[kb + j]);
                }
            }
            wred[t] = partial;
            workgroupBarrier();
            if (lane == 0u && idx < n) {
                var sum = 0.0;
                for (var j = 0u; j < 16u; j = j + 1u) {
                    sum = sum + wred[(g * 16u + j) & 255u];
                }
                let score = sum * qinv * index_f32[(F_RINV + r) & FMASK];
                if (score > best[C_MAX - 1u]) {
                    var cs = score;
                    var cr = r;
                    for (var j = 0u; j < C_MAX; j = j + 1u) {
                        if (cs > best[j]) {
                            let ts = best[j];
                            let tr = rows[j];
                            best[j] = cs;
                            rows[j] = cr;
                            cs = ts;
                            cr = tr;
                        }
                    }
                }
            }
            workgroupBarrier();
        }
        scanned = scanned + n;
        probes = probes + 1u;
        // Lower bound on the global 64th best: max over groups of their 64th.
        if (lane == 0u) {
            wred[g & 255u] = best[C_MAX - 1u];
        }
        workgroupBarrier();
        var m = NONE;
        for (var j = 0u; j < 16u; j = j + 1u) {
            m = max(m, wred[j]);
        }
        kth = m;
        workgroupBarrier();
    }

    // Merge the 16 group lists; thread t < 64 writes slot t.
    if (lane == 0u) {
        for (var j = 0u; j < C_MAX; j = j + 1u) {
            wbuf[(g * C_MAX + j) & 2047u] = bitcast<u32>(best[j]);
            wbuf[(1024u + g * C_MAX + j) & 2047u] = rows[j];
        }
    }
    workgroupBarrier();
    if (t < C_MAX && q < cfg.n_queries) {
        for (var j = 0u; j < C_MAX; j = j + 1u) {
            best[j] = NONE;
            rows[j] = PAD;
        }
        for (var i = 0u; i < 1024u; i = i + 1u) {
            let sc = bitcast<f32>(wbuf[i & 2047u]);
            let rr = wbuf[(1024u + i) & 2047u];
            if (rr != PAD && sc > best[C_MAX - 1u]) {
                var cs = sc;
                var cr = rr;
                for (var j = 0u; j < C_MAX; j = j + 1u) {
                    if (cs > best[j]) {
                        let ts = best[j];
                        let tr = rows[j];
                        best[j] = cs;
                        rows[j] = cr;
                        cs = ts;
                        cr = tr;
                    }
                }
            }
        }
        cands[q * C_MAX + t] = rows[t];
    }
}
