// passes 1
struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const NB: u32 = 12u;
const CAP: u32 = 1024u;
const NCELL: u32 = 4096u;
const BASE: u32 = 4096u;
const PAD: u32 = 0xFFFFFFFFu;
const MAXC: u32 = 1024u;

var<workgroup> wproj: array<f32, 768>;
var<workgroup> wsum: array<f32, 12>;
var<workgroup> wcell: u32;
var<workgroup> wrow: array<u32, 1024>;
var<workgroup> wscore: array<f32, 1024>;
var<workgroup> wn: u32;

fn sgn(d: u32, b: u32) -> f32 {
    var h = (d * 0x9E3779B1u) ^ (b * 0x85EBCA6Bu + 0x1234567u);
    h = h ^ (h >> 15u);
    h = h * 0x2C1B3C6Du;
    h = h ^ (h >> 12u);
    h = h * 0x297A2D39u;
    h = h ^ (h >> 15u);
    return select(-1.0, 1.0, (h & 1u) == 1u);
}

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = cfg.arrived_begin + wid.x;
    let valid = row < cfg.arrived_end;
    var acc: array<f32, 12>;
    for (var b = 0u; b < NB; b++) { acc[b] = 0.0; }
    if (valid) {
        for (var i = 0u; i < 8u; i++) {
            let d4 = i * 64u + t;
            let v = keys[(row & 0x7FFFFu) * D4 + d4];
            for (var b = 0u; b < NB; b++) {
                acc[b] += v.x * sgn(d4 * 4u, b) + v.y * sgn(d4 * 4u + 1u, b)
                        + v.z * sgn(d4 * 4u + 2u, b) + v.w * sgn(d4 * 4u + 3u, b);
            }
        }
    }
    for (var b = 0u; b < NB; b++) { wproj[b * 64u + t] = acc[b]; }
    workgroupBarrier();
    if (t < NB) {
        var s = 0.0;
        for (var i = 0u; i < 64u; i++) { s += wproj[t * 64u + i]; }
        wsum[t] = s;
    }
    workgroupBarrier();
    if (t == 0u && valid) {
        var cell = 0u;
        for (var b = 0u; b < NB; b++) {
            if (wsum[b] > 0.0) { cell |= (1u << b); }
        }
        cell = cell & (NCELL - 1u);
        let slot = atomicAdd(&index_u32[cell], 1u);
        if (slot < CAP) {
            atomicStore(&index_u32[(BASE + cell * CAP + slot) & 0x7FFFFFu], row);
        }
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let qv = q < cfg.n_queries;
    var acc: array<f32, 12>;
    for (var b = 0u; b < NB; b++) { acc[b] = 0.0; }
    if (qv) {
        for (var i = 0u; i < 8u; i++) {
            let d4 = i * 64u + t;
            let v = queries[q * D4 + d4];
            for (var b = 0u; b < NB; b++) {
                acc[b] += v.x * sgn(d4 * 4u, b) + v.y * sgn(d4 * 4u + 1u, b)
                        + v.z * sgn(d4 * 4u + 2u, b) + v.w * sgn(d4 * 4u + 3u, b);
            }
        }
    }
    for (var b = 0u; b < NB; b++) { wproj[b * 64u + t] = acc[b]; }
    workgroupBarrier();
    if (t < NB) {
        var s = 0.0;
        for (var i = 0u; i < 64u; i++) { s += wproj[t * 64u + i]; }
        wsum[t] = s;
    }
    workgroupBarrier();
    if (t == 0u) {
        var n = 0u;
        if (qv) {
            var cell = 0u;
            for (var b = 0u; b < NB; b++) {
                if (wsum[b] > 0.0) { cell |= (1u << b); }
            }
            var ord: array<u32, 8>;
            var used = 0u;
            for (var k = 0u; k < 8u; k++) {
                var bestb = 0u;
                var bestv = 3.0e38;
                for (var b = 0u; b < NB; b++) {
                    if ((used & (1u << b)) == 0u && abs(wsum[b]) < bestv) {
                        bestv = abs(wsum[b]);
                        bestb = b;
                    }
                }
                used |= (1u << bestb);
                ord[k] = bestb;
            }
            for (var p = 0u; p < 20u; p++) {
                var mask = 0u;
                if (p < 16u) {
                    for (var k = 0u; k < 4u; k++) {
                        if ((p & (1u << k)) != 0u) { mask |= (1u << ord[k]); }
                    }
                } else {
                    mask = 1u << ord[p - 12u];
                }
                let c = (cell ^ mask) & (NCELL - 1u);
                let cnt = min(atomicLoad(&index_u32[c]), CAP);
                for (var j = 0u; j < CAP; j++) {
                    if (j < cnt && n < MAXC) {
                        wrow[n] = atomicLoad(&index_u32[(BASE + c * CAP + j) & 0x7FFFFFu]);
                        n++;
                    }
                }
            }
        }
        wn = n;
    }
    workgroupBarrier();
    let n = wn;
    for (var i = 0u; i < MAXC; i += 64u) {
        let c = i + t;
        if (c < n) {
            let r = wrow[c];
            var s = 0.0;
            var kn = 0.0;
            for (var d = 0u; d < D4; d++) {
                let k = keys[(r & 0x7FFFFu) * D4 + d];
                s += dot(k, queries[q * D4 + d]);
                kn += dot(k, k);
            }
            var sc = -3.0e38;
            if (kn > 0.0) { sc = s * inverseSqrt(kn); }
            wscore[c] = sc;
        }
    }
    workgroupBarrier();
    if (qv) {
        for (var i = 0u; i < MAXC; i += 64u) {
            let c = i + t;
            if (c < n) {
                let sc = wscore[c];
                var rank = 0u;
                for (var j = 0u; j < MAXC; j++) {
                    if (j < n) {
                        let o = wscore[j];
                        if (o > sc || (o == sc && j < c)) { rank++; }
                    }
                }
                if (rank < 64u && sc > -1.0e38) {
                    cands[q * 64u + rank] = wrow[c];
                }
            }
        }
    }
}
