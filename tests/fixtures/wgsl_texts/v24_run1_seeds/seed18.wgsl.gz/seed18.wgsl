// passes 3
// Pivot-pair sorted projections. A key is not projected onto random
// directions. It is projected onto 16 directions taken from the data: the
// difference of two pivot rows' unit keys, pivot pairs chosen by hash from
// the first microbatch. Rows are kept in 16 sorted orders, with two banks
// swapped each stage. Pass 0 sketches each new row: 32 pivot cosines give
// 16 differences. Pass 1 ranks each new row among the new batch, writes the
// batch's sorted order to a scratch list, and places the row in the new bank
// at (rank among new + binary-search rank among old). Pass 2 moves every old
// row to (old position + binary-search count of new rows below it). The
// search takes a window of 64 around the query on each order (1,024 slots),
// sorts them by 16-D sketch distance, rescores the best 256 exactly by
// cosine and returns the top 64.

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const C_MAX: u32 = 64u;
const D4: u32 = 512u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const BIG: f32 = 3.0e38;
const NDIR: u32 = 16u;
const AMASK: u32 = 0x7FFFFFu;
const BANK: u32 = 32768u;
const TMP_BASE: u32 = 1048576u;
const TMP_STRIDE: u32 = 8192u;
const NORM_BASE: u32 = 524288u;

var<workgroup> red: array<f32, 768>;
var<workgroup> pc: array<f32, 32>;
var<workgroup> qp: array<f32, 16>;
var<workgroup> xnorm: f32;
var<workgroup> cnt: array<atomic<u32>, 16>;
var<workgroup> wpos: array<u32, 16>;
var<workgroup> sk_s: array<f32, 1024>;
var<workgroup> sk_r: array<u32, 1024>;
var<workgroup> ex_s: array<f32, 256>;
var<workgroup> ex_r: array<u32, 256>;

fn hash_u(x: u32) -> u32 {
    var h = x;
    h = h ^ (h >> 16u);
    h = h * 0x7feb352du;
    h = h ^ (h >> 15u);
    h = h * 0x846ca68bu;
    h = h ^ (h >> 16u);
    return h;
}

fn pivot_row(j: u32, per: u32) -> u32 {
    let pair = j >> 1u;
    let salt = cfg.seed_slot * 0x632BE5ABu;
    let a = hash_u(pair * 2654435761u + 0x9E37u + salt) % per;
    if ((j & 1u) == 0u) {
        return a;
    }
    let off = 1u + hash_u(pair * 2246822519u + 0x51EDu + salt) % max(per - 1u, 1u);
    return (a + off) % per;
}

fn load_x(isq: bool, row: u32, d: u32) -> vec4<f32> {
    if (isq) {
        return queries[(row & 0xFFFFu) * D4 + d];
    }
    return keys[(row & 0x7FFFFu) * D4 + d];
}

// All 256 threads call this. It leaves the 16 sketch values in qp and the
// norm of x in xnorm.
fn compute_sketch(isq: bool, row: u32, t: u32) {
    let per = max(cfg.arrived_end / max(cfg.stage, 1u), 1u);
    let j = t & 31u;
    let sl = t >> 5u;
    let pr = pivot_row(j, per);
    var dxp = 0.0;
    var dpp = 0.0;
    var dxx = 0.0;
    for (var i = 0u; i < 64u; i = i + 1u) {
        let d = sl * 64u + i;
        let x = load_x(isq, row, d);
        let p = keys[(pr & 0x7FFFFu) * D4 + d];
        dxp = dxp + dot(x, p);
        dpp = dpp + dot(p, p);
        dxx = dxx + dot(x, x);
    }
    red[t * 3u] = dxp;
    red[t * 3u + 1u] = dpp;
    red[t * 3u + 2u] = dxx;
    workgroupBarrier();
    if (t < 32u) {
        var a = 0.0;
        var b = 0.0;
        var c = 0.0;
        for (var s = 0u; s < 8u; s = s + 1u) {
            let k = (s * 32u + t) * 3u;
            a = a + red[k];
            b = b + red[k + 1u];
            c = c + red[k + 2u];
        }
        let den = sqrt(b * c);
        var cs = 0.0;
        if (den > 0.0) {
            cs = a / den;
        }
        pc[t] = cs;
        if (t == 0u) {
            xnorm = sqrt(c);
        }
    }
    workgroupBarrier();
    if (t < 16u) {
        qp[t] = pc[2u * t] - pc[2u * t + 1u];
    }
    workgroupBarrier();
}

@compute @workgroup_size(256)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let w = wid.x;
    let begin = cfg.arrived_begin;
    let end = cfg.arrived_end;
    let per = end - begin;
    let r = begin + w;
    let cur = cfg.stage & 1u;
    let old = cur ^ 1u;

    if (cfg.pass_index == 0u) {
        compute_sketch(false, r, t);
        if (t < 16u && r < end) {
            index_f32[(r * 16u + t) & AMASK] = qp[t];
        }
        if (t == 0u && r < end) {
            index_f32[(NORM_BASE + r) & AMASK] = xnorm;
        }
        return;
    }

    if (cfg.pass_index == 1u) {
        if (t < 16u) {
            atomicStore(&cnt[t], 0u);
        }
        workgroupBarrier();
        let d = t >> 4u;
        let s = t & 15u;
        let pr = index_f32[(r * 16u + d) & AMASK];
        var c = 0u;
        for (var i = 0u; i < per; i = i + 16u) {
            let j = begin + i + s;
            if (j < end) {
                let pj = index_f32[(j * 16u + d) & AMASK];
                if (pj < pr || (pj == pr && j < r)) {
                    c = c + 1u;
                }
            }
        }
        atomicAdd(&cnt[d], c);
        workgroupBarrier();
        if (s == 0u && r < end) {
            let lr = atomicLoad(&cnt[d]);
            index_u32[(TMP_BASE + d * TMP_STRIDE + lr) & AMASK] = r;
            let ob = (old * NDIR + d) * BANK;
            var lo = 0u;
            var hi = begin;
            for (var it = 0u; it < 20u; it = it + 1u) {
                if (lo < hi) {
                    let mid = (lo + hi) >> 1u;
                    let mr = index_u32[(ob + mid) & AMASK];
                    let mp = index_f32[((mr & 0x7FFFFu) * 16u + d) & AMASK];
                    if (mp <= pr) {
                        lo = mid + 1u;
                    } else {
                        hi = mid;
                    }
                }
            }
            let nb = (cur * NDIR + d) * BANK;
            index_u32[(nb + lo + lr) & AMASK] = r;
        }
        return;
    }

    // Pass 2: old rows move up past the new rows below them.
    let d = t & 15u;
    let k = t >> 4u;
    let p = w + k * per;
    if (p < begin) {
        let ob = (old * NDIR + d) * BANK;
        let orow = index_u32[(ob + p) & AMASK];
        let op = index_f32[((orow & 0x7FFFFu) * 16u + d) & AMASK];
        let tb = TMP_BASE + d * TMP_STRIDE;
        var lo = 0u;
        var hi = per;
        for (var it = 0u; it < 20u; it = it + 1u) {
            if (lo < hi) {
                let mid = (lo + hi) >> 1u;
                let nr = index_u32[(tb + mid) & AMASK];
                let np = index_f32[((nr & 0x7FFFFu) * 16u + d) & AMASK];
                if (np < op) {
                    lo = mid + 1u;
                } else {
                    hi = mid;
                }
            }
        }
        index_u32[((cur * NDIR + d) * BANK + p + lo) & AMASK] = orow;
    }
}

@compute @workgroup_size(256)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let n = cfg.arrived_end;
    let cur = cfg.stage & 1u;

    compute_sketch(true, q, t);

    if (t < 16u) {
        let base = (cur * NDIR + t) * BANK;
        let qv = qp[t];
        var lo = 0u;
        var hi = n;
        for (var it = 0u; it < 20u; it = it + 1u) {
            if (lo < hi) {
                let mid = (lo + hi) >> 1u;
                let mr = index_u32[(base + mid) & AMASK];
                let mp = index_f32[((mr & 0x7FFFFu) * 16u + t) & AMASK];
                if (mp < qv) {
                    lo = mid + 1u;
                } else {
                    hi = mid;
                }
            }
        }
        var st = 0u;
        if (lo >= 32u) {
            st = lo - 32u;
        }
        if (st + 64u > n) {
            st = select(0u, n - 64u, n > 64u);
        }
        wpos[t] = st;
    }
    workgroupBarrier();

    // Gather 16 windows of 64, scored by sketch distance.
    for (var m = 0u; m < 4u; m = m + 1u) {
        let i = m * 256u + t;
        let d = i >> 6u;
        let o = i & 63u;
        let pos = wpos[d] + o;
        var row = PAD;
        var sc = BIG;
        if (pos < n) {
            row = index_u32[((cur * NDIR + d) * BANK + pos) & AMASK];
            if (row < n) {
                var acc = 0.0;
                for (var e = 0u; e < 16u; e = e + 1u) {
                    let df = index_f32[((row & 0x7FFFFu) * 16u + e) & AMASK] - qp[e];
                    acc = acc + df * df;
                }
                sc = acc;
            } else {
                row = PAD;
            }
        }
        sk_s[i] = sc;
        sk_r[i] = row;
    }
    workgroupBarrier();

    // Bitonic sort, ascending by (distance, row).
    for (var a = 1u; a <= 10u; a = a + 1u) {
        let kk = 1u << a;
        for (var b = 0u; b < a; b = b + 1u) {
            let jj = 1u << (a - 1u - b);
            for (var h = 0u; h < 2u; h = h + 1u) {
                let p = t + h * 256u;
                let i = (p / jj) * 2u * jj + (p % jj);
                let l = i + jj;
                let asc = (i & kk) == 0u;
                let si = sk_s[i & 1023u];
                let sl = sk_s[l & 1023u];
                let ri = sk_r[i & 1023u];
                let rl = sk_r[l & 1023u];
                let igt = si > sl || (si == sl && ri > rl);
                if (igt == asc) {
                    sk_s[i & 1023u] = sl;
                    sk_s[l & 1023u] = si;
                    sk_r[i & 1023u] = rl;
                    sk_r[l & 1023u] = ri;
                }
            }
            workgroupBarrier();
        }
    }

    // The best 256 by sketch, duplicates dropped (they sit adjacent).
    {
        var row = sk_r[t];
        if (t > 0u) {
            if (sk_r[t - 1u] == row) {
                row = PAD;
            }
        }
        ex_r[t] = row;
        ex_s[t] = BIG;
    }
    workgroupBarrier();

    // Exact cosine: 16 threads a candidate, 16 candidates a round.
    let g = t >> 4u;
    let s = t & 15u;
    let qn = xnorm;
    for (var round = 0u; round < 16u; round = round + 1u) {
        let c = round * 16u + g;
        let row = ex_r[c];
        var part = 0.0;
        if (row != PAD) {
            for (var i = 0u; i < 32u; i = i + 1u) {
                let d = i * 16u + s;
                part = part + dot(keys[(row & 0x7FFFFu) * D4 + d], queries[(q & 0xFFFFu) * D4 + d]);
            }
        }
        red[t] = part;
        workgroupBarrier();
        if (s == 0u) {
            var sum = 0.0;
            for (var e = 0u; e < 16u; e = e + 1u) {
                sum = sum + red[g * 16u + e];
            }
            var key = BIG;
            if (row != PAD) {
                let rn = index_f32[(NORM_BASE + (row & 0x7FFFFu)) & AMASK];
                let den = rn * qn;
                if (den > 0.0) {
                    key = -(sum / den);
                }
            }
            ex_s[c] = key;
        }
        workgroupBarrier();
    }

    // Bitonic sort of 256, ascending by (-cosine, row).
    for (var a = 1u; a <= 8u; a = a + 1u) {
        let kk = 1u << a;
        for (var b = 0u; b < a; b = b + 1u) {
            let jj = 1u << (a - 1u - b);
            if (t < 128u) {
                let p = t;
                let i = (p / jj) * 2u * jj + (p % jj);
                let l = i + jj;
                let asc = (i & kk) == 0u;
                let si = ex_s[i & 255u];
                let sl = ex_s[l & 255u];
                let ri = ex_r[i & 255u];
                let rl = ex_r[l & 255u];
                let igt = si > sl || (si == sl && ri > rl);
                if (igt == asc) {
                    ex_s[i & 255u] = sl;
                    ex_s[l & 255u] = si;
                    ex_r[i & 255u] = rl;
                    ex_r[l & 255u] = ri;
                }
            }
            workgroupBarrier();
        }
    }

    if (t < C_MAX && q < cfg.n_queries) {
        var out = PAD;
        let row = ex_r[t];
        if (ex_s[t] < BIG && row < n) {
            out = row;
        }
        cands[(q * C_MAX + t) & 0xFFFFFFu] = out;
    }
}
