// passes 14
// v24 seed design, population seed 1, launch kernel 22: a k-means tree that
// grows by splitting its leaves, searched by leaf centres with a row budget.
//
// The tree. Stage 1, pass 0 picks 64 rows of the first microbatch, evenly
// spaced, as unit-length root centres. A centre owns a leaf bucket that holds
// up to 4,096 member rows.
//
// Pass 0 of every stage stores each arriving row's inverse norm.
// Pass 1 adds each arriving row to its nearest leaf centre.
// Passes 2 to 13 split leaves. Each pass, every leaf with more than 40 rows
// splits once, by farthest-pair seeding:
//   A = the member least like the leaf's centre,
//   B = the member least like A.
// Then the members are split in place between A and B. The leaf keeps the A
// side and a newly allocated leaf takes the B side. Both centres are then
// recomputed as the normalised mean of their members' unit keys.
//
// New leaf ids come from a counter for each (stage, pass). A pass only splits
// leaves that existed before the pass began, so leaves made in the current
// pass are never read in it.
//
// Search scores every leaf centre against the query. It takes the leaves in
// score order until about 768 rows are queued, or 32 leaves. It scores those
// rows exactly by cosine and writes the best 48 by rank, so each slot has one
// writer.

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const DIM: u32 = 2048u;
const MAXC: u32 = 1024u;
const CAPH: u32 = 4096u;
const K0: u32 = 64u;
const SOFT: u32 = 40u;
const ALLOC_BASE: u32 = 0u;
const CNT_BASE: u32 = 256u;
const MEM_BASE: u32 = 2048u;
const CEN_BASE: u32 = 0u;
const RINV_BASE: u32 = 2097152u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const BIG: f32 = 3.0e38;
const CK: u32 = 48u;
const BUDGET: u32 = 768u;
const MSCAN: u32 = 1024u;
const NPROBE: u32 = 32u;

var<workgroup> wa: array<f32, 2048>;
var<workgroup> wrow: array<u32, 1024>;
var<workgroup> red_s: array<f32, 256>;
var<workgroup> red_i: array<u32, 256>;
var<workgroup> wprobe: array<u32, 32>;
var<workgroup> wpofs: array<u32, 33>;
var<workgroup> wcnt: array<atomic<u32>, 2>;
var<workgroup> wu0: u32;
var<workgroup> wu1: u32;
var<workgroup> wu2: u32;

fn key4(r: u32, d: u32) -> vec4<f32> {
    return keys[(r & 0x7FFFu) * D4 + (d & 511u)];
}

fn qry4(qb: u32, d: u32) -> vec4<f32> {
    return queries[qb + (d & 511u)];
}

fn cen4(c: u32, d: u32) -> vec4<f32> {
    let b = CEN_BASE + (c & 1023u) * DIM + (d & 511u) * 4u;
    return vec4<f32>(index_f32[b], index_f32[b + 1u], index_f32[b + 2u], index_f32[b + 3u]);
}

fn set_cen4(c: u32, d: u32, v: vec4<f32>) {
    let b = CEN_BASE + (c & 1023u) * DIM + (d & 511u) * 4u;
    index_f32[b] = v.x;
    index_f32[b + 1u] = v.y;
    index_f32[b + 2u] = v.z;
    index_f32[b + 3u] = v.w;
}

fn rinv(r: u32) -> f32 {
    return index_f32[RINV_BASE + (r & 0x7FFFu)];
}

fn cnt_idx(c: u32) -> u32 {
    return CNT_BASE + (c & 1023u);
}

fn mem_idx(c: u32, s: u32) -> u32 {
    return MEM_BASE + (c & 1023u) * CAPH + (s & 4095u);
}

fn dot_rr(a: u32, b: u32) -> f32 {
    var s = 0.0;
    for (var d = 0u; d < D4; d = d + 1u) {
        s = s + dot(key4(a, d), key4(b, d));
    }
    return s;
}

fn dot_rc(r: u32, c: u32) -> f32 {
    var s = 0.0;
    for (var d = 0u; d < D4; d = d + 1u) {
        s = s + dot(key4(r, d), cen4(c, d));
    }
    return s;
}

// The leaves that exist: the 64 roots plus every id allocated in the
// (stage, pass) slots before lim, capped at MAXC.
fn n_centres(lim: u32) -> u32 {
    var s = K0;
    for (var i = 0u; i < 128u; i = i + 1u) {
        if (i < lim) {
            s = s + atomicLoad(&index_u32[ALLOC_BASE + i]);
        }
    }
    return min(s, MAXC);
}

fn reduce_arg(t: u32, want_min: bool) {
    for (var k = 0u; k < 8u; k = k + 1u) {
        let s = 128u >> k;
        workgroupBarrier();
        if (t < s) {
            let a = red_s[t];
            let b = red_s[t + s];
            var take = b > a;
            if (want_min) {
                take = b < a;
            }
            if (take) {
                red_s[t] = b;
                red_i[t] = red_i[t + s];
            }
        }
    }
    workgroupBarrier();
}

fn reduce_sum(t: u32) {
    for (var k = 0u; k < 8u; k = k + 1u) {
        let s = 128u >> k;
        workgroupBarrier();
        if (t < s) {
            red_s[t] = red_s[t] + red_s[t + s];
        }
    }
    workgroupBarrier();
}

fn ingest_norm(t: u32, w: u32, r: u32, npg: u32) {
    let a = key4(r, t);
    let b = key4(r, t + 256u);
    red_s[t] = dot(a, a) + dot(b, b);
    reduce_sum(t);
    let n2 = red_s[0];
    var inv = 0.0;
    if (n2 > 0.0) {
        inv = inverseSqrt(n2);
    }
    if (t == 0u && r < cfg.arrived_end) {
        index_f32[RINV_BASE + (r & 0x7FFFu)] = inv;
    }
    if (cfg.stage == 1u) {
        let step = max(npg / K0, 1u);
        if (w % step == 0u && w / step < K0) {
            let c = w / step;
            set_cen4(c, t, a * inv);
            set_cen4(c, t + 256u, b * inv);
        }
    }
    workgroupBarrier();
}

fn ingest_assign(t: u32, r: u32) {
    let a = key4(r, t);
    let b = key4(r, t + 256u);
    wa[t * 4u] = a.x;
    wa[t * 4u + 1u] = a.y;
    wa[t * 4u + 2u] = a.z;
    wa[t * 4u + 3u] = a.w;
    let t2 = (t + 256u) * 4u;
    wa[t2] = b.x;
    wa[t2 + 1u] = b.y;
    wa[t2 + 2u] = b.z;
    wa[t2 + 3u] = b.w;
    if (t == 0u) {
        wu0 = n_centres((cfg.stage - 1u) * 16u + 1u);
    }
    let nc = workgroupUniformLoad(&wu0);
    var bs = NONE;
    var bc = PAD;
    for (var i = 0u; i < MAXC; i = i + 256u) {
        let c = i + t;
        if (c < nc) {
            var s = 0.0;
            for (var d = 0u; d < D4; d = d + 1u) {
                let kv = vec4<f32>(wa[d * 4u], wa[d * 4u + 1u], wa[d * 4u + 2u], wa[d * 4u + 3u]);
                s = s + dot(kv, cen4(c, d));
            }
            if (s > bs) {
                bs = s;
                bc = c;
            }
        }
    }
    red_s[t] = bs;
    red_i[t] = bc;
    reduce_arg(t, false);
    if (t == 0u && r < cfg.arrived_end) {
        let c = red_i[0];
        if (c < nc) {
            let slot = atomicAdd(&index_u32[cnt_idx(c)], 1u);
            if (slot < CAPH) {
                atomicStore(&index_u32[mem_idx(c, slot)], r);
            }
        }
    }
    workgroupBarrier();
}

fn recentre(t: u32, cc: u32, m: u32) {
    var a0 = vec4<f32>(0.0);
    var a1 = vec4<f32>(0.0);
    for (var i = 0u; i < CAPH; i = i + 1u) {
        if (i >= m) {
            break;
        }
        let row = atomicLoad(&index_u32[mem_idx(cc, i)]);
        let iv = rinv(row);
        a0 = a0 + key4(row, t) * iv;
        a1 = a1 + key4(row, t + 256u) * iv;
    }
    red_s[t] = dot(a0, a0) + dot(a1, a1);
    reduce_sum(t);
    let n2 = red_s[0];
    var sc = 0.0;
    if (n2 > 0.0) {
        sc = inverseSqrt(n2);
    }
    set_cen4(cc, t, a0 * sc);
    set_cen4(cc, t + 256u, a1 * sc);
    workgroupBarrier();
}

fn split_one(t: u32, c: u32, n: u32, base: u32, aslot: u32) {
    // A: the member least like the leaf's centre.
    var bs = BIG;
    var br = PAD;
    for (var i = 0u; i < CAPH; i = i + 256u) {
        if (i >= n) {
            break;
        }
        let j = i + t;
        if (j < n) {
            let row = atomicLoad(&index_u32[mem_idx(c, j)]);
            let s = dot_rc(row, c) * rinv(row);
            if (s < bs) {
                bs = s;
                br = row;
            }
        }
    }
    red_s[t] = bs;
    red_i[t] = br;
    reduce_arg(t, true);
    let ra = red_i[0];
    workgroupBarrier();
    let ia = rinv(ra);
    // B: the member least like A.
    bs = BIG;
    br = PAD;
    for (var i = 0u; i < CAPH; i = i + 256u) {
        if (i >= n) {
            break;
        }
        let j = i + t;
        if (j < n) {
            let row = atomicLoad(&index_u32[mem_idx(c, j)]);
            let s = dot_rr(row, ra) * rinv(row) * ia;
            if (s < bs) {
                bs = s;
                br = row;
            }
        }
    }
    red_s[t] = bs;
    red_i[t] = br;
    reduce_arg(t, true);
    let rb = red_i[0];
    let gap = red_s[0];
    workgroupBarrier();
    if (t == 0u) {
        var go = 0u;
        if (ra != PAD && rb != PAD && ra != rb && gap < 0.9999) {
            let k = atomicAdd(&index_u32[aslot], 1u);
            let id = base + k;
            if (id < MAXC) {
                go = id;
            }
        }
        wu2 = go;
        atomicStore(&wcnt[0], 0u);
        atomicStore(&wcnt[1], 0u);
    }
    let id = workgroupUniformLoad(&wu2);
    if (id != 0u) {
        let ib = rinv(rb);
        // Split in place, in chunks: a chunk's reads all finish before any of
        // its writes, and the A side's write position never passes the
        // chunk's end.
        for (var i = 0u; i < CAPH; i = i + 256u) {
            if (i >= n) {
                break;
            }
            let j = i + t;
            var row = PAD;
            if (j < n) {
                row = atomicLoad(&index_u32[mem_idx(c, j)]);
            }
            storageBarrier();
            workgroupBarrier();
            if (j < n) {
                var sa = 0.0;
                var sb = 0.0;
                for (var d = 0u; d < D4; d = d + 1u) {
                    let kv = key4(row, d);
                    sa = sa + dot(kv, key4(ra, d));
                    sb = sb + dot(kv, key4(rb, d));
                }
                sa = sa * ia;
                sb = sb * ib;
                if (sa >= sb) {
                    let pos = atomicAdd(&wcnt[0], 1u);
                    atomicStore(&index_u32[mem_idx(c, pos)], row);
                } else {
                    let pos = atomicAdd(&wcnt[1], 1u);
                    atomicStore(&index_u32[mem_idx(id, pos)], row);
                }
            }
            storageBarrier();
            workgroupBarrier();
        }
        let na = atomicLoad(&wcnt[0]);
        let nb = atomicLoad(&wcnt[1]);
        if (t == 0u) {
            atomicStore(&index_u32[cnt_idx(c)], na);
            atomicStore(&index_u32[cnt_idx(id)], nb);
        }
        recentre(t, c, na);
        recentre(t, id, nb);
    }
    workgroupBarrier();
}

fn ingest_split(t: u32, w: u32, npg: u32, p: u32) {
    let slot = (cfg.stage - 1u) * 16u + p;
    if (t == 0u) {
        wu0 = n_centres(slot);
    }
    let base = workgroupUniformLoad(&wu0);
    let aslot = ALLOC_BASE + (slot & 127u);
    for (var k = 0u; k < 4u; k = k + 1u) {
        workgroupBarrier();
        let c = k * npg + w;
        if (t == 0u) {
            var n = 0u;
            if (c < base) {
                n = min(atomicLoad(&index_u32[cnt_idx(c)]), CAPH);
            }
            if (n <= SOFT) {
                n = 0u;
            }
            wu1 = n;
        }
        let n = workgroupUniformLoad(&wu1);
        if (n > 0u) {
            split_one(t, c, n, base, aslot);
        }
    }
}

@compute @workgroup_size(256)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let w = wid.x;
    let r = cfg.arrived_begin + w;
    let npg = max(cfg.arrived_end - cfg.arrived_begin, 1u);
    let p = cfg.pass_index;
    if (p == 0u) {
        ingest_norm(t, w, r, npg);
    } else if (p == 1u) {
        ingest_assign(t, r);
    } else {
        ingest_split(t, w, npg, p);
    }
}

@compute @workgroup_size(256)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let valid = wid.x < cfg.n_queries;
    let q = min(wid.x, max(cfg.n_queries, 1u) - 1u);
    let qb = (q & 0x3FFFu) * D4;
    if (t == 0u) {
        wu0 = n_centres(128u);
    }
    let nc = workgroupUniformLoad(&wu0);
    // Score every non-empty leaf centre.
    for (var i = 0u; i < MAXC; i = i + 256u) {
        let c = i + t;
        var s = NONE;
        if (c < nc) {
            if (atomicLoad(&index_u32[cnt_idx(c)]) > 0u) {
                var acc = 0.0;
                for (var d = 0u; d < D4; d = d + 1u) {
                    acc = acc + dot(qry4(qb, d), cen4(c, d));
                }
                s = acc;
            }
        }
        wa[c & 1023u] = s;
    }
    // Take leaves in score order until the row budget is met.
    var np = 0u;
    var tot = 0u;
    var done = false;
    for (var k = 0u; k < NPROBE; k = k + 1u) {
        workgroupBarrier();
        var bs = NONE;
        var bi = PAD;
        for (var i = 0u; i < MAXC; i = i + 256u) {
            let c = i + t;
            let s = wa[c & 1023u];
            if (s > bs) {
                bs = s;
                bi = c;
            }
        }
        red_s[t] = bs;
        red_i[t] = bi;
        reduce_arg(t, false);
        if (t == 0u) {
            let c = red_i[0];
            if (!done && c != PAD && red_s[0] > NONE) {
                wa[c & 1023u] = NONE;
                let m = min(atomicLoad(&index_u32[cnt_idx(c)]), CAPH);
                wprobe[np & 31u] = c;
                wpofs[np & 31u] = tot;
                tot = tot + m;
                np = np + 1u;
                if (tot >= BUDGET) {
                    done = true;
                }
            } else {
                done = true;
            }
        }
    }
    if (t == 0u) {
        wpofs[min(np, 32u)] = tot;
        wu1 = min(tot, MSCAN);
        wu2 = np;
    }
    let m = workgroupUniformLoad(&wu1);
    let npb = workgroupUniformLoad(&wu2);
    // Score the queued rows exactly.
    for (var i = 0u; i < MSCAN; i = i + 256u) {
        let j = i + t;
        var s = NONE;
        var row = PAD;
        if (j < m) {
            var b = 0u;
            for (var k = 0u; k < NPROBE; k = k + 1u) {
                if (k < npb && j >= wpofs[k]) {
                    b = k;
                }
            }
            let c = wprobe[b & 31u];
            let off = j - wpofs[b & 31u];
            row = atomicLoad(&index_u32[mem_idx(c, off)]);
            if (row < cfg.arrived_end) {
                var acc = 0.0;
                for (var d = 0u; d < D4; d = d + 1u) {
                    acc = acc + dot(qry4(qb, d), key4(row, d));
                }
                s = acc * rinv(row);
            } else {
                row = PAD;
            }
        }
        wa[j & 1023u] = s;
        wrow[j & 1023u] = row;
    }
    workgroupBarrier();
    // Rank select: each entry counts how many entries beat it; ranks below
    // CK write their own slot.
    if (valid) {
        for (var i = 0u; i < MSCAN; i = i + 256u) {
            let j = i + t;
            if (j < m) {
                let s = wa[j & 1023u];
                let row = wrow[j & 1023u];
                if (row != PAD) {
                    var rank = 0u;
                    for (var k = 0u; k < MSCAN; k = k + 1u) {
                        if (k >= m) {
                            break;
                        }
                        let o = wa[k];
                        if (o > s || (o == s && k < j)) {
                            rank = rank + 1u;
                        }
                    }
                    if (rank < CK) {
                        cands[q * 64u + rank] = row;
                    }
                }
            }
        }
    }
}
