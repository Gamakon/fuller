// passes 1

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const NP: u32 = 40u;
const CAP: u32 = 64u;
const SLOT0: u32 = 4096u;

var<workgroup> red: array<f32, 1280>;
var<workgroup> wsum: array<f32, 40>;
var<workgroup> wprobe: array<u32, 16>;
var<workgroup> wrow: array<u32, 1024>;
var<workgroup> seen: array<atomic<u32>, 1024>;

fn hs(d: u32, j: u32) -> f32 {
    var x = (d * 40u + j) * 747796405u + 2891336453u;
    x = ((x >> ((x >> 28u) + 4u)) ^ x) * 277803737u;
    x = (x >> 22u) ^ x;
    return select(-1.0, 1.0, (x & 1u) == 1u);
}

@compute @workgroup_size(32)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let tid = lid.x;
    let row = cfg.arrived_begin + wid.x;
    var acc: array<f32, 40>;
    for (var j = 0u; j < NP; j = j + 1u) { acc[j] = 0.0; }
    for (var i = 0u; i < 512u; i += 32u) {
        let d4 = i + tid;
        if (d4 < 512u) {
            let v = keys[(row & 0x7FFFFu) * 512u + d4];
            for (var j = 0u; j < NP; j = j + 1u) {
                let b = d4 * 4u;
                acc[j] = acc[j] + hs(b, j) * v.x + hs(b + 1u, j) * v.y + hs(b + 2u, j) * v.z + hs(b + 3u, j) * v.w;
            }
        }
    }
    for (var j = 0u; j < NP; j = j + 1u) { red[tid * 40u + j] = acc[j]; }
    workgroupBarrier();
    for (var k = 0u; k < 2u; k += 1u) {
        let j = tid + k * 32u;
        if (j < NP) {
            var s = 0.0;
            for (var u = 0u; u < 32u; u += 1u) { s = s + red[u * 40u + j]; }
            wsum[j] = s;
        }
    }
    workgroupBarrier();
    if (tid < 4u) {
        var code = 0u;
        for (var b = 0u; b < 10u; b += 1u) {
            if (wsum[tid * 10u + b] > 0.0) { code = code | (1u << b); }
        }
        let bucket = tid * 1024u + code;
        let slot = atomicAdd(&index_u32[bucket & 4095u], 1u);
        if (slot < CAP) {
            atomicStore(&index_u32[(SLOT0 + (bucket & 4095u) * CAP + slot) & 0x7FFFFFu], row);
        }
    }
}

@compute @workgroup_size(32)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let tid = lid.x;
    let q = wid.x & 0xFFFFu;
    var acc: array<f32, 40>;
    for (var j = 0u; j < NP; j = j + 1u) { acc[j] = 0.0; }
    for (var i = 0u; i < 512u; i += 32u) {
        let d4 = i + tid;
        if (d4 < 512u) {
            let v = queries[q * 512u + d4];
            for (var j = 0u; j < NP; j = j + 1u) {
                let b = d4 * 4u;
                acc[j] = acc[j] + hs(b, j) * v.x + hs(b + 1u, j) * v.y + hs(b + 2u, j) * v.z + hs(b + 3u, j) * v.w;
            }
        }
    }
    for (var j = 0u; j < NP; j = j + 1u) { red[tid * 40u + j] = acc[j]; }
    for (var i = 0u; i < 1024u; i += 32u) {
        atomicStore(&seen[(i + tid) & 1023u], 0u);
    }
    workgroupBarrier();
    for (var k = 0u; k < 2u; k += 1u) {
        let j = tid + k * 32u;
        if (j < NP) {
            var s = 0.0;
            for (var u = 0u; u < 32u; u += 1u) { s = s + red[u * 40u + j]; }
            wsum[j] = s;
        }
    }
    workgroupBarrier();
    if (tid < 4u) {
        var code = 0u;
        var m1 = 3.0e38;
        var m2 = 3.0e38;
        var b1 = 0u;
        var b2 = 1u;
        for (var b = 0u; b < 10u; b += 1u) {
            let s = wsum[tid * 10u + b];
            if (s > 0.0) { code = code | (1u << b); }
            let a = abs(s);
            if (a < m1) {
                m2 = m1; b2 = b1;
                m1 = a; b1 = b;
            } else if (a < m2) {
                m2 = a; b2 = b;
            }
        }
        let base = tid * 1024u;
        wprobe[tid * 4u] = base + code;
        wprobe[tid * 4u + 1u] = base + (code ^ (1u << b1));
        wprobe[tid * 4u + 2u] = base + (code ^ (1u << b2));
        wprobe[tid * 4u + 3u] = base + (code ^ (1u << b1) ^ (1u << b2));
    }
    workgroupBarrier();
    for (var p = 0u; p < 16u; p += 1u) {
        let bucket = wprobe[p] & 4095u;
        let cnt = min(atomicLoad(&index_u32[bucket]), CAP);
        for (var s = 0u; s < CAP; s += 32u) {
            let s2 = s + tid;
            let i = p * 64u + s2;
            var r = PAD;
            if (s2 < cnt) {
                let cr = atomicLoad(&index_u32[(SLOT0 + bucket * CAP + s2) & 0x7FFFFFu]);
                if (cr < cfg.arrived_end) {
                    let bit = 1u << (cr & 31u);
                    let old = atomicOr(&seen[(cr >> 5u) & 1023u], bit);
                    if ((old & bit) == 0u) { r = cr; }
                }
            }
            wrow[i] = r;
        }
    }
    workgroupBarrier();
    for (var i = 0u; i < 1024u; i += 32u) {
        let c = i + tid;
        let r = wrow[c];
        var score = NONE;
        if (r != PAD) {
            var s = 0.0;
            var kn = 0.0;
            var qn = 0.0;
            for (var d = 0u; d < 512u; d += 1u) {
                let k = keys[(r & 0x7FFFFu) * 512u + d];
                let qv = queries[q * 512u + d];
                s = s + dot(k, qv);
                kn = kn + dot(k, k);
                qn = qn + dot(qv, qv);
            }
            let den = sqrt(qn * kn);
            if (den > 0.0) { score = s / den; }
        }
        red[c] = score;
    }
    workgroupBarrier();
    for (var i = 0u; i < 1024u; i += 32u) {
        let c = i + tid;
        let r = wrow[c];
        if (r != PAD) {
            let sc = red[c];
            var rank = 0u;
            for (var j = 0u; j < 1024u; j += 1u) {
                let o = red[j];
                if (o > sc || (o == sc && j < c)) { rank = rank + 1u; }
            }
            if (rank < 64u) {
                cands[q * 64u + rank] = r;
            }
        }
    }
}
