// passes 2

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const PAD: u32 = 0xFFFFFFFFu;
const NEG: f32 = -1.0e30;
// arena layout (words)
const CC: u32 = 0u;          // 64 cell counts
const CH: u32 = 64u;         // 4096 child counts
const REPS: u32 = 4160u;     // 4096 rep row ids (+1)
const BKT: u32 = 8256u;      // 4096 * 64 bucket slots (row+1)
const RCELL: u32 = 270400u;  // per-row cell

var<workgroup> wsim: array<f32, 64>;
var<workgroup> wpick: u32;
var<workgroup> tcell: array<u32, 4>;
var<workgroup> tch: array<u32, 32>;
var<workgroup> sc: array<f32, 2048>;

fn kdot_k(r: u32, other_is_query: bool, q: u32) -> vec2<f32> {
    var s = 0.0;
    var n = 0.0;
    let base = (r & 0x7FFFFu) * D4;
    let qb = (q & 0xFFFFu) * D4;
    for (var d = 0u; d < D4; d = d + 1u) {
        let k = keys[base + d];
        n = n + dot(k, k);
        if (other_is_query) {
            s = s + dot(k, queries[qb + d]);
        }
    }
    return vec2<f32>(s, n);
}

fn rowdot(r: u32, c: u32) -> f32 {
    var s = 0.0;
    var n = 0.0;
    let rb = (r & 0x7FFFFu) * D4;
    let cb = (c & 0x7FFFFu) * D4;
    for (var d = 0u; d < D4; d = d + 1u) {
        let a = keys[rb + d];
        let b = keys[cb + d];
        s = s + dot(a, b);
        n = n + dot(b, b);
    }
    if (n <= 0.0) {
        return NEG;
    }
    return s / sqrt(n);
}

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = cfg.arrived_begin + wid.x;
    let per = cfg.arrived_end - cfg.arrived_begin;
    let stride = max(per / 64u, 1u);
    if (cfg.pass_index == 0u) {
        wsim[t] = rowdot(row, t * stride);
        workgroupBarrier();
        if (t == 0u) {
            var best = NEG;
            var bc = 0u;
            for (var c = 0u; c < 64u; c = c + 1u) {
                if (wsim[c] > best) {
                    best = wsim[c];
                    bc = c;
                }
            }
            let k = atomicAdd(&index_u32[(CC + bc) & 0xFFFFFu], 1u);
            if (k < 64u) {
                atomicStore(&index_u32[(REPS + bc * 64u + k) & 0xFFFFFu], row + 1u);
            }
            atomicStore(&index_u32[(RCELL + (row & 0x7FFFFu)) & 0x7FFFFFu], bc);
        }
    } else {
        let cell = atomicLoad(&index_u32[(RCELL + (row & 0x7FFFFu)) & 0x7FFFFFu]) & 63u;
        let nrep = min(atomicLoad(&index_u32[(CC + cell) & 0xFFFFFu]), 64u);
        var s = NEG;
        if (t < nrep) {
            let rep = atomicLoad(&index_u32[(REPS + cell * 64u + t) & 0xFFFFFu]);
            if (rep != 0u) {
                s = rowdot(row, rep - 1u);
            }
        }
        wsim[t] = s;
        workgroupBarrier();
        if (t == 0u) {
            for (var tr = 0u; tr < 4u; tr = tr + 1u) {
                var best = NEG;
                var bc = 64u;
                for (var c = 0u; c < 64u; c = c + 1u) {
                    if (wsim[c] > best) {
                        best = wsim[c];
                        bc = c;
                    }
                }
                if (bc < 64u) {
                    let ch = cell * 64u + bc;
                    let slot = atomicAdd(&index_u32[(CH + ch) & 0xFFFFFu], 1u);
                    if (slot < 64u) {
                        atomicStore(&index_u32[(BKT + ch * 64u + slot) & 0x7FFFFFu], row + 1u);
                        break;
                    }
                    wsim[bc] = NEG;
                }
            }
        }
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let per = max(cfg.arrived_end / max(cfg.stage, 1u), 1u);
    let stride = max(per / 64u, 1u);
    // top cells
    {
        let v = kdot_k(t * stride, true, q);
        var s = NEG;
        if (v.y > 0.0) {
            s = v.x / sqrt(v.y);
        }
        wsim[t] = s;
    }
    workgroupBarrier();
    if (t == 0u) {
        for (var i = 0u; i < 4u; i = i + 1u) {
            var best = NEG;
            var bc = PAD;
            for (var c = 0u; c < 64u; c = c + 1u) {
                if (wsim[c] > best) {
                    best = wsim[c];
                    bc = c;
                }
            }
            tcell[i] = bc;
            if (bc != PAD) {
                wsim[bc] = NEG;
            }
        }
    }
    workgroupBarrier();
    for (var ci = 0u; ci < 4u; ci = ci + 1u) {
        let cell = tcell[ci];
        var s = NEG;
        if (cell != PAD) {
            let nrep = min(atomicLoad(&index_u32[(CC + cell) & 0xFFFFFu]), 64u);
            if (t < nrep) {
                let rep = atomicLoad(&index_u32[(REPS + cell * 64u + t) & 0xFFFFFu]);
                if (rep != 0u) {
                    let v = kdot_k(rep - 1u, true, q);
                    if (v.y > 0.0) {
                        s = v.x / sqrt(v.y);
                    }
                }
            }
        }
        wsim[t] = s;
        workgroupBarrier();
        if (t == 0u) {
            for (var i = 0u; i < 8u; i = i + 1u) {
                var best = NEG;
                var bc = PAD;
                for (var c = 0u; c < 64u; c = c + 1u) {
                    if (wsim[c] > best) {
                        best = wsim[c];
                        bc = c;
                    }
                }
                if (bc != PAD && cell != PAD) {
                    tch[ci * 8u + i] = cell * 64u + bc;
                    wsim[bc] = NEG;
                } else {
                    tch[ci * 8u + i] = PAD;
                }
            }
        }
        workgroupBarrier();
    }
    // score candidates
    for (var j = 0u; j < 32u; j = j + 1u) {
        let tc = tch[j];
        var s = NEG;
        if (tc != PAD) {
            let cnt = min(atomicLoad(&index_u32[(CH + tc) & 0xFFFFFu]), 64u);
            if (t < cnt) {
                let r1 = atomicLoad(&index_u32[(BKT + tc * 64u + t) & 0x7FFFFFu]);
                if (r1 != 0u) {
                    let v = kdot_k(r1 - 1u, true, q);
                    if (v.y > 0.0) {
                        s = v.x / sqrt(v.y);
                    }
                }
            }
        }
        sc[j * 64u + t] = s;
    }
    workgroupBarrier();
    for (var j = 0u; j < 32u; j = j + 1u) {
        let a = j * 64u + t;
        let s = sc[a];
        if (s > -1.0e29) {
            var rank = 0u;
            for (var b = 0u; b < 2048u; b = b + 1u) {
                let o = sc[b];
                if (o > s || (o == s && b < a)) {
                    rank = rank + 1u;
                }
            }
            if (rank < 64u && q < cfg.n_queries) {
                let tc = tch[j];
                let r1 = atomicLoad(&index_u32[(BKT + tc * 64u + t) & 0x7FFFFFu]);
                cands[q * 64u + rank] = r1 - 1u;
            }
        }
    }
}
