// passes 2
struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const NC: u32 = 128u;
const CAP: u32 = 512u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const CNT_BASE: u32 = 1024u;
const MEM_BASE: u32 = 4096u;
const CEN_BASE: u32 = 16u;
const NPROBE: u32 = 8u;
const MAXE: u32 = 1024u;

var<workgroup> red: array<f32, 64>;
var<workgroup> wsc: array<f32, 128>;
var<workgroup> sel: array<u32, 8>;
var<workgroup> erow: array<u32, 1024>;
var<workgroup> escore: array<f32, 1024>;

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = cfg.arrived_begin + wid.x;
    let rbase = (row & 0x7FFFFu) * D4;
    let per = max(1u, cfg.arrived_end - cfg.arrived_begin);
    let step = max(1u, per / NC);
    let idx = wid.x;
    if (cfg.pass_index == 0u) {
        let isc = (cfg.stage == 1u) && (idx % step == 0u) && (idx / step < NC);
        var part = 0.0;
        if (isc) {
            for (var d = 0u; d < D4; d += 64u) {
                let j = d + t;
                if (j < D4) {
                    let v = keys[rbase + j];
                    part += dot(v, v);
                }
            }
        }
        red[t] = part;
        workgroupBarrier();
        for (var k = 0u; k < 6u; k += 1u) {
            let s = 32u >> k;
            if (t < s) {
                red[t] = red[t] + red[t + s];
            }
            workgroupBarrier();
        }
        if (isc && t == 0u) {
            let c = (idx / step) & 127u;
            atomicStore(&index_u32[CEN_BASE + c], row);
            index_f32[c] = sqrt(red[0]);
        }
    } else {
        for (var h = 0u; h < 2u; h += 1u) {
            let c = t + h * 64u;
            let crow = atomicLoad(&index_u32[(CEN_BASE + c) & 0x7FFFFFu]);
            let cn = index_f32[c & 127u];
            var s = 0.0;
            for (var d = 0u; d < D4; d += 1u) {
                s += dot(keys[rbase + d], keys[(crow & 0x7FFFFu) * D4 + d]);
            }
            var sc = NONE;
            if (cn > 0.0) {
                sc = s / cn;
            }
            wsc[c & 127u] = sc;
        }
        workgroupBarrier();
        if (t == 0u) {
            var b0 = 0u;
            var s0 = NONE;
            for (var c = 0u; c < NC; c += 1u) {
                if (wsc[c] > s0) {
                    s0 = wsc[c];
                    b0 = c;
                }
            }
            var b1 = 0u;
            var s1 = NONE;
            for (var c = 0u; c < NC; c += 1u) {
                if (c != b0 && wsc[c] > s1) {
                    s1 = wsc[c];
                    b1 = c;
                }
            }
            if (s0 > NONE) {
                let slot = atomicAdd(&index_u32[CNT_BASE + b0], 1u);
                if (slot < CAP) {
                    atomicStore(&index_u32[(MEM_BASE + b0 * CAP + slot) & 0x7FFFFFu], row + 1u);
                }
            }
            if (s1 > NONE) {
                let slot = atomicAdd(&index_u32[CNT_BASE + b1], 1u);
                if (slot < CAP) {
                    atomicStore(&index_u32[(MEM_BASE + b1 * CAP + slot) & 0x7FFFFFu], row + 1u);
                }
            }
        }
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let qbase = (q & 0xFFFFu) * D4;
    let valid = q < cfg.n_queries;
    for (var k = 0u; k < 16u; k += 1u) {
        erow[t + k * 64u] = PAD;
        escore[t + k * 64u] = NONE;
    }
    for (var h = 0u; h < 2u; h += 1u) {
        let c = (t + h * 64u) & 127u;
        let crow = atomicLoad(&index_u32[CEN_BASE + c]);
        let cn = index_f32[c];
        var s = 0.0;
        if (valid) {
            for (var d = 0u; d < D4; d += 1u) {
                s += dot(queries[qbase + d], keys[(crow & 0x7FFFFu) * D4 + d]);
            }
        }
        var sc = NONE;
        if (cn > 0.0) {
            sc = s / cn;
        }
        wsc[c] = sc;
    }
    workgroupBarrier();
    if (t == 0u && valid) {
        var n = 0u;
        for (var p = 0u; p < NPROBE; p += 1u) {
            var bb = 0u;
            var bs = NONE;
            for (var c = 0u; c < NC; c += 1u) {
                if (wsc[c] > bs) {
                    bs = wsc[c];
                    bb = c;
                }
            }
            if (bs > NONE) {
                wsc[bb] = NONE;
                let cnt = min(atomicLoad(&index_u32[CNT_BASE + bb]), CAP);
                for (var i = 0u; i < CAP; i += 1u) {
                    if (i < cnt && n < MAXE) {
                        let m = atomicLoad(&index_u32[(MEM_BASE + bb * CAP + i) & 0x7FFFFFu]);
                        if (m != 0u) {
                            erow[n] = m - 1u;
                            n += 1u;
                        }
                    }
                }
            }
        }
    }
    workgroupBarrier();
    for (var k = 0u; k < 16u; k += 1u) {
        let i = t + k * 64u;
        let r = erow[i];
        if (r != PAD) {
            let rb = (r & 0x7FFFFu) * D4;
            var s = 0.0;
            var kn = 0.0;
            for (var d = 0u; d < D4; d += 1u) {
                let kv = keys[rb + d];
                s += dot(kv, queries[qbase + d]);
                kn += dot(kv, kv);
            }
            var sc = NONE;
            if (kn > 0.0) {
                sc = s * inverseSqrt(kn);
            }
            escore[i] = sc;
        }
    }
    workgroupBarrier();
    for (var k = 0u; k < 16u; k += 1u) {
        let i = t + k * 64u;
        let r = erow[i];
        if (r != PAD) {
            var dup = false;
            for (var j = 0u; j < MAXE; j += 1u) {
                if (j < i && erow[j] == r) {
                    dup = true;
                }
            }
            if (dup) {
                escore[i] = NONE;
            }
        }
    }
    workgroupBarrier();
    for (var k = 0u; k < 16u; k += 1u) {
        let i = t + k * 64u;
        let r = erow[i];
        let s = escore[i];
        if (r != PAD && s > NONE) {
            var rank = 0u;
            for (var j = 0u; j < MAXE; j += 1u) {
                let o = escore[j];
                if (o > s || (o == s && j < i)) {
                    rank += 1u;
                }
            }
            if (rank < 64u && valid) {
                cands[q * 64u + rank] = r;
            }
        }
    }
}
