// passes 2

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const NC: u32 = 128u;
const CAP: u32 = 4096u;
const D4: u32 = 512u;
const NPROBE: u32 = 8u;
const MAXC: u32 = 1536u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const CENT_BASE: u32 = 16u;
const CNT_BASE: u32 = 1024u;
const MEM_BASE: u32 = 2048u;

var<workgroup> red: array<f32, 64>;
var<workgroup> rid: array<u32, 64>;

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let w = wid.x;
    let row = cfg.arrived_begin + w;
    let rowc = row & 0xFFFFFu;
    let base = rowc * D4;
    if (cfg.pass_index == 0u) {
        var n = 0.0;
        for (var i = 0u; i < D4; i += 64u) {
            let d = i + t;
            if (d < D4) {
                let v = keys[base + d];
                n = n + dot(v, v);
            }
        }
        red[t] = n;
        workgroupBarrier();
        if (t == 0u) {
            var s = 0.0;
            for (var k = 0u; k < 64u; k += 1u) {
                s = s + red[k];
            }
            index_f32[rowc] = sqrt(s);
            if (cfg.stage == 1u) {
                let per = cfg.arrived_end - cfg.arrived_begin;
                let stride = max(per / NC, 1u);
                if (w % stride == 0u && (w / stride) < NC) {
                    let c = w / stride;
                    atomicStore(&index_u32[CENT_BASE + (c & 127u)], row);
                }
            }
        }
    } else {
        var best = NONE;
        var bi = 0u;
        for (var i = 0u; i < NC; i += 64u) {
            let c = i + t;
            if (c < NC) {
                let cid = atomicLoad(&index_u32[CENT_BASE + (c & 127u)]) & 0xFFFFFu;
                let cn = index_f32[cid];
                if (cn > 0.0) {
                    var s = 0.0;
                    for (var d = 0u; d < D4; d += 1u) {
                        s = s + dot(keys[base + d], keys[cid * D4 + d]);
                    }
                    s = s / cn;
                    if (s > best) {
                        best = s;
                        bi = c;
                    }
                }
            }
        }
        red[t] = best;
        rid[t] = bi;
        workgroupBarrier();
        if (t == 0u) {
            var bs = NONE;
            var bb = 0u;
            for (var k = 0u; k < 64u; k += 1u) {
                if (red[k] > bs) {
                    bs = red[k];
                    bb = rid[k];
                }
            }
            if (bs > NONE && index_f32[rowc] > 0.0) {
                let b = bb & 127u;
                let slot = atomicAdd(&index_u32[CNT_BASE + b], 1u);
                if (slot < CAP) {
                    atomicStore(&index_u32[MEM_BASE + b * CAP + (slot & 4095u)], row);
                }
            }
        }
    }
}

var<workgroup> sc: array<f32, 128>;
var<workgroup> probe: array<u32, 8>;
var<workgroup> poff: array<u32, 9>;
var<workgroup> cs: array<f32, 1536>;
var<workgroup> cr: array<u32, 1536>;

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let qb = (q & 0xFFFFu) * D4;
    let valid = q < cfg.n_queries;
    for (var i = 0u; i < NC; i += 64u) {
        let c = i + t;
        if (c < NC) {
            var s = NONE;
            if (valid) {
                let cid = atomicLoad(&index_u32[CENT_BASE + (c & 127u)]) & 0xFFFFFu;
                let cn = index_f32[cid];
                if (cn > 0.0) {
                    var a = 0.0;
                    for (var d = 0u; d < D4; d += 1u) {
                        a = a + dot(keys[cid * D4 + d], queries[qb + d]);
                    }
                    s = a / cn;
                }
            }
            sc[c & 127u] = s;
        }
    }
    workgroupBarrier();
    if (t == 0u) {
        var tot = 0u;
        for (var p = 0u; p < NPROBE; p += 1u) {
            var bs = -3.4e38;
            var bc = 0u;
            for (var c = 0u; c < NC; c += 1u) {
                if (sc[c] > bs) {
                    bs = sc[c];
                    bc = c;
                }
            }
            sc[bc] = -3.4e38;
            probe[p] = bc;
            var n = min(atomicLoad(&index_u32[CNT_BASE + (bc & 127u)]), CAP);
            if (!valid) {
                n = 0u;
            }
            n = min(n, MAXC - tot);
            poff[p] = tot;
            tot = tot + n;
        }
        poff[NPROBE] = tot;
    }
    workgroupBarrier();
    for (var p = 0u; p < NPROBE; p += 1u) {
        let b = probe[p] & 127u;
        let n = poff[p + 1u] - poff[p];
        let off = poff[p];
        for (var i = 0u; i < MAXC; i += 64u) {
            let m = i + t;
            if (m < n) {
                let r = atomicLoad(&index_u32[MEM_BASE + b * CAP + (m & 4095u)]);
                let rc = r & 0xFFFFFu;
                let rn = index_f32[rc];
                var s = NONE;
                if (rn > 0.0 && r < cfg.arrived_end) {
                    var a = 0.0;
                    for (var d = 0u; d < D4; d += 1u) {
                        a = a + dot(keys[rc * D4 + d], queries[qb + d]);
                    }
                    s = a / rn;
                }
                let slot = (off + m) % MAXC;
                cs[slot] = s;
                cr[slot] = r;
            }
        }
    }
    workgroupBarrier();
    let total = poff[NPROBE];
    for (var i = 0u; i < MAXC; i += 64u) {
        let j = i + t;
        if (j < total) {
            let sj = cs[j];
            var rank = 0u;
            for (var k = 0u; k < MAXC; k += 1u) {
                if (k < total) {
                    let sk = cs[k];
                    if (sk > sj || (sk == sj && k < j)) {
                        rank += 1u;
                    }
                }
            }
            if (rank < 64u && sj > NONE * 0.5 && valid) {
                cands[(q & 0xFFFFu) * 64u + rank] = cr[j];
            }
        }
    }
}
