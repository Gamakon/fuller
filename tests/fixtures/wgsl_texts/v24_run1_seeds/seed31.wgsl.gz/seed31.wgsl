// passes 3
// v24 design: hotspot-first splaying. Pass 0 projects each arriving row onto
// 16 hashed +-1 directions, keeps a 16-bit sign code and the row's inverse
// norm, and counts the row (and its spill cell: least-confident coarse bit
// flipped) in a histogram of 4,096 coarse cells. Pass 1 places the row: a
// cell whose running count has crossed the hot threshold splays into 16
// sub-buckets keyed by the four extra sign bits, otherwise the row goes in
// the cell's flat coarse bucket. Pass 2 walks the cells and, for any cell
// that has just become hot, migrates its coarse members down into the
// sub-buckets (the splay). Search hashes the query, multi-probes 64 coarse
// cells on the six least-confident bits (plus 4 sub-buckets inside hot
// cells), gathers up to 1,536 candidate rows, scores them exactly by cosine
// and selects the 64 best by repeated parallel argmax.

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const C_MAX: u32 = 64u;
const D4: u32 = 512u;
const WG: u32 = 128u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const MASK: u32 = 0x7FFFFFu;
const ROWMASK: u32 = 0x7FFFFu;

const COUNT_BASE: u32 = 0u;
const HOT_BASE: u32 = 4096u;
const CCNT_BASE: u32 = 8192u;
const SCNT_BASE: u32 = 12288u;
const ROWCODE_BASE: u32 = 77824u;
const COARSE_BASE: u32 = 131072u;
const SUB_BASE: u32 = 655360u;
const CCAP: u32 = 128u;
const SUBCAP: u32 = 96u;
const HOT_T: u32 = 128u;
const CAP: u32 = 1536u;

var<workgroup> wsf: array<f32, 1536>;
var<workgroup> wcid: array<u32, 1536>;
var<workgroup> wred: array<f32, 128>;
var<workgroup> wredi: array<u32, 128>;
var<workgroup> wproj: array<f32, 16>;
var<workgroup> wnorm: f32;
var<workgroup> wcode: u32;
var<workgroup> worder: array<u32, 12>;
var<workgroup> wsord: array<u32, 4>;

fn dimhash(dim: u32) -> u32 {
    var h = dim * 0x9E3779B1u + 0x7F4A7C15u;
    h = h ^ (h >> 16u);
    h = h * 0x85EBCA6Bu;
    h = h ^ (h >> 13u);
    h = h * 0xC2B2AE35u;
    h = h ^ (h >> 16u);
    return h;
}

fn addp(p: ptr<function, array<f32, 16>>, v: vec4<f32>, dim0: u32) {
    for (var e = 0u; e < 4u; e += 1u) {
        let h = dimhash(dim0 + e);
        let x = v[e];
        for (var i = 0u; i < 16u; i += 1u) {
            (*p)[i] = (*p)[i] + x * (1.0 - 2.0 * f32((h >> i) & 1u));
        }
    }
}

fn reduce_proj(t: u32, p: ptr<function, array<f32, 16>>, nrm: f32) {
    for (var round = 0u; round < 2u; round += 1u) {
        for (var i = 0u; i < 8u; i += 1u) {
            wsf[i * WG + t] = (*p)[round * 8u + i];
        }
        workgroupBarrier();
        if (t < 8u) {
            var s = 0.0;
            for (var k = 0u; k < WG; k += 1u) {
                s = s + wsf[t * WG + k];
            }
            wproj[round * 8u + t] = s;
        }
        workgroupBarrier();
    }
    wsf[t] = nrm;
    workgroupBarrier();
    if (t == 0u) {
        var s = 0.0;
        for (var k = 0u; k < WG; k += 1u) {
            s = s + wsf[k];
        }
        wnorm = s;
    }
    workgroupBarrier();
}

fn insert_row(cell: u32, sub: u32, row: u32) {
    let c = cell & 0xFFFu;
    let cnt = atomicLoad(&index_u32[(COUNT_BASE + c) & MASK]);
    if (cnt >= HOT_T) {
        let b = c * 16u + (sub & 0xFu);
        let slot = atomicAdd(&index_u32[(SCNT_BASE + b) & MASK], 1u);
        if (slot < SUBCAP) {
            atomicStore(&index_u32[(SUB_BASE + b * SUBCAP + slot) & MASK], row);
        }
    } else {
        let slot = atomicAdd(&index_u32[(CCNT_BASE + c) & MASK], 1u);
        if (slot < CCAP) {
            atomicStore(&index_u32[(COARSE_BASE + c * CCAP + slot) & MASK], row);
        }
    }
}

@compute @workgroup_size(128)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = cfg.arrived_begin + wid.x;
    if (cfg.pass_index == 0u) {
        var p: array<f32, 16>;
        for (var i = 0u; i < 16u; i += 1u) {
            p[i] = 0.0;
        }
        var nrm = 0.0;
        if (row < cfg.arrived_end) {
            for (var j = 0u; j < 4u; j += 1u) {
                let d = t * 4u + j;
                let v = keys[(row & ROWMASK) * D4 + d];
                nrm = nrm + dot(v, v);
                addp(&p, v, d * 4u);
            }
        }
        reduce_proj(t, &p, nrm);
        if (t == 0u && row < cfg.arrived_end) {
            var code = 0u;
            for (var i = 0u; i < 16u; i += 1u) {
                if (wproj[i] > 0.0) {
                    code = code | (1u << i);
                }
            }
            var lc = 0u;
            var lcv = 3.0e38;
            for (var i = 0u; i < 12u; i += 1u) {
                let a = abs(wproj[i]);
                if (a < lcv) {
                    lcv = a;
                    lc = i;
                }
            }
            atomicStore(&index_u32[(ROWCODE_BASE + (row & ROWMASK)) & MASK], code | (lc << 16u));
            var inv = 0.0;
            if (wnorm > 0.0) {
                inv = inverseSqrt(wnorm);
            }
            index_f32[row & MASK] = inv;
            let cell_a = code & 0xFFFu;
            let cell_b = cell_a ^ (1u << lc);
            atomicAdd(&index_u32[(COUNT_BASE + cell_a) & MASK], 1u);
            atomicAdd(&index_u32[(COUNT_BASE + cell_b) & MASK], 1u);
        }
    } else if (cfg.pass_index == 1u) {
        if (t == 0u && row < cfg.arrived_end) {
            let w = atomicLoad(&index_u32[(ROWCODE_BASE + (row & ROWMASK)) & MASK]);
            let code = w & 0xFFFFu;
            let lc = (w >> 16u) & 0xFu;
            let sub = code >> 12u;
            let cell_a = code & 0xFFFu;
            let cell_b = cell_a ^ (1u << lc);
            insert_row(cell_a, sub, row);
            insert_row(cell_b, sub, row);
        }
    } else if (cfg.pass_index == 2u) {
        let per = cfg.arrived_end - cfg.arrived_begin;
        for (var k = 0u; k < 4096u; k += 1u) {
            let c = wid.x + k * per;
            if (c >= 4096u) {
                break;
            }
            let cnt = atomicLoad(&index_u32[(COUNT_BASE + c) & MASK]);
            let done = atomicLoad(&index_u32[(HOT_BASE + c) & MASK]);
            let mig = (cnt >= HOT_T) && (done == 0u);
            let n = min(atomicLoad(&index_u32[(CCNT_BASE + c) & MASK]), CCAP);
            if (mig && t < n) {
                let r = atomicLoad(&index_u32[(COARSE_BASE + c * CCAP + t) & MASK]);
                let w = atomicLoad(&index_u32[(ROWCODE_BASE + (r & ROWMASK)) & MASK]);
                let sub = (w >> 12u) & 0xFu;
                let b = c * 16u + sub;
                let slot = atomicAdd(&index_u32[(SCNT_BASE + b) & MASK], 1u);
                if (slot < SUBCAP) {
                    atomicStore(&index_u32[(SUB_BASE + b * SUBCAP + slot) & MASK], r);
                }
            }
            workgroupBarrier();
            if (mig && t == 0u) {
                atomicStore(&index_u32[(CCNT_BASE + c) & MASK], 0u);
                atomicStore(&index_u32[(HOT_BASE + c) & MASK], 1u);
            }
            workgroupBarrier();
        }
    }
}

@compute @workgroup_size(128)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let q = wid.x;
    let t = lid.x;
    let qbase = (q & ROWMASK) * D4;

    // Phase A: hash the query.
    var p: array<f32, 16>;
    for (var i = 0u; i < 16u; i += 1u) {
        p[i] = 0.0;
    }
    var nrm = 0.0;
    if (q < cfg.n_queries) {
        for (var j = 0u; j < 4u; j += 1u) {
            let d = t * 4u + j;
            let v = queries[qbase + d];
            nrm = nrm + dot(v, v);
            addp(&p, v, d * 4u);
        }
    }
    reduce_proj(t, &p, nrm);
    if (t == 0u) {
        var code = 0u;
        for (var i = 0u; i < 16u; i += 1u) {
            if (wproj[i] > 0.0) {
                code = code | (1u << i);
            }
        }
        wcode = code;
        // Coarse bits sorted by confidence, least confident first.
        var ord: array<u32, 12>;
        for (var i = 0u; i < 12u; i += 1u) {
            ord[i] = i;
        }
        for (var i = 1u; i < 12u; i += 1u) {
            let cur = ord[i];
            let cv = abs(wproj[cur]);
            var j = i;
            for (var m = 0u; m < 12u; m += 1u) {
                if (j > 0u) {
                    let prev = ord[j - 1u];
                    if (abs(wproj[prev]) > cv) {
                        ord[j] = prev;
                        j = j - 1u;
                    }
                }
            }
            ord[j] = cur;
        }
        for (var i = 0u; i < 12u; i += 1u) {
            worder[i] = ord[i];
        }
        var sord: array<u32, 4>;
        for (var i = 0u; i < 4u; i += 1u) {
            sord[i] = 12u + i;
        }
        for (var i = 1u; i < 4u; i += 1u) {
            let cur = sord[i];
            let cv = abs(wproj[cur]);
            var j = i;
            for (var m = 0u; m < 4u; m += 1u) {
                if (j > 0u) {
                    let prev = sord[j - 1u];
                    if (abs(wproj[prev]) > cv) {
                        sord[j] = prev;
                        j = j - 1u;
                    }
                }
            }
            sord[j] = cur;
        }
        for (var i = 0u; i < 4u; i += 1u) {
            wsord[i] = sord[i] - 12u;
        }
    }
    workgroupBarrier();

    // Phase B: gather candidates from the probed cells.
    let code = wcode;
    let code12 = code & 0xFFFu;
    let qsub = code >> 12u;
    var base = 0u;
    for (var pr = 0u; pr < 64u; pr += 1u) {
        if (base >= CAP) {
            break;
        }
        var cell = code12;
        for (var k = 0u; k < 6u; k += 1u) {
            if (((pr >> k) & 1u) == 1u) {
                cell = cell ^ (1u << worder[k]);
            }
        }
        cell = cell & 0xFFFu;
        let cc = min(atomicLoad(&index_u32[(CCNT_BASE + cell) & MASK]), CCAP);
        if (t < cc && base + t < CAP) {
            let r = atomicLoad(&index_u32[(COARSE_BASE + cell * CCAP + t) & MASK]);
            var rr = PAD;
            if (r < cfg.arrived_end) {
                rr = r;
            }
            wcid[base + t] = rr;
        }
        base = min(base + cc, CAP);
        let cnt = atomicLoad(&index_u32[(COUNT_BASE + cell) & MASK]);
        if (cnt >= HOT_T) {
            for (var s = 0u; s < 4u; s += 1u) {
                var sub = qsub;
                if ((s & 1u) == 1u) {
                    sub = sub ^ (1u << wsord[0]);
                }
                if ((s & 2u) == 2u) {
                    sub = sub ^ (1u << wsord[1]);
                }
                let b = cell * 16u + (sub & 0xFu);
                let sc = min(atomicLoad(&index_u32[(SCNT_BASE + b) & MASK]), SUBCAP);
                if (t < sc && base + t < CAP) {
                    let r = atomicLoad(&index_u32[(SUB_BASE + b * SUBCAP + t) & MASK]);
                    var rr = PAD;
                    if (r < cfg.arrived_end) {
                        rr = r;
                    }
                    wcid[base + t] = rr;
                }
                base = min(base + sc, CAP);
            }
        }
    }
    workgroupBarrier();
    let ncand = min(base, CAP);

    // Phase C: exact cosine over the candidates.
    var qinv = 0.0;
    if (wnorm > 0.0) {
        qinv = inverseSqrt(wnorm);
    }
    for (var i = 0u; i < CAP; i += WG) {
        let j = i + t;
        if (j < ncand) {
            let r = wcid[j];
            var score = NONE;
            if (r != PAD) {
                let kb = (r & ROWMASK) * D4;
                var s = 0.0;
                for (var d = 0u; d < D4; d += 1u) {
                    s = s + dot(keys[kb + d], queries[qbase + d]);
                }
                let rinv = index_f32[r & MASK];
                if (rinv > 0.0 && qinv > 0.0) {
                    score = s * qinv * rinv;
                }
            }
            wsf[j] = score;
        }
    }
    workgroupBarrier();

    // Phase D: 64 rounds of parallel argmax.
    var nsel = 0u;
    var last = PAD;
    for (var round = 0u; round < C_MAX; round += 1u) {
        var bs = NONE;
        var bi = PAD;
        for (var i = 0u; i < CAP; i += WG) {
            let j = i + t;
            if (j < ncand) {
                let s = wsf[j];
                if (s > bs) {
                    bs = s;
                    bi = j;
                }
            }
        }
        wred[t] = bs;
        wredi[t] = bi;
        workgroupBarrier();
        for (var k = 0u; k < 7u; k += 1u) {
            let s = 64u >> k;
            if (t < s) {
                let os = wred[t + s];
                let oi = wredi[t + s];
                let ms = wred[t];
                let mi = wredi[t];
                if (os > ms || (os == ms && oi < mi)) {
                    wred[t] = os;
                    wredi[t] = oi;
                }
            }
            workgroupBarrier();
        }
        if (t == 0u) {
            let bi0 = wredi[0];
            let bs0 = wred[0];
            if (bi0 != PAD && bs0 > NONE) {
                let r = wcid[bi0 & 2047u];
                if (r != last && r != PAD && nsel < C_MAX && q < cfg.n_queries) {
                    cands[q * C_MAX + nsel] = r;
                    nsel = nsel + 1u;
                    last = r;
                }
                wsf[bi0 & 2047u] = NONE;
            }
        }
        workgroupBarrier();
    }
}
