// passes 2
struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const CELLS: u32 = 128u;
const ROOTS: u32 = 32u;
const CELL_COUNT: u32 = 0u;
const NEXT_CELL: u32 = 256u;
const CELL_REP: u32 = 512u;
const MEMBERS: u32 = 2048u;
const CELL_CAP: u32 = 256u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;

var<workgroup> merge_score: array<f32, 64>;
var<workgroup> merge_row: array<u32, 64>;

@compute @workgroup_size(1)
fn ingest(@builtin(workgroup_id) wid: vec3<u32>) {
    let row = cfg.arrived_begin + wid.x;

    if (cfg.pass_index == 0u) {
        if (cfg.arrived_begin == 0u && row < ROOTS) {
            atomicStore(&index_u32[CELL_REP + row], row);
        }
        if (cfg.arrived_begin == 0u && row == 0u) {
            atomicStore(&index_u32[NEXT_CELL], ROOTS);
        }
        return;
    }

    if (row >= cfg.arrived_end) {
        return;
    }

    let visible = min(atomicLoad(&index_u32[NEXT_CELL]), CELLS);
    var best_cell = 0u;
    var best_dist = 3.0e38;

    for (var c = 0u; c < CELLS; c = c + 1u) {
        if (c < visible) {
            let rep = atomicLoad(&index_u32[CELL_REP + c]);
            var dist = 0.0;
            for (var d = 0u; d < 16u; d = d + 1u) {
                let delta = keys[(row & 0x7FFFFu) * D4 + d] -
                    keys[(rep & 0x7FFFFu) * D4 + d];
                dist = dist + dot(delta, delta);
            }
            if (dist < best_dist) {
                best_dist = dist;
                best_cell = c;
            }
        }
    }

    let density = f32(atomicLoad(&index_u32[CELL_COUNT + best_cell]));
    let radius = 0.080 / (1.0 + 0.012 * density);

    if (best_dist > radius && visible < CELLS) {
        let made = atomicAdd(&index_u32[NEXT_CELL], 1u);
        if (made < CELLS) {
            atomicStore(&index_u32[CELL_REP + made], row);
            best_cell = made;
        }
    }

    let slot = atomicAdd(&index_u32[CELL_COUNT + best_cell], 1u);
    if (slot < CELL_CAP) {
        atomicStore(&index_u32[MEMBERS + best_cell * CELL_CAP + slot], row);
    }
}

@compute @workgroup_size(8)
fn search(
    @builtin(local_invocation_id) lid: vec3<u32>,
    @builtin(workgroup_id) wid: vec3<u32>
) {
    let q = wid.x;
    let t = lid.x;

    var picked_score: array<f32, 4>;
    var picked_cell: array<u32, 4>;
    for (var j = 0u; j < 4u; j = j + 1u) {
        picked_score[j] = NONE;
        picked_cell[j] = 0u;
    }

    if (q < cfg.n_queries) {
        let ncell = min(atomicLoad(&index_u32[NEXT_CELL]), CELLS);
        for (var c = 0u; c < CELLS; c = c + 1u) {
            if (c < ncell && atomicLoad(&index_u32[CELL_COUNT + c]) != 0u) {
                let rep = atomicLoad(&index_u32[CELL_REP + c]);
                var score = 0.0;
                for (var d = 0u; d < 32u; d = d + 1u) {
                    score = score + dot(
                        queries[(q & 0xFFFFu) * D4 + d],
                        keys[(rep & 0x7FFFFu) * D4 + d]
                    );
                }

                var carry_score = score;
                var carry_cell = c;
                for (var j = 0u; j < 4u; j = j + 1u) {
                    if (carry_score > picked_score[j]) {
                        let old_score = picked_score[j];
                        let old_cell = picked_cell[j];
                        picked_score[j] = carry_score;
                        picked_cell[j] = carry_cell;
                        carry_score = old_score;
                        carry_cell = old_cell;
                    }
                }
            }
        }
    }

    var best: array<f32, 8>;
    var rows: array<u32, 8>;
    for (var j = 0u; j < 8u; j = j + 1u) {
        best[j] = NONE;
        rows[j] = PAD;
    }

    if (q < cfg.n_queries) {
        for (var which = 0u; which < 4u; which = which + 1u) {
            let cell = picked_cell[which];
            let count = min(atomicLoad(&index_u32[CELL_COUNT + cell]), CELL_CAP);

            for (var base = 0u; base < CELL_CAP; base = base + 8u) {
                let pos = base + t;
                if (pos < count) {
                    let row = atomicLoad(&index_u32[MEMBERS + cell * CELL_CAP + pos]);
                    var score = 0.0;
                    for (var d = 0u; d < 64u; d = d + 1u) {
                        score = score + dot(
                            queries[(q & 0xFFFFu) * D4 + d],
                            keys[(row & 0x7FFFFu) * D4 + d]
                        );
                    }

                    if (score > best[7u]) {
                        var carry_score = score;
                        var carry_row = row;
                        for (var j = 0u; j < 8u; j = j + 1u) {
                            if (carry_score > best[j]) {
                                let old_score = best[j];
                                let old_row = rows[j];
                                best[j] = carry_score;
                                rows[j] = carry_row;
                                carry_score = old_score;
                                carry_row = old_row;
                            }
                        }
                    }
                }
            }
        }
    }

    for (var j = 0u; j < 8u; j = j + 1u) {
        merge_score[t * 8u + j] = best[j];
        merge_row[t * 8u + j] = rows[j];
    }
    workgroupBarrier();

    if (q < cfg.n_queries) {
        for (var j = 0u; j < 8u; j = j + 1u) {
            best[j] = NONE;
            rows[j] = PAD;
        }

        for (var i = 0u; i < 64u; i = i + 1u) {
            let score = merge_score[i];
            let row = merge_row[i];
            if (row != PAD && score > best[7u]) {
                var carry_score = score;
                var carry_row = row;
                for (var j = 0u; j < 8u; j = j + 1u) {
                    if (carry_score > best[j]) {
                        let old_score = best[j];
                        let old_row = rows[j];
                        best[j] = carry_score;
                        rows[j] = carry_row;
                        carry_score = old_score;
                        carry_row = old_row;
                    }
                }
            }
        }

        for (var j = 0u; j < 8u; j = j + 1u) {
            cands[(q & 0xFFFFu) * 64u + t + j * 8u] = rows[t + j * 8u];
        }
    }
}
