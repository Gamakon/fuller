// passes 2
struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<f32>;
@group(0) @binding(1) var<storage, read> queries: array<f32>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D: u32 = 16u;
const CELLS: u32 = 64u;
const CAP: u32 = 1024u;
const COUNT_BASE: u32 = 0u;
const ROW_BASE: u32 = 128u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;

var<workgroup> chosen: array<u32, 3>;
var<workgroup> merge_score: array<f32, 128>;
var<workgroup> merge_row: array<u32, 128>;

fn feature_key(row: u32, d: u32) -> f32 {
    return keys[row * 2048u + d * 127u];
}

fn feature_query(q: u32, d: u32) -> f32 {
    return queries[q * 2048u + d * 127u];
}

fn centre_dist_key(row: u32, cell: u32) -> f32 {
    var v = 0.0;
    for (var d = 0u; d < D; d = d + 1u) {
        let x = feature_key(row, d) - index_f32[cell * D + d];
        v = v + x * x;
    }
    return v;
}

fn centre_dist_query(q: u32, cell: u32) -> f32 {
    var v = 0.0;
    for (var d = 0u; d < D; d = d + 1u) {
        let x = feature_query(q, d) - index_f32[cell * D + d];
        v = v + x * x;
    }
    return v;
}

@compute @workgroup_size(1)
fn ingest(@builtin(workgroup_id) wid: vec3<u32>) {
    let row = cfg.arrived_begin + wid.x;
    if (row >= cfg.arrived_end) {
        return;
    }

    if (cfg.pass_index == 0u) {
        if (cfg.stage == 1u && row < CELLS) {
            for (var d = 0u; d < D; d = d + 1u) {
                index_f32[row * D + d] = feature_key(row, d);
            }
        }
        return;
    }

    var first = 0u;
    var second = 1u;
    var da = centre_dist_key(row, 0u);
    var db = centre_dist_key(row, 1u);
    if (db < da) {
        let td = da;
        da = db;
        db = td;
        first = 1u;
        second = 0u;
    }
    for (var cell = 2u; cell < CELLS; cell = cell + 1u) {
        let d = centre_dist_key(row, cell);
        if (d < da) {
            db = da;
            second = first;
            da = d;
            first = cell;
        } else if (d < db) {
            db = d;
            second = cell;
        }
    }

    let slot_a = atomicAdd(&index_u32[COUNT_BASE + first], 1u);
    if (slot_a < CAP) {
        atomicStore(&index_u32[ROW_BASE + first * CAP + slot_a], row);
    }
    let slot_b = atomicAdd(&index_u32[COUNT_BASE + second], 1u);
    if (slot_b < CAP) {
        atomicStore(&index_u32[ROW_BASE + second * CAP + slot_b], row);
    }
}

@compute @workgroup_size(16)
fn search(
    @builtin(local_invocation_id) lid: vec3<u32>,
    @builtin(workgroup_id) wid: vec3<u32>
) {
    let q = wid.x;
    let t = lid.x;

    if (t == 0u && q < cfg.n_queries) {
        var a = 0u;
        var b = 1u;
        var c = 2u;
        var da = centre_dist_query(q, a);
        var db = centre_dist_query(q, b);
        var dc = centre_dist_query(q, c);
        if (db < da) {
            let tx = da;
            da = db;
            db = tx;
            let ti = a;
            a = b;
            b = ti;
        }
        if (dc < db) {
            let tx = db;
            db = dc;
            dc = tx;
            let ti = b;
            b = c;
            c = ti;
        }
        if (db < da) {
            let tx = da;
            da = db;
            db = tx;
            let ti = a;
            a = b;
            b = ti;
        }
        for (var cell = 3u; cell < CELLS; cell = cell + 1u) {
            let d = centre_dist_query(q, cell);
            if (d < da) {
                dc = db;
                c = b;
                db = da;
                b = a;
                da = d;
                a = cell;
            } else if (d < db) {
                dc = db;
                c = b;
                db = d;
                b = cell;
            } else if (d < dc) {
                dc = d;
                c = cell;
            }
        }
        chosen[0] = a;
        chosen[1] = b;
        chosen[2] = c;
    }
    workgroupBarrier();

    var best: array<f32, 8>;
    var rows: array<u32, 8>;
    for (var i = 0u; i < 8u; i = i + 1u) {
        best[i] = NONE;
        rows[i] = PAD;
    }

    if (q < cfg.n_queries) {
        for (var probe = 0u; probe < 3u; probe = probe + 1u) {
            let cell = chosen[probe];
            let count = min(atomicLoad(&index_u32[COUNT_BASE + cell]), CAP);
            for (var i = 0u; i < count; i = i + 16u) {
                let slot = i + t;
                if (slot < count) {
                    let row = atomicLoad(&index_u32[ROW_BASE + cell * CAP + slot]);
                    if (row < cfg.arrived_end) {
                        var score = 0.0;
                        for (var d = 0u; d < D; d = d + 1u) {
                            score = score + feature_key(row, d) * feature_query(q, d);
                        }
                        if (score > best[7u]) {
                            var carry_score = score;
                            var carry_row = row;
                            for (var j = 0u; j < 8u; j = j + 1u) {
                                if (carry_score > best[j]) {
                                    let old_score = best[j];
                                    let old_row = rows[j];
                                    best[j] = carry_score;
                                    rows[j] = carry_row;
                                    carry_score = old_score;
                                    carry_row = old_row;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    for (var i = 0u; i < 8u; i = i + 1u) {
        merge_score[t * 8u + i] = best[i];
        merge_row[t * 8u + i] = rows[i];
    }
    workgroupBarrier();

    if (q < cfg.n_queries) {
        for (var i = 0u; i < 8u; i = i + 1u) {
            best[i] = NONE;
            rows[i] = PAD;
        }
        for (var i = 0u; i < 128u; i = i + 1u) {
            let score = merge_score[i];
            let row = merge_row[i];
            if (row != PAD && score > best[7u]) {
                var carry_score = score;
                var carry_row = row;
                for (var j = 0u; j < 8u; j = j + 1u) {
                    if (carry_score > best[j]) {
                        let old_score = best[j];
                        let old_row = rows[j];
                        best[j] = carry_score;
                        rows[j] = carry_row;
                        carry_score = old_score;
                        carry_row = old_row;
                    }
                }
            }
        }
        cands[q * 64u + t] = rows[t];
        cands[q * 64u + 16u + t] = rows[16u + t];
        cands[q * 64u + 32u + t] = rows[32u + t];
        cands[q * 64u + 48u + t] = rows[48u + t];
    }
}
