// passes 2
struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const K: u32 = 128u;
const CAP: u32 = 256u;
const MEMBASE: u32 = 1024u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;

var<workgroup> wrowv: array<vec4<f32>, 512>;
var<workgroup> red_s: array<f32, 256>;
var<workgroup> red_i: array<u32, 256>;
var<workgroup> wscore: array<f32, 2048>;
var<workgroup> probe: array<u32, 8>;

@compute @workgroup_size(256)
fn ingest(@builtin(local_invocation_id) lid3: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let lid = lid3.x;
    let row = (cfg.arrived_begin + wid.x) & 0x7FFFFu;
    if (cfg.pass_index == 0u) {
        // Stage 1 only: the first K rows become the global top-level centres.
        let isc = (cfg.stage == 1u) && (wid.x < K);
        var part = 0.0;
        if (isc) {
            for (var i = 0u; i < 2u; i += 1u) {
                let v = keys[row * D4 + lid + i * 256u];
                part += dot(v, v);
            }
        }
        red_s[lid] = part;
        workgroupBarrier();
        for (var k = 0u; k < 8u; k += 1u) {
            let st = 128u >> k;
            if (lid < st) {
                red_s[lid] = red_s[lid] + red_s[lid + st];
            }
            workgroupBarrier();
        }
        let nrm = red_s[0];
        if (isc) {
            var inv = 0.0;
            if (nrm > 0.0) {
                inv = inverseSqrt(nrm);
            }
            let c = wid.x & 127u;
            for (var i = 0u; i < 2u; i += 1u) {
                let d = lid + i * 256u;
                let v = keys[row * D4 + d] * inv;
                let b = c * 2048u + d * 4u;
                index_f32[b] = v.x;
                index_f32[b + 1u] = v.y;
                index_f32[b + 2u] = v.z;
                index_f32[b + 3u] = v.w;
            }
        }
    } else {
        for (var i = 0u; i < 2u; i += 1u) {
            let d = lid + i * 256u;
            wrowv[d] = keys[row * D4 + d];
        }
        workgroupBarrier();
        var s = NONE;
        if (lid < K) {
            s = 0.0;
            let b = lid * 2048u;
            for (var d = 0u; d < D4; d += 1u) {
                let o = b + d * 4u;
                let cv = vec4<f32>(index_f32[o], index_f32[o + 1u], index_f32[o + 2u], index_f32[o + 3u]);
                s += dot(wrowv[d], cv);
            }
        }
        red_s[lid] = s;
        red_i[lid] = lid;
        workgroupBarrier();
        for (var k = 0u; k < 8u; k += 1u) {
            let st = 128u >> k;
            if (lid < st) {
                if (red_s[lid + st] > red_s[lid]) {
                    red_s[lid] = red_s[lid + st];
                    red_i[lid] = red_i[lid + st];
                }
            }
            workgroupBarrier();
        }
        if (lid == 0u) {
            let c = red_i[0] & 127u;
            let slot = atomicAdd(&index_u32[c], 1u);
            if (slot < CAP) {
                atomicStore(&index_u32[MEMBASE + c * CAP + slot], row + 1u);
            }
        }
    }
}

@compute @workgroup_size(256)
fn search(@builtin(local_invocation_id) lid3: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let lid = lid3.x;
    let q = wid.x;
    var s = NONE;
    if (lid < K) {
        s = 0.0;
        let b = lid * 2048u;
        for (var d = 0u; d < D4; d += 1u) {
            let o = b + d * 4u;
            let cv = vec4<f32>(index_f32[o], index_f32[o + 1u], index_f32[o + 2u], index_f32[o + 3u]);
            s += dot(queries[q * D4 + d], cv);
        }
    }
    wscore[lid] = s;
    workgroupBarrier();
    // choose 8 probe centres
    for (var p = 0u; p < 8u; p += 1u) {
        red_s[lid] = wscore[lid];
        red_i[lid] = lid;
        workgroupBarrier();
        for (var k = 0u; k < 8u; k += 1u) {
            let st = 128u >> k;
            if (lid < st) {
                if (red_s[lid + st] > red_s[lid]) {
                    red_s[lid] = red_s[lid + st];
                    red_i[lid] = red_i[lid + st];
                }
            }
            workgroupBarrier();
        }
        let w = red_i[0] & 127u;
        workgroupBarrier();
        if (lid == 0u) {
            probe[p] = w;
            wscore[w] = NONE;
        }
        workgroupBarrier();
    }
    // score members of the probed buckets
    for (var i = 0u; i < 8u; i += 1u) {
        let c = probe[i] & 127u;
        let cnt = min(atomicLoad(&index_u32[c]), CAP);
        var sc = NONE;
        if (lid < cnt) {
            let rv = atomicLoad(&index_u32[MEMBASE + c * CAP + lid]);
            if (rv != 0u) {
                let r = (rv - 1u) & 0x7FFFFu;
                var dt = 0.0;
                var kn = 0.0;
                for (var d = 0u; d < D4; d += 1u) {
                    let kv = keys[r * D4 + d];
                    dt += dot(kv, queries[q * D4 + d]);
                    kn += dot(kv, kv);
                }
                if (kn > 0.0) {
                    sc = dt * inverseSqrt(kn);
                }
            }
        }
        wscore[i * 256u + lid] = sc;
    }
    workgroupBarrier();
    // top 64 by repeated argmax
    for (var r = 0u; r < 64u; r += 1u) {
        var bs = NONE;
        var bi = 0u;
        for (var i = 0u; i < 8u; i += 1u) {
            let e = i * 256u + lid;
            let v = wscore[e];
            if (v > bs) {
                bs = v;
                bi = e;
            }
        }
        red_s[lid] = bs;
        red_i[lid] = bi;
        workgroupBarrier();
        for (var k = 0u; k < 8u; k += 1u) {
            let st = 128u >> k;
            if (lid < st) {
                if (red_s[lid + st] > red_s[lid]) {
                    red_s[lid] = red_s[lid + st];
                    red_i[lid] = red_i[lid + st];
                }
            }
            workgroupBarrier();
        }
        if (lid == 0u) {
            let e = red_i[0] & 2047u;
            var out = PAD;
            if (red_s[0] > -1.0e30) {
                let c = probe[e >> 8u] & 127u;
                let rv = atomicLoad(&index_u32[MEMBASE + c * CAP + (e & 255u)]);
                if (rv != 0u) {
                    out = rv - 1u;
                }
                wscore[e] = NONE;
            }
            cands[q * 64u + r] = out;
        }
        workgroupBarrier();
    }
}
