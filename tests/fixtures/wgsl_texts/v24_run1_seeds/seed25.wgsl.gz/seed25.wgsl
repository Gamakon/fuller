// passes 1
struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const C_MAX: u32 = 64u;
const LANES: u32 = 8u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;

var<workgroup> lane_score: array<f32, 512>;
var<workgroup> lane_row: array<u32, 512>;

fn fold_bucket_key(row: u32) -> u32 {
    var a0 = 0.0;
    var a1 = 0.0;
    var a2 = 0.0;
    var a3 = 0.0;
    var a4 = 0.0;
    var a5 = 0.0;
    for (var i = 0u; i < D4; i = i + 1u) {
        let v = keys[(row & 0x7FFFFu) * D4 + i];
        let z = dot(v, vec4<f32>(1.0, -1.0, 1.0, -1.0));
        a0 = a0 + z;
        a1 = a1 + z * select(-1.0, 1.0, (i & 1u) == 0u);
        a2 = a2 + z * select(-1.0, 1.0, (i & 2u) == 0u);
        a3 = a3 + z * select(-1.0, 1.0, (i & 4u) == 0u);
        a4 = a4 + z * select(-1.0, 1.0, (i & 8u) == 0u);
        a5 = a5 + z * select(-1.0, 1.0, (i & 16u) == 0u);
    }
    var h = 0u;
    if (a0 >= 0.0) { h = h | 1u; }
    if (a1 >= 0.0) { h = h | 2u; }
    if (a2 >= 0.0) { h = h | 4u; }
    if (a3 >= 0.0) { h = h | 8u; }
    if (a4 >= 0.0) { h = h | 16u; }
    if (a5 >= 0.0) { h = h | 32u; }
    return h;
}

fn query_bucket_key(q: u32) -> u32 {
    var a0 = 0.0;
    var a1 = 0.0;
    var a2 = 0.0;
    var a3 = 0.0;
    var a4 = 0.0;
    var a5 = 0.0;
    for (var i = 0u; i < D4; i = i + 1u) {
        let v = queries[q * D4 + i];
        let z = dot(v, vec4<f32>(1.0, -1.0, 1.0, -1.0));
        a0 = a0 + z;
        a1 = a1 + z * select(-1.0, 1.0, (i & 1u) == 0u);
        a2 = a2 + z * select(-1.0, 1.0, (i & 2u) == 0u);
        a3 = a3 + z * select(-1.0, 1.0, (i & 4u) == 0u);
        a4 = a4 + z * select(-1.0, 1.0, (i & 8u) == 0u);
        a5 = a5 + z * select(-1.0, 1.0, (i & 16u) == 0u);
    }
    var h = 0u;
    if (a0 >= 0.0) { h = h | 1u; }
    if (a1 >= 0.0) { h = h | 2u; }
    if (a2 >= 0.0) { h = h | 4u; }
    if (a3 >= 0.0) { h = h | 8u; }
    if (a4 >= 0.0) { h = h | 16u; }
    if (a5 >= 0.0) { h = h | 32u; }
    return h;
}

@compute @workgroup_size(1)
fn ingest(@builtin(workgroup_id) wid: vec3<u32>) {
    let row = cfg.arrived_begin + wid.x;
    if (row < cfg.arrived_end && cfg.pass_index == 0u) {
        index_u32[row & 0x7FFFFFu] = fold_bucket_key(row);
    }
}

@compute @workgroup_size(8)
fn search(
    @builtin(local_invocation_id) lid: vec3<u32>,
    @builtin(workgroup_id) wid: vec3<u32>
) {
    let q = wid.x;
    let t = lid.x;
    var best: array<f32, 64>;
    var rows: array<u32, 64>;

    for (var j = 0u; j < C_MAX; j = j + 1u) {
        best[j] = NONE;
        rows[j] = PAD;
    }

    if (q < cfg.n_queries) {
        let h = query_bucket_key(q);
        let h1 = h ^ 1u;
        let h2 = h ^ 2u;
        let h3 = h ^ 4u;
        var qn = 0.0;
        for (var d = 0u; d < D4; d = d + 1u) {
            let v = queries[q * D4 + d];
            qn = qn + dot(v, v);
        }

        for (var i = 0u; i < cfg.arrived_end; i = i + LANES) {
            let row = i + t;
            if (row < cfg.arrived_end) {
                let rh = index_u32[row & 0x7FFFFFu];
                if (rh == h || rh == h1 || rh == h2 || rh == h3) {
                    var s = 0.0;
                    var kn = 0.0;
                    for (var d = 0u; d < D4; d = d + 1u) {
                        let k = keys[(row & 0x7FFFFu) * D4 + d];
                        let v = queries[q * D4 + d];
                        s = s + dot(k, v);
                        kn = kn + dot(k, k);
                    }
                    let denom = sqrt(qn * kn);
                    var score = NONE;
                    if (denom > 0.0) {
                        score = s / denom;
                    }
                    if (score > best[C_MAX - 1u]) {
                        var carry_score = score;
                        var carry_row = row;
                        for (var j = 0u; j < C_MAX; j = j + 1u) {
                            if (carry_score > best[j]) {
                                let old_score = best[j];
                                let old_row = rows[j];
                                best[j] = carry_score;
                                rows[j] = carry_row;
                                carry_score = old_score;
                                carry_row = old_row;
                            }
                        }
                    }
                }
            }
        }
    }

    for (var j = 0u; j < C_MAX; j = j + 1u) {
        lane_score[t * C_MAX + j] = best[j];
        lane_row[t * C_MAX + j] = rows[j];
    }
    workgroupBarrier();

    if (q < cfg.n_queries) {
        for (var j = 0u; j < C_MAX; j = j + 1u) {
            best[j] = NONE;
            rows[j] = PAD;
        }
        for (var i = 0u; i < 512u; i = i + 1u) {
            let score = lane_score[i];
            let row = lane_row[i];
            if (row != PAD && score > best[C_MAX - 1u]) {
                var carry_score = score;
                var carry_row = row;
                for (var j = 0u; j < C_MAX; j = j + 1u) {
                    if (carry_score > best[j]) {
                        let old_score = best[j];
                        let old_row = rows[j];
                        best[j] = carry_score;
                        rows[j] = carry_row;
                        carry_score = old_score;
                        carry_row = old_row;
                    }
                }
            }
        }
        for (var i = 0u; i < C_MAX; i = i + LANES) {
            cands[q * C_MAX + i + t] = rows[i + t];
        }
    }
}
