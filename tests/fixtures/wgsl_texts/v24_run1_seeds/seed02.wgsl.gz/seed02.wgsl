// passes 2
struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const NC: u32 = 128u;
const CAP: u32 = 2048u;
const BASE: u32 = 256u;
const MAXM: u32 = 1024u;
const NPROBE: u32 = 3u;
const PAD: u32 = 0xFFFFFFFFu;

var<workgroup> red: array<f32, 128>;
var<workgroup> wbest: array<u32, 4>;
var<workgroup> wscore: array<f32, 1024>;
var<workgroup> wrow: array<u32, 1024>;
var<workgroup> woff: array<u32, 4>;
var<workgroup> wcen: array<u32, 4>;
var<workgroup> wlen: array<u32, 4>;
var<workgroup> wtotal: u32;

@compute @workgroup_size(128)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = cfg.arrived_begin + wid.x;
    let rowbase = (row & 0x7FFFFu) * 512u;
    if (cfg.pass_index == 0u) {
        if (cfg.stage != 1u) {
            return;
        }
        let per = max(cfg.arrived_end - cfg.arrived_begin, 1u);
        let stride = max(per / NC, 1u);
        let w = wid.x;
        if ((w % stride) != 0u || (w / stride) >= NC) {
            return;
        }
        let j = w / stride;
        var part = 0.0;
        for (var i = 0u; i < 16u; i += 1u) {
            let d = i * 128u + t;
            let x = keys[rowbase + (d >> 2u)][d & 3u];
            part += x * x;
        }
        red[t] = part;
        workgroupBarrier();
        var n = 0.0;
        for (var i = 0u; i < 128u; i += 1u) {
            n += red[i];
        }
        let inv = 1.0 / sqrt(max(n, 1e-20));
        for (var i = 0u; i < 16u; i += 1u) {
            let d = i * 128u + t;
            let x = keys[rowbase + (d >> 2u)][d & 3u];
            index_f32[(d * 128u + j) & 0x7FFFFFu] = x * inv;
        }
        return;
    }
    // pass 1: assign to two nearest centres
    var s = 0.0;
    for (var d4 = 0u; d4 < 512u; d4 += 1u) {
        let v = keys[rowbase + d4];
        let b = d4 * 512u + t;
        s += v.x * index_f32[b & 0x7FFFFFu]
           + v.y * index_f32[(b + 128u) & 0x7FFFFFu]
           + v.z * index_f32[(b + 256u) & 0x7FFFFFu]
           + v.w * index_f32[(b + 384u) & 0x7FFFFFu];
    }
    red[t] = s;
    workgroupBarrier();
    if (t == 0u) {
        var b1 = -3.0e38;
        var c1 = 0u;
        for (var j = 0u; j < NC; j += 1u) {
            if (red[j] > b1) {
                b1 = red[j];
                c1 = j;
            }
        }
        var b2 = -3.0e38;
        var c2 = 0u;
        for (var j = 0u; j < NC; j += 1u) {
            if (j != c1 && red[j] > b2) {
                b2 = red[j];
                c2 = j;
            }
        }
        let s1 = atomicAdd(&index_u32[c1 & 127u], 1u);
        if (s1 < CAP) {
            atomicStore(&index_u32[(BASE + (c1 & 127u) * CAP + s1) & 0x7FFFFFu], row);
        }
        let s2 = atomicAdd(&index_u32[c2 & 127u], 1u);
        if (s2 < CAP) {
            atomicStore(&index_u32[(BASE + (c2 & 127u) * CAP + s2) & 0x7FFFFFu], row);
        }
    }
}

@compute @workgroup_size(128)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    if (q >= cfg.n_queries) {
        return;
    }
    let qbase = (q & 0xFFFFu) * 512u;
    var s = 0.0;
    for (var d4 = 0u; d4 < 512u; d4 += 1u) {
        let v = queries[qbase + d4];
        let b = d4 * 512u + t;
        s += v.x * index_f32[b & 0x7FFFFFu]
           + v.y * index_f32[(b + 128u) & 0x7FFFFFu]
           + v.z * index_f32[(b + 256u) & 0x7FFFFFu]
           + v.w * index_f32[(b + 384u) & 0x7FFFFFu];
    }
    red[t] = s;
    workgroupBarrier();
    if (t == 0u) {
        var used0 = 1000u;
        var used1 = 1000u;
        var off = 0u;
        for (var k = 0u; k < NPROBE; k += 1u) {
            var bs = -3.0e38;
            var bc = 0u;
            for (var j = 0u; j < NC; j += 1u) {
                if (j != used0 && j != used1 && red[j] > bs) {
                    bs = red[j];
                    bc = j;
                }
            }
            if (k == 0u) { used0 = bc; } else { used1 = bc; }
            let cnt = min(atomicLoad(&index_u32[bc & 127u]), CAP);
            let m = min(cnt, MAXM - off);
            wcen[k] = bc;
            woff[k] = off;
            wlen[k] = m;
            off += m;
        }
        wtotal = off;
    }
    workgroupBarrier();
    let total = wtotal;
    for (var i = 0u; i < 8u; i += 1u) {
        let g = i * 128u + t;
        if (g < total) {
            var k = 0u;
            if (g >= woff[1]) { k = 1u; }
            if (g >= woff[2]) { k = 2u; }
            let c = wcen[k] & 127u;
            let r = atomicLoad(&index_u32[(BASE + c * CAP + (g - woff[k])) & 0x7FFFFFu]);
            let rb = (r & 0x7FFFFu) * 512u;
            var dt = 0.0;
            var kn = 0.0;
            for (var d4 = 0u; d4 < 512u; d4 += 1u) {
                let kv = keys[rb + d4];
                dt += dot(kv, queries[qbase + d4]);
                kn += dot(kv, kv);
            }
            var sc = -1.0e30;
            if (kn > 0.0) {
                sc = dt * inverseSqrt(kn);
            }
            wscore[g] = sc;
            wrow[g] = r;
        }
    }
    workgroupBarrier();
    for (var i = 0u; i < 8u; i += 1u) {
        let g = i * 128u + t;
        if (g < total) {
            let si = wscore[g];
            var rank = 0u;
            for (var j = 0u; j < total; j += 1u) {
                let sj = wscore[j];
                if (sj > si || (sj == si && j < g)) {
                    rank += 1u;
                }
            }
            if (rank < 64u) {
                cands[q * 64u + rank] = wrow[g];
            }
        }
    }
}
