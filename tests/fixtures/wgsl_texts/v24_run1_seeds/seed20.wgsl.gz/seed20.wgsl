// passes 6
// Product-quantised coarse cells. A row is unit-normalised; its halves
// (dims 0..1023 and 1024..2047) are each quantised against their own
// 32-centroid codebook, and its cell is the code pair (a, b): 1,024 cells.
// The codebooks are trained on the first microbatch only: pass 0 seeds them
// with evenly spaced rows of that batch, then two spherical Lloyd rounds
// follow (pass 1 assigns, pass 2 re-centres, pass 3 assigns, pass 4
// re-centres). Pass 5 assigns each arriving row with the final codebooks
// and appends it to its cell's fixed-capacity member list. On later stages
// only pass 5 does work, because the codebooks are frozen.
// Search scores the query against all 64 sub-centroids, keeps the 12 best
// codes per half, and ranks the 144 code pairs by their summed asymmetric
// score. It opens cells in that order until a budget of 1,024 member rows
// is reached, then scores those rows exactly (dot times the stored inverse
// norm) and writes the best 64 by counting rank.

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const C_MAX: u32 = 64u;
const D4: u32 = 512u;
const HALF4: u32 = 256u;
const NC: u32 = 32u;
const CAP: u32 = 4096u;
const RMASK: u32 = 0x7FFFu;
const CELLMASK: u32 = 1023u;
const BUDGET: u32 = 1024u;
const TOPH: u32 = 12u;
const NPAIR: u32 = 144u;
const PAD: u32 = 0xFFFFFFFFu;

// index_f32 layout
const F_CN: u32 = 65536u;   // 64 squared sub-centroid norms
const F_INV: u32 = 65600u;  // inverse key norm per row
// index_u32 layout
const U_CODE: u32 = 0u;     // code per row
const U_CNT: u32 = 32768u;  // count per cell
const U_MEM: u32 = 65536u;  // cell members, CAP per cell

var<workgroup> red: array<f32, 256>;
var<workgroup> red2: array<f32, 256>;
var<workgroup> sc: array<f32, 64>;
var<workgroup> topA: array<u32, 12>;
var<workgroup> topB: array<u32, 12>;
var<workgroup> ps: array<f32, 144>;
var<workgroup> pc: array<u32, 144>;
var<workgroup> ord: array<u32, 144>;
var<workgroup> selCell: array<u32, 144>;
var<workgroup> selStart: array<u32, 145>;
var<workgroup> nsel: u32;
var<workgroup> ntot: u32;
var<workgroup> sscore: array<f32, 1024>;
var<workgroup> srow: array<u32, 1024>;

fn reduce2(t: u32) {
    workgroupBarrier();
    for (var k = 0u; k < 8u; k = k + 1u) {
        let s = 128u >> k;
        if (t < s) {
            red[t] = red[t] + red[t + s];
            red2[t] = red2[t] + red2[t + s];
        }
        workgroupBarrier();
    }
}

fn cent4(o: u32) -> vec4<f32> {
    let b = o & 0x7FFFFFu;
    return vec4<f32>(index_f32[b], index_f32[(b + 1u) & 0x7FFFFFu], index_f32[(b + 2u) & 0x7FFFFFu], index_f32[(b + 3u) & 0x7FFFFFu]);
}

fn init_centroid(j: u32, per: u32, t: u32) {
    let src = (cfg.arrived_begin + j * (per / NC) + per / (2u * NC)) & RMASK;
    let xa = keys[src * D4 + t];
    let xb = keys[src * D4 + HALF4 + t];
    red[t] = dot(xa, xa) + dot(xb, xb);
    red2[t] = 0.0;
    reduce2(t);
    let n2 = red[0];
    workgroupBarrier();
    var inv = 0.0;
    if (n2 > 0.0) {
        inv = inverseSqrt(n2);
    }
    let ca = xa * inv;
    let cb = xb * inv;
    let oa = (j * 1024u + t * 4u) & 0x7FFFFu;
    let ob = ((NC + j) * 1024u + t * 4u) & 0x7FFFFu;
    for (var c = 0u; c < 4u; c = c + 1u) {
        index_f32[oa + c] = ca[c];
        index_f32[ob + c] = cb[c];
    }
    red[t] = dot(ca, ca);
    red2[t] = dot(cb, cb);
    reduce2(t);
    if (t == 0u) {
        index_f32[F_CN + (j & 31u)] = red[0];
        index_f32[F_CN + NC + (j & 31u)] = red2[0];
    }
}

fn update_centroid(j: u32, per: u32, t: u32) {
    let h = j >> 5u;
    let c = j & 31u;
    var sum = vec4<f32>(0.0);
    var cnt = 0u;
    for (var i = 0u; i < per; i = i + 1u) {
        let ri = (cfg.arrived_begin + i) & RMASK;
        let code = atomicLoad(&index_u32[U_CODE + ri]);
        var cc = code & 31u;
        if (h == 0u) {
            cc = (code >> 5u) & 31u;
        }
        if (cc == c) {
            sum = sum + keys[ri * D4 + h * HALF4 + t] * index_f32[F_INV + ri];
            cnt = cnt + 1u;
        }
    }
    let o = ((j & 63u) * 1024u + t * 4u) & 0x7FFFFu;
    var m = cent4(o);
    if (cnt > 0u) {
        m = sum / f32(cnt);
    }
    for (var k = 0u; k < 4u; k = k + 1u) {
        index_f32[o + k] = m[k];
    }
    red[t] = dot(m, m);
    red2[t] = 0.0;
    reduce2(t);
    if (t == 0u) {
        index_f32[F_CN + (j & 63u)] = red[0];
    }
}

fn assign(r: u32, t: u32, insert: bool) {
    let rr = r & RMASK;
    let base = rr * D4;
    let xa = keys[base + t];
    let xb = keys[base + HALF4 + t];
    red[t] = dot(xa, xa) + dot(xb, xb);
    red2[t] = 0.0;
    reduce2(t);
    let n2 = red[0];
    workgroupBarrier();
    var inv = 0.0;
    if (n2 > 0.0) {
        inv = inverseSqrt(n2);
    }
    let j = t >> 2u;
    let p = t & 3u;
    let h = j >> 5u;
    let kb = base + h * HALF4 + p * 64u;
    let cb = j * 1024u + p * 256u;
    var s = 0.0;
    for (var i = 0u; i < 64u; i = i + 1u) {
        s = s + dot(keys[kb + i], cent4(cb + i * 4u));
    }
    red[t] = s;
    workgroupBarrier();
    if (t < 64u) {
        sc[t] = (red[t * 4u] + red[t * 4u + 1u] + red[t * 4u + 2u] + red[t * 4u + 3u]) * inv
            - 0.5 * index_f32[F_CN + t];
    }
    workgroupBarrier();
    if (t == 0u) {
        var a = 0u;
        var b = 0u;
        var ba = sc[0];
        var bb = sc[NC];
        for (var k = 1u; k < NC; k = k + 1u) {
            if (sc[k] > ba) {
                ba = sc[k];
                a = k;
            }
            if (sc[NC + k] > bb) {
                bb = sc[NC + k];
                b = k;
            }
        }
        let code = (a * NC + b) & CELLMASK;
        atomicStore(&index_u32[U_CODE + rr], code);
        index_f32[F_INV + rr] = inv;
        if (insert) {
            let slot = atomicAdd(&index_u32[U_CNT + code], 1u);
            if (slot < CAP) {
                atomicStore(&index_u32[U_MEM + code * CAP + slot], rr);
            }
        }
    }
}

@compute @workgroup_size(256)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let g = wid.x;
    let per = cfg.arrived_end - cfg.arrived_begin;
    let pi = cfg.pass_index;
    if (pi < 5u && cfg.stage != 1u) {
        return;
    }
    if (pi == 0u) {
        if (g < NC) {
            init_centroid(g, per, t);
        }
        return;
    }
    if (pi == 2u || pi == 4u) {
        if (g < 64u) {
            update_centroid(g, per, t);
        }
        return;
    }
    if (pi > 5u) {
        return;
    }
    let r = cfg.arrived_begin + g;
    if (r >= cfg.arrived_end) {
        return;
    }
    assign(r, t, pi == 5u);
}

@compute @workgroup_size(256)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let q = wid.x;
    let t = lid.x;
    if (q >= cfg.n_queries) {
        return;
    }
    let qbase = (q & 0x3FFFu) * D4;
    // Asymmetric scores against all 64 sub-centroids.
    let j = t >> 2u;
    let p = t & 3u;
    let h = j >> 5u;
    let qb = qbase + h * HALF4 + p * 64u;
    let cb = j * 1024u + p * 256u;
    var s = 0.0;
    for (var i = 0u; i < 64u; i = i + 1u) {
        s = s + dot(queries[qb + i], cent4(cb + i * 4u));
    }
    red[t] = s;
    workgroupBarrier();
    if (t < 64u) {
        sc[t] = red[t * 4u] + red[t * 4u + 1u] + red[t * 4u + 2u] + red[t * 4u + 3u];
    }
    workgroupBarrier();
    // Best TOPH codes per half, by counting rank.
    if (t < 64u) {
        let hb = (t >> 5u) << 5u;
        let my = sc[t];
        var rank = 0u;
        for (var k = 0u; k < NC; k = k + 1u) {
            let o = sc[hb + k];
            if (o > my || (o == my && hb + k < t)) {
                rank = rank + 1u;
            }
        }
        if (rank < TOPH) {
            if (t < NC) {
                topA[rank] = t;
            } else {
                topB[rank] = t - NC;
            }
        }
    }
    workgroupBarrier();
    if (t < NPAIR) {
        let a = topA[t / TOPH] & 31u;
        let b = topB[t % TOPH] & 31u;
        ps[t] = sc[a] + sc[NC + b];
        pc[t] = a * NC + b;
    }
    workgroupBarrier();
    if (t < NPAIR) {
        let my = ps[t];
        var rank = 0u;
        for (var k = 0u; k < NPAIR; k = k + 1u) {
            let o = ps[k];
            if (o > my || (o == my && k < t)) {
                rank = rank + 1u;
            }
        }
        ord[min(rank, NPAIR - 1u)] = t;
    }
    workgroupBarrier();
    // Open cells in pair order until the row budget is met.
    if (t == 0u) {
        var cum = 0u;
        var n = 0u;
        for (var k = 0u; k < NPAIR; k = k + 1u) {
            if (cum >= BUDGET) {
                break;
            }
            let cell = pc[ord[k] % NPAIR] & CELLMASK;
            let c = min(atomicLoad(&index_u32[U_CNT + cell]), CAP);
            if (c == 0u) {
                continue;
            }
            selCell[n] = cell;
            selStart[n] = cum;
            cum = cum + c;
            n = n + 1u;
        }
        selStart[n] = cum;
        nsel = n;
        ntot = min(cum, BUDGET);
    }
    workgroupBarrier();
    let n = nsel;
    let total = ntot;
    // Exact scoring of the gathered members.
    for (var i = 0u; i < BUDGET; i = i + 256u) {
        let e = i + t;
        if (e < total) {
            var k = 0u;
            for (var st = 0u; st < 8u; st = st + 1u) {
                let step = 128u >> st;
                if (k + step < n && selStart[k + step] <= e) {
                    k = k + step;
                }
            }
            let cell = selCell[k] & CELLMASK;
            let slot = min(e - selStart[k], CAP - 1u);
            let row = atomicLoad(&index_u32[U_MEM + cell * CAP + slot]) & RMASK;
            let rb = row * D4;
            var d = 0.0;
            for (var v = 0u; v < D4; v = v + 1u) {
                d = d + dot(keys[rb + v], queries[qbase + v]);
            }
            sscore[e] = d * index_f32[F_INV + row];
            srow[e] = row;
        }
    }
    workgroupBarrier();
    // Counting rank; the best C_MAX are written in rank slots.
    for (var i = 0u; i < BUDGET; i = i + 256u) {
        let e = i + t;
        if (e < total) {
            let my = sscore[e];
            var rank = 0u;
            for (var k = 0u; k < total; k = k + 1u) {
                let o = sscore[k];
                if (o > my || (o == my && k < e)) {
                    rank = rank + 1u;
                    if (rank >= C_MAX) {
                        break;
                    }
                }
            }
            let row = srow[e];
            if (rank < C_MAX && row < cfg.arrived_end) {
                cands[q * C_MAX + rank] = row;
            }
        }
    }
}
