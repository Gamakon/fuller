// grid 256 1 1 1
@group(0) @binding(0) var<storage, read_write> buffer_0_global: array<u32>;
@group(0) @binding(1) var<storage, read_write> buffer_1_global: array<f32>;
@group(0) @binding(2) var<storage, read_write> buffer_2_global: array<f32>;
@group(0) @binding(3) var<storage, read_write> buffer_3_global: array<f32>;
@group(0) @binding(4) var<storage, read_write> buffer_4_global: array<f32>;
@group(0) @binding(5) var<storage, read_write> buffer_5_global: array<u32>;
@group(0) @binding(6) var<storage, read_write> buffer_6_global: array<u32>;
@group(0) @binding(7) var<storage, read_write> buffer_7_global: array<f32>;
@group(0) @binding(8) var<storage, read_write> info: array<u32>;
var<workgroup> wg_a: array<f32, 1024>;
fn lit_f32(x: f32) -> f32 { return x; }
fn lit_u32(x: u32) -> u32 { return x; }
@compute @workgroup_size(256, 1, 1)
fn generated_step(@builtin(global_invocation_id) gid: vec3<u32>, @builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>, @builtin(local_invocation_index) lidx: u32, @builtin(num_workgroups) nwg: vec3<u32>) {
    var f0: f32 = 0.0; var f1: f32 = 0.0; var f2: f32 = 0.0; var f3: f32 = 0.0; var f4: f32 = 0.0; var f5: f32 = 0.0; var f6: f32 = 0.0; var f7: f32 = 0.0; 
    var f8: f32 = 0.0; var f9: f32 = 0.0; var f10: f32 = 0.0; var f11: f32 = 0.0; var f12: f32 = 0.0; var f13: f32 = 0.0; var f14: f32 = 0.0; var f15: f32 = 0.0; 
    var f16r: f32 = 0.0; var f17: f32 = 0.0; var f18: f32 = 0.0; var f19: f32 = 0.0; var f20: f32 = 0.0; var f21: f32 = 0.0; var f22: f32 = 0.0; var f23: f32 = 0.0; 
    var f24: f32 = 0.0; var f25: f32 = 0.0; var f26: f32 = 0.0; var f27: f32 = 0.0; var f28: f32 = 0.0; var f29: f32 = 0.0; var f30: f32 = 0.0; var f31: f32 = 0.0; 
    var f32r: f32 = 0.0; var f33: f32 = 0.0; var f34: f32 = 0.0; var f35: f32 = 0.0; var f36: f32 = 0.0; var f37: f32 = 0.0; var f38: f32 = 0.0; var f39: f32 = 0.0; 
    var f40: f32 = 0.0; var f41: f32 = 0.0; var f42: f32 = 0.0; var f43: f32 = 0.0; var f44: f32 = 0.0; var f45: f32 = 0.0; var f46: f32 = 0.0; var f47: f32 = 0.0; 
    var f48: f32 = 0.0; var f49: f32 = 0.0; var f50: f32 = 0.0; var f51: f32 = 0.0; var f52: f32 = 0.0; var f53: f32 = 0.0; var f54: f32 = 0.0; var f55: f32 = 0.0; 
    var f56: f32 = 0.0; var f57: f32 = 0.0; var f58: f32 = 0.0; var f59: f32 = 0.0; var f60: f32 = 0.0; var f61: f32 = 0.0; var f62: f32 = 0.0; var f63: f32 = 0.0; 
    var v0: vec4<f32> = vec4<f32>(0.0); var v1: vec4<f32> = vec4<f32>(0.0); var v2: vec4<f32> = vec4<f32>(0.0); var v3: vec4<f32> = vec4<f32>(0.0); var v4: vec4<f32> = vec4<f32>(0.0); var v5: vec4<f32> = vec4<f32>(0.0); var v6: vec4<f32> = vec4<f32>(0.0); var v7: vec4<f32> = vec4<f32>(0.0); 
    var v8: vec4<f32> = vec4<f32>(0.0); var v9: vec4<f32> = vec4<f32>(0.0); var v10: vec4<f32> = vec4<f32>(0.0); var v11: vec4<f32> = vec4<f32>(0.0); var v12: vec4<f32> = vec4<f32>(0.0); var v13: vec4<f32> = vec4<f32>(0.0); var v14: vec4<f32> = vec4<f32>(0.0); var v15: vec4<f32> = vec4<f32>(0.0); 
    var v16: vec4<f32> = vec4<f32>(0.0); var v17: vec4<f32> = vec4<f32>(0.0); var v18: vec4<f32> = vec4<f32>(0.0); var v19: vec4<f32> = vec4<f32>(0.0); var v20: vec4<f32> = vec4<f32>(0.0); var v21: vec4<f32> = vec4<f32>(0.0); var v22: vec4<f32> = vec4<f32>(0.0); var v23: vec4<f32> = vec4<f32>(0.0); 
    var v24: vec4<f32> = vec4<f32>(0.0); var v25: vec4<f32> = vec4<f32>(0.0); var v26: vec4<f32> = vec4<f32>(0.0); var v27: vec4<f32> = vec4<f32>(0.0); var v28: vec4<f32> = vec4<f32>(0.0); var v29: vec4<f32> = vec4<f32>(0.0); var v30: vec4<f32> = vec4<f32>(0.0); var v31: vec4<f32> = vec4<f32>(0.0); 
    var i0: u32 = 0u; var i1: u32 = 0u; var i2: u32 = 0u; var i3: u32 = 0u; var i4: u32 = 0u; var i5: u32 = 0u; var i6: u32 = 0u; var i7: u32 = 0u; 
    var i8: u32 = 0u; var i9: u32 = 0u; var i10: u32 = 0u; var i11: u32 = 0u; var i12: u32 = 0u; var i13: u32 = 0u; var i14: u32 = 0u; var i15: u32 = 0u; 
    var i16: u32 = 0u; var i17: u32 = 0u; var i18: u32 = 0u; var i19: u32 = 0u; var i20: u32 = 0u; var i21: u32 = 0u; var i22: u32 = 0u; var i23: u32 = 0u; 
    var i24: u32 = 0u; var i25: u32 = 0u; var i26: u32 = 0u; var i27: u32 = 0u; var i28: u32 = 0u; var i29: u32 = 0u; var i30: u32 = 0u; var i31: u32 = 0u; 
    var i32r: u32 = 0u; var i33: u32 = 0u; var i34: u32 = 0u; var i35: u32 = 0u; var i36: u32 = 0u; var i37: u32 = 0u; var i38: u32 = 0u; var i39: u32 = 0u; 
    var i40: u32 = 0u; var i41: u32 = 0u; var i42: u32 = 0u; var i43: u32 = 0u; var i44: u32 = 0u; var i45: u32 = 0u; var i46: u32 = 0u; var i47: u32 = 0u; 
    var i48: u32 = 0u; var i49: u32 = 0u; var i50: u32 = 0u; var i51: u32 = 0u; var i52: u32 = 0u; var i53: u32 = 0u; var i54: u32 = 0u; var i55: u32 = 0u; 
    var i56: u32 = 0u; var i57: u32 = 0u; var i58: u32 = 0u; var i59: u32 = 0u; var i60: u32 = 0u; var i61: u32 = 0u; var i62: u32 = 0u; var i63: u32 = 0u; 
    var b0: bool = false; var b1: bool = false; var b2: bool = false; var b3: bool = false; var b4: bool = false; var b5: bool = false; var b6: bool = false; var b7: bool = false; 
    var b8: bool = false; var b9: bool = false; var b10: bool = false; var b11: bool = false; var b12: bool = false; var b13: bool = false; var b14: bool = false; var b15: bool = false; 
    var n0: i32 = 0; var n1: i32 = 0; var n2: i32 = 0; var n3: i32 = 0; var n4: i32 = 0; var n5: i32 = 0; var n6: i32 = 0; var n7: i32 = 0; 
    var n8: i32 = 0; var n9: i32 = 0; var n10: i32 = 0; var n11: i32 = 0; var n12: i32 = 0; var n13: i32 = 0; var n14: i32 = 0; var n15: i32 = 0; 
    var u0: vec4<u32> = vec4<u32>(0u); var u1: vec4<u32> = vec4<u32>(0u); var u2: vec4<u32> = vec4<u32>(0u); var u3: vec4<u32> = vec4<u32>(0u); var u4: vec4<u32> = vec4<u32>(0u); var u5: vec4<u32> = vec4<u32>(0u); var u6: vec4<u32> = vec4<u32>(0u); var u7: vec4<u32> = vec4<u32>(0u); 
    var x0: mat2x2<f32> = mat2x2<f32>(); var x1: mat2x2<f32> = mat2x2<f32>(); 
    var y0: mat3x3<f32> = mat3x3<f32>(); var y1: mat3x3<f32> = mat3x3<f32>(); 
    var z0: mat4x4<f32> = mat4x4<f32>(); var z1: mat4x4<f32> = mat4x4<f32>(); 
    var t: u32 = 0u; var k: u32 = 0u; var k2: u32 = 0u; var k3: u32 = 0u; var k4: u32 = 0u;
    var pa: array<f32, 64>; var pb: array<f32, 64>; var pc: array<f32, 64>; var pd: array<f32, 64>; var pe: array<f32, 64>; var pf: array<f32, 64>;
    var pv: array<vec4<f32>, 16>; var pw: array<vec4<f32>, 16>; var px: array<vec4<f32>, 16>; var py: array<vec4<f32>, 16>; var pi: array<u32, 16>; var pj: array<u32, 16>; var pk: array<u32, 16>; var pm: array<bool, 16>; var pn: array<bool, 16>; var pq: array<vec2<f32>, 16>; var pr: array<vec2<f32>, 16>;
    f0 = 1.0f;
    i0 = lidx;
    for (t = 0u; t < min((lit_u32(1024u)), 16777216u); t = t + 256u) {
    wg_a[((t) & 1023u)] = buffer_2_global[(t)];
    }
    workgroupBarrier();
    i1 = ((gid.x + buffer_6_global[(lit_u32(0u))]) * 10u);
    i3 = 0u;
    i3 = u32((u32(buffer_5_global[(lit_u32(1u))]) ^ u32((gid.x + buffer_6_global[(lit_u32(0u))]))));
    i3 = u32((u32(i3) ^ (u32(i3) >> ((16u) & 31u))));
    i3 = (i3 * ((u32((lit_u32(34283u) << ((lit_u32(16u)) & 31u)))) | (lit_u32(51819u))));
    i3 = u32((u32(i3) ^ (u32(i3) >> ((13u) & 31u))));
    i3 = (i3 * ((u32((lit_u32(49842u) << ((lit_u32(16u)) & 31u)))) | (lit_u32(44597u))));
    i3 = u32((u32(i3) ^ (u32(i3) >> ((16u) & 31u))));
    i2 = i3;
    i4 = buffer_5_global[(lit_u32(2u))];
    for (k = 0u; k < 10u; k = k + 1u) {
    i3 = 0u;
    i3 = u32((u32(i2) ^ (u32(i4) ^ u32(k))));
    i3 = u32((u32(i3) ^ (u32(i3) >> ((16u) & 31u))));
    i3 = (i3 * ((u32((lit_u32(34283u) << ((lit_u32(16u)) & 31u)))) | (lit_u32(51819u))));
    i3 = u32((u32(i3) ^ (u32(i3) >> ((13u) & 31u))));
    i3 = (i3 * ((u32((lit_u32(49842u) << ((lit_u32(16u)) & 31u)))) | (lit_u32(44597u))));
    i3 = u32((u32(i3) ^ (u32(i3) >> ((16u) & 31u))));
    i5 = i3;
    f3 = (f1 + ((wg_a[((((i5) >> ((22u) & 31u))) & 1023u)] * buffer_1_global[(buffer_0_global[((i1 + k))])]) - f2));
    f2 = ((f3 - f1) - ((wg_a[((((i5) >> ((22u) & 31u))) & 1023u)] * buffer_1_global[(buffer_0_global[((i1 + k))])]) - f2));
    f1 = f3;
    f4 = (f4 + buffer_1_global[(buffer_0_global[((i1 + k))])]);
    }
    i3 = 0u;
    i3 = u32((u32(buffer_6_global[(lit_u32(1u))]) ^ u32((gid.x + buffer_6_global[(lit_u32(0u))]))));
    i3 = u32((u32(i3) ^ (u32(i3) >> ((16u) & 31u))));
    i3 = (i3 * ((u32((lit_u32(34283u) << ((lit_u32(16u)) & 31u)))) | (lit_u32(51819u))));
    i3 = u32((u32(i3) ^ (u32(i3) >> ((13u) & 31u))));
    i3 = (i3 * ((u32((lit_u32(49842u) << ((lit_u32(16u)) & 31u)))) | (lit_u32(44597u))));
    i3 = u32((u32(i3) ^ (u32(i3) >> ((16u) & 31u))));
    i6 = i3;
    i3 = 0u;
    i3 = u32((u32(i6) ^ (u32(buffer_6_global[(lit_u32(2u))]) ^ u32(buffer_6_global[(lit_u32(3u))]))));
    i3 = u32((u32(i3) ^ (u32(i3) >> ((16u) & 31u))));
    i3 = (i3 * ((u32((lit_u32(34283u) << ((lit_u32(16u)) & 31u)))) | (lit_u32(51819u))));
    i3 = u32((u32(i3) ^ (u32(i3) >> ((13u) & 31u))));
    i3 = (i3 * ((u32((lit_u32(49842u) << ((lit_u32(16u)) & 31u)))) | (lit_u32(44597u))));
    i3 = u32((u32(i3) ^ (u32(i3) >> ((16u) & 31u))));
    i7 = i3;
    if ((((((buffer_7_global[(lit_u32(1u))] * f1) + (buffer_7_global[(lit_u32(0u))] * f4)) + buffer_3_global[((gid.x + buffer_6_global[(lit_u32(0u))]))]) + (buffer_7_global[(lit_u32(4u))] * wg_a[((((i7) >> ((22u) & 31u))) & 1023u)])) <= 43.0f)) {
    f0 = tanh(((((buffer_7_global[(lit_u32(1u))] * f1) + (buffer_7_global[(lit_u32(0u))] * f4)) + buffer_3_global[((gid.x + buffer_6_global[(lit_u32(0u))]))]) + (buffer_7_global[(lit_u32(4u))] * wg_a[((((i7) >> ((22u) & 31u))) & 1023u)])));
    }
    if ((!((gid.x + buffer_6_global[(lit_u32(0u))]) >= buffer_5_global[(lit_u32(0u))]))) {
    buffer_4_global[((gid.x + buffer_6_global[(lit_u32(0u))]))] = ((((lit_f32(1.0f) - buffer_7_global[(lit_u32(2u))]) * buffer_1_global[((gid.x + buffer_6_global[(lit_u32(0u))]))]) + (buffer_7_global[(lit_u32(2u))] * f0)));
    }
}
