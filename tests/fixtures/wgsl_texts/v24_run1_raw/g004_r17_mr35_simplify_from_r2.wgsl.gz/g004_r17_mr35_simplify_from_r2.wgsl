// passes 1
@compute @workgroup_size(1)
fn ingest() {
}

@compute @workgroup_size(1)
fn search() {
}
