// grid 64 1 1
// entry ingest grid 64 1 1
// entry search grid 64 1 1
struct Cfg { seed_slot: u32, stage: u32, arrived_begin: u32, arrived_end: u32, n_queries: u32, pass_index: u32, n_passes: u32, c_max: u32, };
@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const K: u32 = 8u;

var<workgroup> red: array<f32, 64>;
var<workgroup> wscore: array<f32, 512>;
var<workgroup> wrow: array<u32, 512>;

@compute @workgroup_size(64, 1, 1)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = cfg.arrived_begin + wid.x;
    var acc = 0.0;
    for (var i = 0u; i < D4; i += 64u) {
        let j = i + t;
        if (j < D4) {
            let k = keys[(row & 0x7FFFu) * D4 + j];
            acc += dot(k, k);
        }
    }
    red[t] = acc;
    workgroupBarrier();
    for (var s = 32u; s > 0u; s = s >> 1u) {
        if (t < s) {
            red[t] = red[t] + red[t + s];
        }
        workgroupBarrier();
    }
    if (t == 0u) {
        var inv = 0.0;
        if (red[0] > 0.0) {
            inv = inverseSqrt(red[0]);
        }
        index_f32[row & 0x7FFFu] = inv;
    }
}

@compute @workgroup_size(64, 1, 1)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let q = wid.x;
    let t = lid.x;
    var best: array<f32, 8>;
    var rows: array<u32, 8>;
    for (var j = 0u; j < K; j += 1u) {
        best[j] = NONE;
        rows[j] = PAD;
    }
    if (q < cfg.n_queries) {
        let qb = (q & 0xFFFFu) * D4;
        for (var i = 0u; i < cfg.arrived_end; i += 64u) {
            let r = i + t;
            if (r < cfg.arrived_end) {
                var s = 0.0;
                let rb = (r & 0x7FFFFu) * D4;
                for (var d = 0u; d < D4; d += 1u) {
                    s += dot(keys[rb + d], queries[qb + d]);
                }
                let score = s * index_f32[r & 0x7FFFu];
                if (score > best[K - 1u]) {
                    var cs = score;
                    var cr = r;
                    for (var j = 0u; j < K; j += 1u) {
                        if (cs > best[j]) {
                            let ts = best[j];
                            let tr = rows[j];
                            best[j] = cs;
                            rows[j] = cr;
                            cs = ts;
                            cr = tr;
                        }
                    }
                }
            }
        }
    }
    for (var j = 0u; j < K; j += 1u) {
        wscore[t * K + j] = best[j];
        wrow[t * K + j] = rows[j];
    }
    workgroupBarrier();
    if (q < cfg.n_queries) {
        for (var m = 0u; m < K; m += 1u) {
            let e = t * K + m;
            let es = wscore[e];
            let er = wrow[e];
            if (er != PAD) {
                var rank = 0u;
                for (var o = 0u; o < 512u; o += 1u) {
                    let os = wscore[o];
                    if (wrow[o] != PAD && (os > es || (os == es && o < e))) {
                        rank += 1u;
                    }
                }
                if (rank < 64u) {
                    cands[q * 64u + rank] = er;
                }
            }
        }
    }
}
