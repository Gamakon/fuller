// passes 3
// Centre-graph bucket index.
// Stage 1 takes 256 centres from the first microbatch: they are strided over
// arrival time and normalised. Each centre links to its 8 nearest centres.
// A row is assigned by a greedy beam over that graph (8 entries, 16
// expansions), never by an exhaustive scan. It is spilled into its 2 best
// buckets. Search runs the same beam for the query, takes the 8 best visited
// centres and scans their members exactly with cached inverse norms. It
// returns the best 32 distinct rows.

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const C_MAX: u32 = 64u;
const NC: u32 = 256u;
const K: u32 = 8u;
const D4: u32 = 512u;
const D: u32 = 2048u;
const CAP: u32 = 4096u;
const LINK_BASE: u32 = 256u;
const MEM_BASE: u32 = 4096u;
const INV_BASE: u32 = 524288u;
const AMASK: u32 = 0x7FFFFFu;
const ENTRIES: u32 = 8u;
const EXPANSIONS: u32 = 16u;
const NP: u32 = 8u;
const L: u32 = 6u;
const OUT: u32 = 32u;
const ROUNDS: u32 = 48u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const HALF: f32 = -1.0e38;

var<workgroup> vq: array<vec4<f32>, 512>;
var<workgroup> cscore: array<f32, 256>;
var<workgroup> expd: array<u32, 256>;
var<workgroup> partial: array<f32, 256>;
var<workgroup> redv: array<f32, 256>;
var<workgroup> redi: array<u32, 256>;
var<workgroup> pend: array<u32, 8>;
var<workgroup> sel: array<u32, 8>;
var<workgroup> wrow: u32;

fn centre4(c: u32, d4: u32) -> vec4<f32> {
    let base = c * D + d4 * 4u;
    return vec4<f32>(
        index_f32[base & AMASK],
        index_f32[(base + 1u) & AMASK],
        index_f32[(base + 2u) & AMASK],
        index_f32[(base + 3u) & AMASK]);
}

fn argmax_tree(t: u32) {
    workgroupBarrier();
    for (var k = 0u; k < 8u; k = k + 1u) {
        let s = 128u >> k;
        if (t < s) {
            let a = redv[t];
            let b = redv[t + s];
            if (b > a || (b == a && redi[t + s] < redi[t])) {
                redv[t] = b;
                redi[t] = redi[t + s];
            }
        }
        workgroupBarrier();
    }
}

// Scores the up-to-8 centres in pend against vq: 32 threads a centre.
fn score_batch(t: u32) {
    workgroupBarrier();
    let slot = t / 32u;
    let lane = t % 32u;
    let c = pend[slot];
    var s = 0.0;
    if (c < NC) {
        for (var i = 0u; i < 16u; i = i + 1u) {
            let d4 = i * 32u + lane;
            s = s + dot(vq[d4], centre4(c, d4));
        }
    }
    partial[t] = s;
    workgroupBarrier();
    if (t < 8u) {
        let cc = pend[t];
        if (cc < NC) {
            var sum = 0.0;
            for (var j = 0u; j < 32u; j = j + 1u) {
                sum = sum + partial[t * 32u + j];
            }
            cscore[cc] = sum;
        }
    }
    workgroupBarrier();
}

// Greedy best-first beam over the centre graph, scoring into cscore.
fn beam(t: u32, salt: u32) {
    cscore[t] = NONE;
    expd[t] = 0u;
    if (t < ENTRIES) {
        pend[t] = (t * 32u + salt) % NC;
    }
    score_batch(t);
    for (var e = 0u; e < EXPANSIONS; e = e + 1u) {
        let cs = cscore[t];
        var v = NONE;
        if (cs > HALF && expd[t] == 0u) {
            v = cs;
        }
        redv[t] = v;
        redi[t] = t;
        argmax_tree(t);
        let best = redi[0] % NC;
        let bv = redv[0];
        if (t < 8u) {
            var n = PAD;
            if (bv > HALF) {
                let l = atomicLoad(&index_u32[(LINK_BASE + best * K + t) & AMASK]);
                if (l < NC) {
                    if (cscore[l] <= HALF) {
                        n = l;
                    }
                }
            }
            pend[t] = n;
        }
        if (t == 0u && bv > HALF) {
            expd[best] = 1u;
        }
        score_batch(t);
    }
}

// Picks the n best centres by cscore into sel[0..n), consuming them.
fn topk(t: u32, n: u32) {
    for (var k = 0u; k < 8u; k = k + 1u) {
        if (k < n) {
            redv[t] = cscore[t];
            redi[t] = t;
        }
        argmax_tree(t);
        let w = redi[0];
        let wv = redv[0];
        workgroupBarrier();
        if (k < n) {
            if (t == w) {
                cscore[t] = NONE;
            }
            if (t == 0u) {
                if (wv > HALF) {
                    sel[k] = w;
                } else {
                    sel[k] = PAD;
                }
            }
        }
        workgroupBarrier();
    }
}

@compute @workgroup_size(256)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let local = wid.x;
    let r = cfg.arrived_begin + local;
    let per = cfg.arrived_end - cfg.arrived_begin;
    let kb = (r & 0x7FFFFu) * D4;

    if (cfg.pass_index == 0u) {
        let a = keys[kb + t];
        let b = keys[kb + t + 256u];
        partial[t] = dot(a, a) + dot(b, b);
        workgroupBarrier();
        for (var k = 0u; k < 8u; k = k + 1u) {
            let s = 128u >> k;
            if (t < s) {
                partial[t] = partial[t] + partial[t + s];
            }
            workgroupBarrier();
        }
        let nn = partial[0];
        var inv = 0.0;
        if (nn > 0.0) {
            inv = inverseSqrt(nn);
        }
        if (t == 0u && r < cfg.arrived_end) {
            index_f32[(INV_BASE + (r & 0x7FFFu)) & AMASK] = inv;
        }
        if (cfg.stage == 1u) {
            let stride = max(1u, per / NC);
            if (local % stride == 0u) {
                let c = local / stride;
                if (c < NC) {
                    let ba = c * D + t * 4u;
                    let bb = c * D + (t + 256u) * 4u;
                    index_f32[ba & AMASK] = a.x * inv;
                    index_f32[(ba + 1u) & AMASK] = a.y * inv;
                    index_f32[(ba + 2u) & AMASK] = a.z * inv;
                    index_f32[(ba + 3u) & AMASK] = a.w * inv;
                    index_f32[bb & AMASK] = b.x * inv;
                    index_f32[(bb + 1u) & AMASK] = b.y * inv;
                    index_f32[(bb + 2u) & AMASK] = b.z * inv;
                    index_f32[(bb + 3u) & AMASK] = b.w * inv;
                }
            }
        }
    } else if (cfg.pass_index == 1u) {
        if (cfg.stage == 1u && local < NC) {
            vq[t] = centre4(local, t);
            vq[t + 256u] = centre4(local, t + 256u);
            workgroupBarrier();
            var s = 0.0;
            for (var d = 0u; d < D4; d = d + 1u) {
                s = s + dot(vq[d], centre4(t, d));
            }
            if (t == local) {
                s = NONE;
            }
            cscore[t] = s;
            topk(t, K);
            if (t < K) {
                atomicStore(&index_u32[(LINK_BASE + local * K + t) & AMASK], sel[t]);
            }
        }
    } else {
        if (r < cfg.arrived_end) {
            vq[t] = keys[kb + t];
            vq[t + 256u] = keys[kb + t + 256u];
            beam(t, local % 32u);
            topk(t, 2u);
            if (t == 0u) {
                for (var k = 0u; k < 2u; k = k + 1u) {
                    let bk = sel[k];
                    if (bk < NC) {
                        let slot = atomicAdd(&index_u32[bk], 1u);
                        if (slot < CAP) {
                            atomicStore(&index_u32[(MEM_BASE + bk * CAP + slot) & AMASK], r);
                        }
                    }
                }
            }
        }
    }
}

@compute @workgroup_size(256)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let qb = (q & 0x7FFFu) * D4;
    vq[t] = queries[qb + t];
    vq[t + 256u] = queries[qb + t + 256u];
    beam(t, 7u);
    topk(t, NP);

    var lv: array<f32, 6>;
    var lr: array<u32, 6>;
    for (var j = 0u; j < L; j = j + 1u) {
        lv[j] = NONE;
        lr[j] = PAD;
    }
    for (var b = 0u; b < NP; b = b + 1u) {
        let bk = sel[b];
        if (bk < NC) {
            let cnt = min(atomicLoad(&index_u32[bk]), CAP);
            for (var i = 0u; i < CAP; i = i + 256u) {
                let j = i + t;
                if (j < cnt) {
                    let rr = atomicLoad(&index_u32[(MEM_BASE + bk * CAP + j) & AMASK]);
                    if (rr < cfg.arrived_end) {
                        let kb = (rr & 0x7FFFFu) * D4;
                        var s = 0.0;
                        for (var d = 0u; d < D4; d = d + 1u) {
                            s = s + dot(keys[kb + d], vq[d]);
                        }
                        let sc = s * index_f32[(INV_BASE + (rr & 0x7FFFu)) & AMASK];
                        if (sc > lv[L - 1u]) {
                            var dup = false;
                            for (var m = 0u; m < L; m = m + 1u) {
                                if (lr[m] == rr) {
                                    dup = true;
                                }
                            }
                            if (!dup) {
                                var cs = sc;
                                var cr = rr;
                                for (var m = 0u; m < L; m = m + 1u) {
                                    if (cs > lv[m]) {
                                        let ts = lv[m];
                                        let tr = lr[m];
                                        lv[m] = cs;
                                        lr[m] = cr;
                                        cs = ts;
                                        cr = tr;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    var head = 0u;
    var nout = 0u;
    var last = PAD;
    for (var k = 0u; k < ROUNDS; k = k + 1u) {
        var hv = NONE;
        if (head < L) {
            hv = lv[head];
        }
        redv[t] = hv;
        redi[t] = t;
        argmax_tree(t);
        let w = redi[0];
        let wv = redv[0];
        if (t == w && head < L) {
            wrow = lr[head];
            head = head + 1u;
        }
        workgroupBarrier();
        let row = wrow;
        if (wv > HALF && row != PAD && row != last && nout < OUT) {
            if (t == 0u && q < cfg.n_queries && row < cfg.arrived_end) {
                cands[q * C_MAX + nout] = row;
            }
            nout = nout + 1u;
            last = row;
        }
        workgroupBarrier();
    }
}
