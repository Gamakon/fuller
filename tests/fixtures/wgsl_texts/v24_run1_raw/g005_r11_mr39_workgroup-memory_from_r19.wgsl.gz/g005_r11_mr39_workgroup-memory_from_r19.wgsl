// passes 1
struct Cfg { seed_slot: u32, stage: u32, arrived_begin: u32, arrived_end: u32, n_queries: u32, pass_index: u32, n_passes: u32, c_max: u32, };

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const D4: u32 = 512u;
const NS: u32 = 128u;

var<workgroup> wq: array<vec4<f32>, 128>;
var<workgroup> wscore: array<f32, 256>;
var<workgroup> bscore: array<f32, 64>;
var<workgroup> brow: array<u32, 64>;

@compute @workgroup_size(1)
fn ingest() {
}

@compute @workgroup_size(256)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let q = wid.x;
    let t = lid.x;
    if (q >= cfg.n_queries) {
        return;
    }
    if (t < NS) {
        wq[t] = queries[(q & 0xFFFFu) * D4 + t * 4u];
    }
    if (t < 64u) {
        bscore[t] = NONE;
        brow[t] = PAD;
    }
    workgroupBarrier();
    for (var base = 0u; base < cfg.arrived_end; base += 256u) {
        let r = base + t;
        var score = NONE;
        if (r < cfg.arrived_end) {
            var s = 0.0;
            var kn = 0.0;
            let off = (r & 0x7FFFFu) * D4;
            for (var i = 0u; i < NS; i += 1u) {
                let k = keys[off + i * 4u];
                s = s + dot(k, wq[i]);
                kn = kn + dot(k, k);
            }
            if (kn > 0.0) {
                score = s / sqrt(kn);
            }
        }
        wscore[t] = score;
        workgroupBarrier();
        if (t == 0u) {
            for (var j = 0u; j < 256u; j += 1u) {
                let sc = wscore[j];
                if (sc > bscore[63]) {
                    var cs = sc;
                    var cr = base + j;
                    for (var m = 0u; m < 64u; m += 1u) {
                        if (cs > bscore[m]) {
                            let ts = bscore[m];
                            let tr = brow[m];
                            bscore[m] = cs;
                            brow[m] = cr;
                            cs = ts;
                            cr = tr;
                        }
                    }
                }
            }
        }
        workgroupBarrier();
    }
    if (t < 64u) {
        cands[(q & 0xFFFFu) * 64u + t] = brow[t];
    }
}
