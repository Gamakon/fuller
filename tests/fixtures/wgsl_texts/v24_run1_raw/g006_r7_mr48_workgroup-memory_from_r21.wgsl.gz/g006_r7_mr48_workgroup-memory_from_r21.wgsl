// passes 1
struct Cfg { seed_slot: u32, stage: u32, arrived_begin: u32, arrived_end: u32, n_queries: u32, pass_index: u32, n_passes: u32, c_max: u32, };
@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const CAP: u32 = 8192u;
const NC: u32 = 64u;
const NP: u32 = 8u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -1.0e30;

var<workgroup> vsh: array<vec4<f32>, 512>;
var<workgroup> csc: array<f32, 64>;
var<workgroup> sel: array<u32, 8>;
var<workgroup> wsc: array<f32, 512>;
var<workgroup> wrw: array<u32, 512>;

fn centre_score(c: u32) -> f32 {
    var s = 0.0;
    var kn = 0.0;
    for (var d = 0u; d < 512u; d = d + 1u) {
        let k = keys[(c & 63u) * 512u + d];
        s = s + dot(k, vsh[d]);
        kn = kn + dot(k, k);
    }
    var r = NONE;
    if (kn > 0.0) {
        r = s * inverseSqrt(kn);
    }
    return r;
}

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = cfg.arrived_begin + wid.x;
    for (var i = 0u; i < 8u; i = i + 1u) {
        let d = i * 64u + t;
        vsh[d] = keys[(row & 0x7FFFFu) * 512u + d];
    }
    workgroupBarrier();
    csc[t] = centre_score(t);
    workgroupBarrier();
    if (t == 0u && row < cfg.arrived_end) {
        var bi = 0u;
        var bs = csc[0];
        for (var c = 1u; c < NC; c = c + 1u) {
            if (csc[c] > bs) {
                bs = csc[c];
                bi = c;
            }
        }
        let slot = atomicAdd(&index_u32[bi & 63u], 1u);
        if (slot < CAP) {
            atomicStore(&index_u32[(64u + (bi & 63u) * CAP + slot) & 0x7FFFFFu], row);
        }
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    for (var i = 0u; i < 8u; i = i + 1u) {
        let d = i * 64u + t;
        vsh[d] = queries[(q & 0xFFFFu) * 512u + d];
    }
    workgroupBarrier();
    csc[t] = centre_score(t);
    workgroupBarrier();
    if (t == 0u) {
        for (var j = 0u; j < NP; j = j + 1u) {
            var bi = 0u;
            var bs = -3.0e38;
            for (var c = 0u; c < NC; c = c + 1u) {
                if (csc[c] > bs) {
                    bs = csc[c];
                    bi = c;
                }
            }
            sel[j] = bi;
            csc[bi] = -3.0e38;
        }
    }
    workgroupBarrier();
    var best: array<f32, 8>;
    var rows: array<u32, 8>;
    for (var j = 0u; j < 8u; j = j + 1u) {
        best[j] = NONE;
        rows[j] = PAD;
    }
    var qn = 0.0;
    for (var d = 0u; d < 512u; d = d + 1u) {
        qn = qn + dot(vsh[d], vsh[d]);
    }
    for (var p = 0u; p < NP; p = p + 1u) {
        let b = sel[p] & 63u;
        let n = min(atomicLoad(&index_u32[b]), CAP);
        for (var i = 0u; i < CAP; i = i + 64u) {
            if (i >= n) {
                break;
            }
            let m = i + t;
            if (m < n) {
                let r = atomicLoad(&index_u32[(64u + b * CAP + m) & 0x7FFFFFu]);
                var s = 0.0;
                var kn = 0.0;
                for (var d = 0u; d < 512u; d = d + 1u) {
                    let k = keys[(r & 0x7FFFFu) * 512u + d];
                    s = s + dot(k, vsh[d]);
                    kn = kn + dot(k, k);
                }
                var score = NONE;
                if (kn > 0.0 && qn > 0.0) {
                    score = s * inverseSqrt(kn * qn);
                }
                if (score > best[7]) {
                    var cs = score;
                    var cr = r;
                    for (var j = 0u; j < 8u; j = j + 1u) {
                        if (cs > best[j]) {
                            let ts = best[j];
                            let tr = rows[j];
                            best[j] = cs;
                            rows[j] = cr;
                            cs = ts;
                            cr = tr;
                        }
                    }
                }
            }
        }
    }
    for (var j = 0u; j < 8u; j = j + 1u) {
        wsc[t * 8u + j] = best[j];
        wrw[t * 8u + j] = rows[j];
    }
    workgroupBarrier();
    if (t == 0u && q < cfg.n_queries) {
        for (var k = 0u; k < 64u; k = k + 1u) {
            var bi = 0u;
            var bs = -3.0e38;
            for (var i = 0u; i < 512u; i = i + 1u) {
                if (wsc[i] > bs) {
                    bs = wsc[i];
                    bi = i;
                }
            }
            if (bs > NONE * 0.5) {
                cands[(q * 64u + k) & 0x3FFFFFu] = wrw[bi];
            }
            wsc[bi] = -3.0e38;
        }
    }
}
