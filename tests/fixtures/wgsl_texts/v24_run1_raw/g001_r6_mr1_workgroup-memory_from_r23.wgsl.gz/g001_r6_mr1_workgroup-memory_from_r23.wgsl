// passes 3
// Online k-means with drift, using 256 centres. Centres are stored dimension-major
// (index_f32[d * 256 + c]), so thread c of a workgroup scores centre c and the reads
// across threads are coalesced. The running means do not use f32 atomics. Each
// member's unit key is added into a fixed-point i32 sum in index_u32 with atomicAdd,
// and the last pass of each stage rewrites every centre as its normalised sum.
// That rewrite is the drift. Seeding happens once, at stage 1 pass 0: 256 rows are
// sampled at a stride across the first microbatch.
// Search ranks the centres and takes the 8 best by repeated argmax. The probe list is
// kept in workgroup memory, shared by all threads. Each thread scans
// a strided share of those buckets' members exactly and keeps its own top 16. The
// final 64 slots are chosen by a 32-step bitwise threshold search over the
// order-preserving u32 form of the scores, with no list merge.
//
// index_u32: [0, 524288) fixed-point centre sums (c * 2048 + d), [524288, +256) counts,
//            [1048576, +256 * 25600) bucket member lists.
// index_f32: [0, 524288) unit centres, stored dimension-major; [524288, +rows) the inverse norm of each row.

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const C_MAX: u32 = 64u;
const D: u32 = 2048u;
const D4: u32 = 512u;
const K: u32 = 256u;
const AMASK: u32 = 0x7FFFFFu;
const RMASK: u32 = 0x7FFFFu;
const SUM_BASE: u32 = 0u;
const CNT_BASE: u32 = 524288u;
const BKT_BASE: u32 = 1048576u;
const CAP: u32 = 25600u;
const CT_BASE: u32 = 0u;
const INV_BASE: u32 = 524288u;
const FIX: f32 = 32768.0;
const PROBES: u32 = 8u;
const LK: u32 = 16u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;

var<workgroup> wv: array<vec4<f32>, 512>;
var<workgroup> rs: array<f32, 256>;
var<workgroup> ri: array<u32, 256>;
var<workgroup> wcnt: array<atomic<u32>, 34>;
var<workgroup> wprobe: array<u32, 8>;

fn ord_key(f: f32) -> u32 {
    let b = bitcast<u32>(f);
    if ((b & 0x80000000u) != 0u) {
        return ~b;
    }
    return b | 0x80000000u;
}

fn ct_index(d: u32, c: u32) -> u32 {
    return (CT_BASE + d * K + c) & AMASK;
}

@compute @workgroup_size(256)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = cfg.arrived_begin + wid.x;
    let live = row < cfg.arrived_end;
    let rr = row & RMASK;

    if (cfg.pass_index == 0u) {
        var v0 = vec4<f32>(0.0);
        var v1 = vec4<f32>(0.0);
        if (live) {
            v0 = keys[rr * D4 + t];
            v1 = keys[rr * D4 + 256u + t];
        }
        rs[t] = dot(v0, v0) + dot(v1, v1);
        workgroupBarrier();
        for (var k = 0u; k < 8u; k = k + 1u) {
            let s = 128u >> k;
            if (t < s) {
                rs[t] = rs[t] + rs[t + s];
            }
            workgroupBarrier();
        }
        let n2 = rs[0];
        var inv = 0.0;
        if (n2 > 0.0) {
            inv = inverseSqrt(n2);
        }
        if (live && t == 0u) {
            index_f32[(INV_BASE + rr) & AMASK] = inv;
        }
        if (live && cfg.stage == 1u) {
            let n = cfg.arrived_end - cfg.arrived_begin;
            let stride = max(1u, n / K);
            let w = wid.x;
            if ((w % stride) == 0u && (w / stride) < K) {
                let c = w / stride;
                let d0 = t * 4u;
                let d1 = (256u + t) * 4u;
                index_f32[ct_index(d0, c)] = v0.x * inv;
                index_f32[ct_index(d0 + 1u, c)] = v0.y * inv;
                index_f32[ct_index(d0 + 2u, c)] = v0.z * inv;
                index_f32[ct_index(d0 + 3u, c)] = v0.w * inv;
                index_f32[ct_index(d1, c)] = v1.x * inv;
                index_f32[ct_index(d1 + 1u, c)] = v1.y * inv;
                index_f32[ct_index(d1 + 2u, c)] = v1.z * inv;
                index_f32[ct_index(d1 + 3u, c)] = v1.w * inv;
            }
        }
    }

    if (cfg.pass_index == 1u) {
        let inv = index_f32[(INV_BASE + rr) & AMASK];
        var a0 = vec4<f32>(0.0);
        var a1 = vec4<f32>(0.0);
        if (live) {
            a0 = keys[rr * D4 + t] * inv;
            a1 = keys[rr * D4 + 256u + t] * inv;
        }
        wv[t] = a0;
        wv[t + 256u] = a1;
        workgroupBarrier();
        var s = NONE;
        if (live && inv > 0.0) {
            s = 0.0;
            for (var d4 = 0u; d4 < D4; d4 = d4 + 1u) {
                let kv = wv[d4];
                let b = d4 * 4u;
                s = s + index_f32[ct_index(b, t)] * kv.x
                      + index_f32[ct_index(b + 1u, t)] * kv.y
                      + index_f32[ct_index(b + 2u, t)] * kv.z
                      + index_f32[ct_index(b + 3u, t)] * kv.w;
            }
        }
        rs[t] = s;
        ri[t] = t;
        workgroupBarrier();
        for (var k = 0u; k < 8u; k = k + 1u) {
            let h = 128u >> k;
            if (t < h) {
                let sa = rs[t];
                let sb = rs[t + h];
                let ia = ri[t];
                let ib = ri[t + h];
                if (sb > sa || (sb == sa && ib < ia)) {
                    rs[t] = sb;
                    ri[t] = ib;
                }
            }
            workgroupBarrier();
        }
        let c = ri[0] & 255u;
        let best = rs[0];
        if (live && inv > 0.0 && best > NONE) {
            if (t == 0u) {
                let slot = atomicAdd(&index_u32[(CNT_BASE + c) & AMASK], 1u);
                if (slot < CAP) {
                    atomicStore(&index_u32[(BKT_BASE + c * CAP + slot) & AMASK], row);
                }
            }
            let sb = SUM_BASE + c * D;
            let d0 = t * 4u;
            let d1 = (256u + t) * 4u;
            atomicAdd(&index_u32[(sb + d0) & AMASK], bitcast<u32>(i32(round(a0.x * FIX))));
            atomicAdd(&index_u32[(sb + d0 + 1u) & AMASK], bitcast<u32>(i32(round(a0.y * FIX))));
            atomicAdd(&index_u32[(sb + d0 + 2u) & AMASK], bitcast<u32>(i32(round(a0.z * FIX))));
            atomicAdd(&index_u32[(sb + d0 + 3u) & AMASK], bitcast<u32>(i32(round(a0.w * FIX))));
            atomicAdd(&index_u32[(sb + d1) & AMASK], bitcast<u32>(i32(round(a1.x * FIX))));
            atomicAdd(&index_u32[(sb + d1 + 1u) & AMASK], bitcast<u32>(i32(round(a1.y * FIX))));
            atomicAdd(&index_u32[(sb + d1 + 2u) & AMASK], bitcast<u32>(i32(round(a1.z * FIX))));
            atomicAdd(&index_u32[(sb + d1 + 3u) & AMASK], bitcast<u32>(i32(round(a1.w * FIX))));
        }
    }

    if (cfg.pass_index == 2u) {
        let c = wid.x;
        if (c < K) {
            let n = atomicLoad(&index_u32[(CNT_BASE + c) & AMASK]);
            var vals: array<f32, 8>;
            var p = 0.0;
            for (var k = 0u; k < 8u; k = k + 1u) {
                let d = k * 256u + t;
                let v = f32(bitcast<i32>(atomicLoad(&index_u32[(SUM_BASE + c * D + d) & AMASK])));
                vals[k] = v;
                p = p + v * v;
            }
            rs[t] = p;
            workgroupBarrier();
            for (var k = 0u; k < 8u; k = k + 1u) {
                let h = 128u >> k;
                if (t < h) {
                    rs[t] = rs[t] + rs[t + h];
                }
                workgroupBarrier();
            }
            let n2 = rs[0];
            if (n > 0u && n2 > 0.0) {
                let inv = inverseSqrt(n2);
                for (var k = 0u; k < 8u; k = k + 1u) {
                    let d = k * 256u + t;
                    index_f32[ct_index(d, c)] = vals[k] * inv;
                }
            }
        }
    }
}

@compute @workgroup_size(256)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let qv = q < cfg.n_queries;
    let qb = (q & RMASK) * D4;

    var a0 = vec4<f32>(0.0);
    var a1 = vec4<f32>(0.0);
    if (qv) {
        a0 = queries[qb + t];
        a1 = queries[qb + 256u + t];
    }
    wv[t] = a0;
    wv[t + 256u] = a1;
    if (t < 34u) {
        atomicStore(&wcnt[t], 0u);
    }
    workgroupBarrier();

    var cs = NONE;
    let cn = atomicLoad(&index_u32[(CNT_BASE + t) & AMASK]);
    if (cn > 0u) {
        cs = 0.0;
        for (var d4 = 0u; d4 < D4; d4 = d4 + 1u) {
            let kv = wv[d4];
            let b = d4 * 4u;
            cs = cs + index_f32[ct_index(b, t)] * kv.x
                    + index_f32[ct_index(b + 1u, t)] * kv.y
                    + index_f32[ct_index(b + 2u, t)] * kv.z
                    + index_f32[ct_index(b + 3u, t)] * kv.w;
        }
    }

    // Take the 8 best centres by repeated argmax; keep them in workgroup memory.
    for (var r = 0u; r < PROBES; r = r + 1u) {
        rs[t] = cs;
        ri[t] = t;
        workgroupBarrier();
        for (var k = 0u; k < 8u; k = k + 1u) {
            let h = 128u >> k;
            if (t < h) {
                let sa = rs[t];
                let sb = rs[t + h];
                let ia = ri[t];
                let ib = ri[t + h];
                if (sb > sa || (sb == sa && ib < ia)) {
                    rs[t] = sb;
                    ri[t] = ib;
                }
            }
            workgroupBarrier();
        }
        let w = ri[0];
        let ws = rs[0];
        if (t == 0u) {
            wprobe[r] = select(PAD, w, ws > NONE);
        }
        workgroupBarrier();
        if (t == w) {
            cs = NONE;
        }
    }

    var lk: array<u32, 16>;
    var lr: array<u32, 16>;
    for (var e = 0u; e < LK; e = e + 1u) {
        lk[e] = 0u;
        lr[e] = PAD;
    }
    if (qv) {
        for (var r = 0u; r < PROBES; r = r + 1u) {
            let b = wprobe[r];
            if (b != PAD) {
                let bb = b & 255u;
                let n = min(atomicLoad(&index_u32[(CNT_BASE + bb) & AMASK]), CAP);
                for (var i = 0u; i < CAP; i = i + 256u) {
                    if (i >= n) {
                        break;
                    }
                    let j = i + t;
                    if (j < n) {
                        let row = atomicLoad(&index_u32[(BKT_BASE + bb * CAP + j) & AMASK]);
                        if (row < cfg.arrived_end) {
                            let rm = row & RMASK;
                            let inv = index_f32[(INV_BASE + rm) & AMASK];
                            if (inv > 0.0) {
                                var s = 0.0;
                                for (var d4 = 0u; d4 < D4; d4 = d4 + 1u) {
                                    s = s + dot(keys[rm * D4 + d4], wv[d4]);
                                }
                                let key = ord_key(s * inv);
                                if (key > lk[LK - 1u]) {
                                    var ck = key;
                                    var cr = row;
                                    for (var e = 0u; e < LK; e = e + 1u) {
                                        if (ck > lk[e]) {
                                            let tk = lk[e];
                                            let tr = lr[e];
                                            lk[e] = ck;
                                            lr[e] = cr;
                                            ck = tk;
                                            cr = tr;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    var thr = 0u;
    for (var bit = 0u; bit < 32u; bit = bit + 1u) {
        let cand = thr | (0x80000000u >> bit);
        var c = 0u;
        for (var e = 0u; e < LK; e = e + 1u) {
            if (lk[e] >= cand) {
                c = c + 1u;
            }
        }
        atomicAdd(&wcnt[bit], c);
        workgroupBarrier();
        let tot = atomicLoad(&wcnt[bit]);
        if (tot >= C_MAX) {
            thr = cand;
        }
    }

    if (qv) {
        for (var e = 0u; e < LK; e = e + 1u) {
            if (lk[e] != 0u && lk[e] > thr) {
                let s = atomicAdd(&wcnt[32], 1u);
                if (s < C_MAX) {
                    cands[(q & RMASK) * C_MAX + s] = lr[e];
                }
            }
        }
    }
    workgroupBarrier();
    if (qv) {
        for (var e = 0u; e < LK; e = e + 1u) {
            if (lk[e] != 0u && lk[e] == thr) {
                let s = atomicAdd(&wcnt[32], 1u);
                if (s < C_MAX) {
                    cands[(q & RMASK) * C_MAX + s] = lr[e];
                }
            }
        }
    }
}
