// passes 1
struct Cfg { seed_slot: u32, stage: u32, arrived_begin: u32, arrived_end: u32, n_queries: u32, pass_index: u32, n_passes: u32, c_max: u32, };
@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const STRIDE: u32 = 36u;

var<workgroup> wq: array<f32, 32>;
var<workgroup> wsc: array<f32, 512>;
var<workgroup> wrw: array<u32, 512>;

@compute @workgroup_size(32)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let row = cfg.arrived_begin + wid.x;
    let t = lid.x;
    if (row < cfg.arrived_end) {
        // Each thread reduces 64 consecutive dims (16 vec4) into one value.
        var s = 0.0;
        for (var k = 0u; k < 16u; k = k + 1u) {
            let v = keys[(row & 0x7FFFFu) * 512u + t * 16u + k];
            s = s + v.x + v.y + v.z + v.w;
        }
        let base = (row & 0x7FFFFu) * STRIDE;
        index_f32[(base + t) & 0x7FFFFFu] = s;
        workgroupBarrier();
        if (t == 0u) {
            var n = 0.0;
            for (var j = 0u; j < 32u; j = j + 1u) {
                let x = index_f32[(base + j) & 0x7FFFFFu];
                n = n + x * x;
            }
            index_f32[(base + 32u) & 0x7FFFFFu] = sqrt(n);
        }
    }
}

@compute @workgroup_size(256)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let q = wid.x;
    let t = lid.x;
    if (t < 32u) {
        var s = 0.0;
        for (var k = 0u; k < 16u; k = k + 1u) {
            let v = queries[(q & 0xFFFFu) * 512u + t * 16u + k];
            s = s + v.x + v.y + v.z + v.w;
        }
        wq[t] = s;
    }
    workgroupBarrier();
    var b0 = NONE;
    var r0 = PAD;
    var b1 = NONE;
    var r1 = PAD;
    for (var i = 0u; i < cfg.arrived_end; i += 256u) {
        let r = i + t;
        if (r < cfg.arrived_end) {
            let base = (r & 0x7FFFFu) * STRIDE;
            let rn = index_f32[(base + 32u) & 0x7FFFFFu];
            if (rn > 0.0) {
                var d = 0.0;
                for (var j = 0u; j < 32u; j = j + 1u) {
                    d = d + wq[j] * index_f32[(base + j) & 0x7FFFFFu];
                }
                let sc = d / rn;
                if (sc > b0) {
                    b1 = b0; r1 = r0;
                    b0 = sc; r0 = r;
                } else if (sc > b1) {
                    b1 = sc; r1 = r;
                }
            }
        }
    }
    wsc[t * 2u] = b0;
    wrw[t * 2u] = r0;
    wsc[t * 2u + 1u] = b1;
    wrw[t * 2u + 1u] = r1;
    workgroupBarrier();
    for (var s = 0u; s < 2u; s = s + 1u) {
        let me = t * 2u + s;
        let a = wsc[me];
        if (wrw[me] != PAD) {
            var rank = 0u;
            for (var j = 0u; j < 512u; j = j + 1u) {
                let o = wsc[j];
                if (o > a || (o == a && j < me)) {
                    rank = rank + 1u;
                }
            }
            if (rank < 64u && q < cfg.n_queries) {
                cands[(q * 64u + rank) & 0x3FFFFFu] = wrw[me];
            }
        }
    }
}
