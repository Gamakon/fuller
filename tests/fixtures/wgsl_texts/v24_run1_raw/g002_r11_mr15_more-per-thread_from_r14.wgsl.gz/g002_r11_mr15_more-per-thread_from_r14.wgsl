// passes 1
struct Cfg { seed_slot: u32, stage: u32, arrived_begin: u32, arrived_end: u32, n_queries: u32, pass_index: u32, n_passes: u32, c_max: u32, };
@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const NPROJ: u32 = 80u;
const SLOT_BASE: u32 = 8192u;

var<workgroup> wproj: array<f32, 128>;
var<workgroup> wbucket: array<u32, 8>;
var<workgroup> wscore: array<f32, 512>;
var<workgroup> wrow: array<u32, 512>;

fn hsh(x: u32) -> u32 {
    var v = x * 0x9E3779B1u;
    v = v ^ (v >> 15u);
    v = v * 0x85EBCA6Bu;
    v = v ^ (v >> 13u);
    v = v * 0xC2B2AE35u;
    v = v ^ (v >> 16u);
    return v;
}

fn sgn(d: u32, p: u32) -> f32 {
    let h = hsh(d * 128u + p + 12345u);
    return select(-1.0, 1.0, (h & 1u) == 1u);
}

// Two projections per thread (p0 = lid, p1 = lid + 64) for a vec4 buffer region.
fn project_ingest(base: u32, lid: u32) {
    var s0 = 0.0;
    var s1 = 0.0;
    let p1 = lid + 64u;
    for (var d4 = 0u; d4 < 512u; d4 = d4 + 1u) {
        let v = keys[(base + d4) & 0xFFFFFFu];
        for (var c = 0u; c < 4u; c = c + 1u) {
            let d = d4 * 4u + c;
            s0 = s0 + v[c] * sgn(d, lid);
            if (p1 < NPROJ) {
                s1 = s1 + v[c] * sgn(d, p1);
            }
        }
    }
    wproj[lid] = s0;
    wproj[p1] = s1;
}

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = cfg.arrived_begin + wid.x;
    let ok = row < cfg.arrived_end;
    let base = (row & 0x7FFFFu) * 512u;
    if (ok) {
        project_ingest(base, t);
    }
    workgroupBarrier();
    if (ok && t < 8u) {
        var b = 0u;
        for (var i = 0u; i < 10u; i = i + 1u) {
            if (wproj[t * 10u + i] > 0.0) {
                b = b | (1u << i);
            }
        }
        let cell = t * 1024u + b;
        let idx = atomicAdd(&index_u32[cell & 8191u], 1u);
        if (idx < 64u) {
            atomicStore(&index_u32[(SLOT_BASE + cell * 64u + idx) & 0x7FFFFFu], row);
        }
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let qok = q < cfg.n_queries;
    let qbase = (q & 0xFFFFu) * 512u;
    // projections: two per thread
    var s0 = 0.0;
    var s1 = 0.0;
    let p1 = t + 64u;
    if (qok) {
        for (var d4 = 0u; d4 < 512u; d4 = d4 + 1u) {
            let v = queries[(qbase + d4) & 0xFFFFFFu];
            for (var c = 0u; c < 4u; c = c + 1u) {
                let d = d4 * 4u + c;
                s0 = s0 + v[c] * sgn(d, t);
                if (p1 < NPROJ) {
                    s1 = s1 + v[c] * sgn(d, p1);
                }
            }
        }
    }
    wproj[t] = s0;
    wproj[p1] = s1;
    workgroupBarrier();
    if (t < 8u) {
        var b = 0u;
        for (var i = 0u; i < 10u; i = i + 1u) {
            if (wproj[t * 10u + i] > 0.0) {
                b = b | (1u << i);
            }
        }
        wbucket[t] = b;
    }
    workgroupBarrier();
    // Score the candidates: 8 tables, slot t of each bucket (8 per thread).
    for (var i = 0u; i < 8u; i = i + 1u) {
        let cell = i * 1024u + (wbucket[i] & 1023u);
        let cnt = min(atomicLoad(&index_u32[cell & 8191u]), 64u);
        var sc = NONE;
        var rw = PAD;
        if (qok && t < cnt) {
            let r = atomicLoad(&index_u32[(SLOT_BASE + cell * 64u + t) & 0x7FFFFFu]);
            if (r < cfg.arrived_end) {
                var s = 0.0;
                var kn = 0.0;
                for (var d = 0u; d < 512u; d = d + 1u) {
                    let k = keys[((r & 0x7FFFFu) * 512u + d) & 0xFFFFFFu];
                    s = s + dot(k, queries[(qbase + d) & 0xFFFFFFu]);
                    kn = kn + dot(k, k);
                }
                if (kn > 0.0) {
                    sc = s / sqrt(kn);
                    rw = r;
                }
            }
        }
        wscore[i * 64u + t] = sc;
        wrow[i * 64u + t] = rw;
    }
    workgroupBarrier();
    // Dedup: later copies of the same row are dropped.
    var dup: array<bool, 8>;
    for (var i = 0u; i < 8u; i = i + 1u) {
        let c = i * 64u + t;
        var dp = false;
        let r = wrow[c];
        if (r != PAD) {
            for (var j = 0u; j < 512u; j = j + 1u) {
                if (j < c && wrow[j] == r) {
                    dp = true;
                }
            }
        }
        dup[i] = dp;
    }
    workgroupBarrier();
    for (var i = 0u; i < 8u; i = i + 1u) {
        if (dup[i]) {
            wscore[i * 64u + t] = NONE;
        }
    }
    workgroupBarrier();
    // Rank selection of the top 64.
    for (var i = 0u; i < 8u; i = i + 1u) {
        let c = i * 64u + t;
        let s = wscore[c];
        if (qok && s > NONE) {
            var rank = 0u;
            for (var j = 0u; j < 512u; j = j + 1u) {
                let o = wscore[j];
                if (o > s || (o == s && j < c)) {
                    rank = rank + 1u;
                }
            }
            if (rank < 64u) {
                cands[(q * 64u + rank) & 0x3FFFFFu] = wrow[c];
            }
        }
    }
}
