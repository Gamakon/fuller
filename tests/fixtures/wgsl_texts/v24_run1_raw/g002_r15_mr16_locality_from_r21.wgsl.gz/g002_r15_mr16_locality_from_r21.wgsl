// passes 2
struct Cfg { seed_slot: u32, stage: u32, arrived_begin: u32, arrived_end: u32, n_queries: u32, pass_index: u32, n_passes: u32, c_max: u32, };
@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const PAD: u32 = 0xFFFFFFFFu;
const NC: u32 = 64u;
const CAP: u32 = 1024u;
const NORM_BASE: u32 = 131072u;
const ARENA_MASK: u32 = 0x7FFFFFu;

var<workgroup> sc: array<f32, 64>;
var<workgroup> sel: array<u32, 8>;
var<workgroup> offs: array<u32, 9>;
var<workgroup> wscore: array<f32, 1024>;
var<workgroup> wrow: array<u32, 1024>;

// Centres are stored transposed: dim d of centre c at d * 64 + c, so the
// 64 threads (one per centre) read consecutive floats while the row/query
// vec4 is a broadcast read.
fn cent_score_row(vbase: u32, t: u32, use_query: bool) -> f32 {
    var acc = 0.0;
    for (var d4 = 0u; d4 < 512u; d4 += 1u) {
        var v: vec4<f32>;
        if (use_query) {
            v = queries[vbase + d4];
        } else {
            v = keys[vbase + d4];
        }
        let b = d4 * 4u * NC + t;
        acc += v.x * index_f32[b & ARENA_MASK];
        acc += v.y * index_f32[(b + NC) & ARENA_MASK];
        acc += v.z * index_f32[(b + 2u * NC) & ARENA_MASK];
        acc += v.w * index_f32[(b + 3u * NC) & ARENA_MASK];
    }
    let cn = max(index_f32[(NORM_BASE + t) & ARENA_MASK], 1.0e-12);
    return acc / cn;
}

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = (cfg.arrived_begin + wid.x) & 0x7FFFFu;
    if (cfg.pass_index == 0u) {
        // Stage 1: the first 64 rows become the centres.
        if (cfg.stage == 1u && wid.x < NC) {
            for (var dd = 0u; dd < 2048u; dd += 64u) {
                let d = dd + t;
                let v = keys[row * 512u + (d >> 2u)];
                var x = v.x;
                let m = d & 3u;
                if (m == 1u) { x = v.y; }
                if (m == 2u) { x = v.z; }
                if (m == 3u) { x = v.w; }
                index_f32[(d * NC + wid.x) & ARENA_MASK] = x;
            }
            if (t == 0u) {
                var n = 0.0;
                for (var d4 = 0u; d4 < 512u; d4 += 1u) {
                    let v = keys[row * 512u + d4];
                    n += dot(v, v);
                }
                index_f32[(NORM_BASE + wid.x) & ARENA_MASK] = sqrt(n);
            }
        }
        return;
    }
    sc[t] = cent_score_row(row * 512u, t, false);
    workgroupBarrier();
    if (t == 0u) {
        var best = -3.0e38;
        var bi = 0u;
        for (var c = 0u; c < NC; c += 1u) {
            if (sc[c] > best) {
                best = sc[c];
                bi = c;
            }
        }
        let slot = atomicAdd(&index_u32[bi], 1u);
        if (slot < CAP) {
            atomicStore(&index_u32[(NC + bi * CAP + slot) & ARENA_MASK], row);
        }
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let valid = q < cfg.n_queries;
    let qq = min(q, max(cfg.n_queries, 1u) - 1u);
    sc[t] = cent_score_row(qq * 512u, t, true);
    workgroupBarrier();
    if (t == 0u) {
        var total = 0u;
        offs[0] = 0u;
        for (var r = 0u; r < 8u; r += 1u) {
            var best = -3.0e38;
            var bi = 0u;
            for (var c = 0u; c < NC; c += 1u) {
                if (sc[c] > best) {
                    best = sc[c];
                    bi = c;
                }
            }
            sc[bi] = -3.4e38;
            sel[r] = bi;
            let cnt = min(atomicLoad(&index_u32[bi]), CAP);
            total = min(total + cnt, CAP);
            offs[r + 1u] = total;
        }
    }
    workgroupBarrier();
    let total = offs[8];
    for (var i = 0u; i < CAP; i += 64u) {
        let idx = i + t;
        var r = PAD;
        if (idx < total) {
            for (var j = 0u; j < 8u; j += 1u) {
                if (idx >= offs[j] && idx < offs[j + 1u]) {
                    r = atomicLoad(&index_u32[(NC + sel[j] * CAP + (idx - offs[j])) & ARENA_MASK]);
                }
            }
        }
        wrow[idx] = r;
        wscore[idx] = -3.0e38;
    }
    workgroupBarrier();
    for (var i = 0u; i < CAP; i += 64u) {
        let idx = i + t;
        let r = wrow[idx];
        if (r != PAD) {
            let base = (r & 0x7FFFFu) * 512u;
            var s = 0.0;
            var kn = 0.0;
            for (var d4 = 0u; d4 < 512u; d4 += 1u) {
                let k = keys[base + d4];
                s += dot(k, queries[qq * 512u + d4]);
                kn += dot(k, k);
            }
            wscore[idx] = s / max(sqrt(kn), 1.0e-12);
        }
    }
    workgroupBarrier();
    for (var i = 0u; i < CAP; i += 64u) {
        let idx = i + t;
        if (valid && idx < total && wrow[idx] != PAD) {
            let s = wscore[idx];
            var rank = 0u;
            for (var j = 0u; j < CAP; j += 1u) {
                if (j < total) {
                    let o = wscore[j];
                    if (o > s || (o == s && j < idx)) {
                        rank += 1u;
                    }
                }
            }
            if (rank < 64u) {
                cands[q * 64u + rank] = wrow[idx];
            }
        }
    }
}
