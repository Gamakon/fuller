// passes 1
struct Cfg { seed_slot: u32, stage: u32, arrived_begin: u32, arrived_end: u32, n_queries: u32, pass_index: u32, n_passes: u32, c_max: u32, };
@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;

var<workgroup> red: array<f32, 64>;
var<workgroup> wscore: array<f32, 1024>;
var<workgroup> wrow: array<u32, 1024>;

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = (cfg.arrived_begin + wid.x) & 0x7FFFFu;
    var acc = 0.0;
    for (var i = 0u; i < D4; i += 64u) {
        let d = i + t;
        if (d < D4) {
            let k = keys[row * D4 + d];
            acc += dot(k, k);
        }
    }
    red[t] = acc;
    workgroupBarrier();
    for (var s = 32u; s > 0u; s = s >> 1u) {
        if (t < s) {
            red[t] = red[t] + red[t + s];
        }
        workgroupBarrier();
    }
    if (t == 0u) {
        var inv = 0.0;
        if (red[0] > 0.0) {
            inv = inverseSqrt(red[0]);
        }
        index_f32[row] = inv;
    }
}

@compute @workgroup_size(256)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let q = wid.x;
    let t = lid.x;
    if (q >= cfg.n_queries) {
        return;
    }
    var bs = array<f32, 4>(NONE, NONE, NONE, NONE);
    var br = array<u32, 4>(PAD, PAD, PAD, PAD);
    let qb = (q & 0xFFFFu) * D4;
    for (var i = 0u; i < cfg.arrived_end; i += 256u) {
        let r = i + t;
        if (r < cfg.arrived_end) {
            let rr = r & 0x7FFFFu;
            let inv = index_f32[rr];
            if (inv > 0.0) {
                var s = 0.0;
                for (var d = 0u; d < D4; d += 1u) {
                    s += dot(keys[rr * D4 + d], queries[qb + d]);
                }
                let score = s * inv;
                // replace the minimum of the four
                var mi = 0u;
                var mv = bs[0];
                for (var j = 1u; j < 4u; j += 1u) {
                    if (bs[j] < mv) {
                        mv = bs[j];
                        mi = j;
                    }
                }
                if (score > mv) {
                    bs[mi] = score;
                    br[mi] = rr;
                }
            }
        }
    }
    for (var j = 0u; j < 4u; j += 1u) {
        wscore[t * 4u + j] = bs[j];
        wrow[t * 4u + j] = br[j];
    }
    workgroupBarrier();
    for (var j = 0u; j < 4u; j += 1u) {
        let e = t * 4u + j;
        let se = wscore[e];
        if (wrow[e] != PAD) {
            var rank = 0u;
            for (var k = 0u; k < 1024u; k += 1u) {
                let sk = wscore[k];
                if (sk > se || (sk == se && k < e)) {
                    rank += 1u;
                }
            }
            if (rank < 64u) {
                cands[q * 64u + rank] = wrow[e];
            }
        }
    }
}
