// passes 1
struct Cfg { seed_slot: u32, stage: u32, arrived_begin: u32, arrived_end: u32, n_queries: u32, pass_index: u32, n_passes: u32, c_max: u32, };
@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;

var<workgroup> red: array<f32, 64>;
var<workgroup> wscore: array<f32, 1024>;
var<workgroup> wrow: array<u32, 1024>;

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let r = cfg.arrived_begin + wid.x;
    var acc = 0.0;
    if (r < cfg.arrived_end) {
        for (var i = 0u; i < 8u; i += 1u) {
            let d = i * 64u + t;
            let v = keys[(r & 0x7FFFFu) * D4 + d];
            acc += dot(v, v);
        }
    }
    red[t] = acc;
    workgroupBarrier();
    for (var s = 32u; s > 0u; s = s >> 1u) {
        if (t < s) {
            red[t] = red[t] + red[t + s];
        }
        workgroupBarrier();
    }
    if (t == 0u && r < cfg.arrived_end) {
        var inv = 0.0;
        if (red[0] > 0.0) {
            inv = inverseSqrt(red[0]);
        }
        index_f32[r & 0x7FFFFu] = inv;
    }
}

@compute @workgroup_size(256)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let q = wid.x;
    let t = lid.x;
    var bs: array<f32, 4>;
    var br: array<u32, 4>;
    for (var j = 0u; j < 4u; j += 1u) {
        bs[j] = NONE;
        br[j] = PAD;
    }
    if (q < cfg.n_queries) {
        let qb = q * D4;
        for (var i = 0u; i < cfg.arrived_end; i += 512u) {
            let ra = i + t;
            let rb = i + t + 256u;
            let oka = ra < cfg.arrived_end;
            let okb = rb < cfg.arrived_end;
            let ca = select(0u, ra, oka);
            let cb = select(0u, rb, okb);
            let basea = (ca & 0x7FFFFu) * D4;
            let baseb = (cb & 0x7FFFFu) * D4;
            var sa = 0.0;
            var sb = 0.0;
            for (var d = 0u; d < D4; d += 1u) {
                let qv = queries[qb + d];
                sa += dot(keys[basea + d], qv);
                sb += dot(keys[baseb + d], qv);
            }
            var sc: array<f32, 2>;
            var rr: array<u32, 2>;
            var ok: array<bool, 2>;
            sc[0] = sa * index_f32[ca & 0x7FFFFu];
            sc[1] = sb * index_f32[cb & 0x7FFFFu];
            rr[0] = ra;
            rr[1] = rb;
            ok[0] = oka && index_f32[ca & 0x7FFFFu] > 0.0;
            ok[1] = okb && index_f32[cb & 0x7FFFFu] > 0.0;
            for (var e = 0u; e < 2u; e += 1u) {
                var cs = sc[e];
                if (ok[e] && cs > bs[3]) {
                    var cr = rr[e];
                    for (var j = 0u; j < 4u; j += 1u) {
                        if (cs > bs[j]) {
                            let ts = bs[j];
                            let tr = br[j];
                            bs[j] = cs;
                            br[j] = cr;
                            cs = ts;
                            cr = tr;
                        }
                    }
                }
            }
        }
    }
    for (var j = 0u; j < 4u; j += 1u) {
        wscore[t * 4u + j] = bs[j];
        wrow[t * 4u + j] = br[j];
    }
    workgroupBarrier();
    if (q < cfg.n_queries) {
        for (var j = 0u; j < 4u; j += 1u) {
            let idx = t * 4u + j;
            let s = wscore[idx];
            var rank = 0u;
            for (var k = 0u; k < 1024u; k += 1u) {
                let o = wscore[k];
                if (o > s || (o == s && k < idx)) {
                    rank += 1u;
                }
            }
            if (rank < 64u && wrow[idx] != PAD) {
                cands[q * 64u + rank] = wrow[idx];
            }
        }
    }
}
