// passes 1
// v24 design: quantised keys with a sign-sketch prefilter.
// Each thread handles more output elements: 128 threads a workgroup, each
// quantising 16 dimensions (4 packed words) in ingest and in the query
// setup, and keeping 8 best rows in search. The 128 x 8 per-thread lists
// are bitonic-sorted in workgroup memory and the top 64 are written.

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<f32>;
@group(0) @binding(1) var<storage, read> queries: array<f32>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D: u32 = 2048u;
const W: u32 = 512u;
const NSK: u32 = 128u;
const RMASK: u32 = 0x3FFFu;
const QMASK: u32 = 0xFFFu;
const SK_BASE: u32 = 16384u;
const C_MAX: u32 = 64u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const MARGIN: f32 = 0.25;
const NT: u32 = 128u;
const TOPT: u32 = 8u;

var<workgroup> wred: array<f32, 128>;
var<workgroup> wqs: array<f32, 128>;
var<workgroup> wqc: array<u32, 512>;
var<workgroup> wsc: array<f32, 1024>;
var<workgroup> wrw: array<u32, 1024>;

fn sign_bits(j: u32, blk: u32) -> u32 {
    var h = j * 0x9E3779B1u + blk * 0x85EBCA77u + 0x27D4EB2Fu;
    h = h ^ (h >> 16u);
    h = h * 0x7FEB352Du;
    h = h ^ (h >> 15u);
    h = h * 0x846CA68Bu;
    h = h ^ (h >> 16u);
    return h;
}

fn unpack_i8(w: u32) -> vec4<i32> {
    return vec4<i32>(
        bitcast<i32>(w << 24u) >> 24u,
        bitcast<i32>(w << 16u) >> 24u,
        bitcast<i32>(w << 8u) >> 24u,
        bitcast<i32>(w) >> 24u
    );
}

// wred[t] must hold each thread's value before the call.
fn wg_sum(t: u32) -> f32 {
    workgroupBarrier();
    for (var s = 0u; s < 7u; s = s + 1u) {
        let half = 64u >> s;
        if (t < half) {
            wred[t] = wred[t] + wred[t + half];
        }
        workgroupBarrier();
    }
    let v = wred[0];
    workgroupBarrier();
    return v;
}

fn wg_max(t: u32) -> f32 {
    workgroupBarrier();
    for (var s = 0u; s < 7u; s = s + 1u) {
        let half = 64u >> s;
        if (t < half) {
            wred[t] = max(wred[t], wred[t + half]);
        }
        workgroupBarrier();
    }
    let v = wred[0];
    workgroupBarrier();
    return v;
}

@compute @workgroup_size(128)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let r = cfg.arrived_begin + wid.x;
    if (cfg.pass_index != 0u || r >= cfg.arrived_end) {
        return;
    }
    let kb = (r & 0x7FFFu) * D;
    var vals: array<f32, 16>;
    var m = 0.0;
    var sq = 0.0;
    for (var i = 0u; i < 16u; i = i + 1u) {
        let v = keys[kb + t * 16u + i];
        vals[i] = v;
        m = max(m, abs(v));
        sq = sq + v * v;
    }
    wred[t] = m;
    let mx = wg_max(t);
    wred[t] = sq;
    let xn2 = wg_sum(t);
    var inv = 0.0;
    if (mx > 0.0) {
        inv = 127.0 / mx;
    }
    var nrm = 0.0;
    var words: array<u32, 4>;
    for (var i = 0u; i < 4u; i = i + 1u) {
        words[i] = 0u;
    }
    for (var i = 0u; i < 16u; i = i + 1u) {
        let c = clamp(i32(round(vals[i] * inv)), -127, 127);
        nrm = nrm + f32(c * c);
        let b = bitcast<u32>(c) & 0xFFu;
        words[i >> 2u] = words[i >> 2u] | (b << (8u * (i & 3u)));
    }
    let rm = r & RMASK;
    for (var k = 0u; k < 4u; k = k + 1u) {
        index_u32[rm * W + t * 4u + k] = words[k];
    }
    wred[t] = nrm;
    let cn = wg_sum(t);
    if (t == 0u) {
        index_f32[rm] = cn;
    }
    if (t < NSK) {
        var acc = 0.0;
        for (var b = 0u; b < 64u; b = b + 1u) {
            let bits = sign_bits(t, b);
            for (var i = 0u; i < 32u; i = i + 1u) {
                let v = keys[kb + b * 32u + i];
                acc = acc + select(-v, v, ((bits >> i) & 1u) == 1u);
            }
        }
        var s = 0.0;
        if (xn2 > 0.0) {
            s = acc / sqrt(xn2);
        }
        index_f32[SK_BASE + rm * NSK + t] = s;
    }
}

@compute @workgroup_size(128)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    if (q >= cfg.n_queries) {
        return;
    }
    let qb = (q & QMASK) * D;
    var vals: array<f32, 16>;
    var m = 0.0;
    var sq = 0.0;
    for (var i = 0u; i < 16u; i = i + 1u) {
        let v = queries[qb + t * 16u + i];
        vals[i] = v;
        m = max(m, abs(v));
        sq = sq + v * v;
    }
    wred[t] = m;
    let mx = wg_max(t);
    wred[t] = sq;
    let qn2 = wg_sum(t);
    var inv = 0.0;
    if (mx > 0.0) {
        inv = 127.0 / mx;
    }
    var nrm = 0.0;
    var words: array<u32, 4>;
    for (var i = 0u; i < 4u; i = i + 1u) {
        words[i] = 0u;
    }
    for (var i = 0u; i < 16u; i = i + 1u) {
        let c = clamp(i32(round(vals[i] * inv)), -127, 127);
        nrm = nrm + f32(c * c);
        let b = bitcast<u32>(c) & 0xFFu;
        words[i >> 2u] = words[i >> 2u] | (b << (8u * (i & 3u)));
    }
    for (var k = 0u; k < 4u; k = k + 1u) {
        wqc[t * 4u + k] = words[k];
    }
    wred[t] = nrm;
    let qcn = wg_sum(t);
    if (t < NSK) {
        var acc = 0.0;
        for (var b = 0u; b < 64u; b = b + 1u) {
            let bits = sign_bits(t, b);
            for (var i = 0u; i < 32u; i = i + 1u) {
                let v = queries[qb + b * 32u + i];
                acc = acc + select(-v, v, ((bits >> i) & 1u) == 1u);
            }
        }
        var s = 0.0;
        if (qn2 > 0.0) {
            s = acc / sqrt(qn2);
        }
        wqs[t] = s;
    }
    workgroupBarrier();

    var best: array<f32, 8>;
    var rows: array<u32, 8>;
    for (var j = 0u; j < TOPT; j = j + 1u) {
        best[j] = NONE;
        rows[j] = PAD;
    }
    var thr = NONE;
    if (qcn > 0.0) {
        for (var i = 0u; i < cfg.arrived_end; i = i + NT) {
            let r = i + t;
            if (r < cfg.arrived_end) {
                let rm = r & RMASK;
                let kn = index_f32[rm];
                if (kn > 0.0) {
                    var e = 0.0;
                    let sb = SK_BASE + rm * NSK;
                    for (var j = 0u; j < NSK; j = j + 1u) {
                        e = e + index_f32[sb + j] * wqs[j];
                    }
                    e = e * (1.0 / 128.0);
                    if (e > thr) {
                        var acc = 0;
                        let cb = rm * W;
                        for (var w = 0u; w < W; w = w + 1u) {
                            acc = acc + dot(unpack_i8(index_u32[cb + w]), unpack_i8(wqc[w]));
                        }
                        let score = f32(acc) / sqrt(kn * qcn);
                        if (score > best[TOPT - 1u]) {
                            var cs = score;
                            var cr = r;
                            for (var j = 0u; j < TOPT; j = j + 1u) {
                                if (cs > best[j]) {
                                    let ts = best[j];
                                    let tr = rows[j];
                                    best[j] = cs;
                                    rows[j] = cr;
                                    cs = ts;
                                    cr = tr;
                                }
                            }
                            thr = best[TOPT - 1u] - MARGIN;
                        }
                    }
                }
            }
        }
    }
    for (var j = 0u; j < TOPT; j = j + 1u) {
        wsc[t * TOPT + j] = best[j];
        wrw[t * TOPT + j] = rows[j];
    }
    workgroupBarrier();

    // Bitonic sort of the 1,024 entries, descending by score.
    for (var kk = 1u; kk <= 10u; kk = kk + 1u) {
        let k = 1u << kk;
        for (var jj = 0u; jj < kk; jj = jj + 1u) {
            let j = k >> (jj + 1u);
            for (var p = 0u; p < 512u; p = p + NT) {
                let idx = p + t;
                let a = (idx / j) * (2u * j) + (idx % j);
                let b = a + j;
                let desc = (a & k) == 0u;
                let sa = wsc[a];
                let sb2 = wsc[b];
                if ((desc && sa < sb2) || (!desc && sa > sb2)) {
                    let ra = wrw[a];
                    wsc[a] = sb2;
                    wsc[b] = sa;
                    wrw[a] = wrw[b];
                    wrw[b] = ra;
                }
            }
            workgroupBarrier();
        }
    }
    if (t < C_MAX) {
        let r = wrw[t];
        if (r != PAD) {
            cands[(q & QMASK) * C_MAX + t] = r;
        }
    }
}
