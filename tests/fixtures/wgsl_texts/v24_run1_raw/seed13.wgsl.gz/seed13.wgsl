// passes 1
struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const NP: u32 = 32u;

var<workgroup> red: array<f32, 2048>;
var<workgroup> wq: array<f32, 32>;
var<workgroup> wscore: array<f32, 512>;
var<workgroup> wrow: array<u32, 512>;

fn sgn(d: u32, j: u32) -> f32 {
    var h = (d * 32u + j + 1u) * 0x9E3779B1u;
    h = h ^ (h >> 15u);
    h = h * 0x85EBCA6Bu;
    h = h ^ (h >> 13u);
    h = h * 0xC2B2AE35u;
    h = h ^ (h >> 16u);
    return select(-1.0, 1.0, (h & 1u) == 1u);
}

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = (cfg.arrived_begin + wid.x) & 0x7FFFFu;
    var acc: array<f32, 32>;
    for (var j = 0u; j < NP; j = j + 1u) { acc[j] = 0.0; }
    for (var i = 0u; i < 8u; i = i + 1u) {
        let d4 = t + 64u * i;
        let v = keys[row * 512u + d4];
        for (var j = 0u; j < NP; j = j + 1u) {
            acc[j] = acc[j] + v.x * sgn(d4 * 4u, j) + v.y * sgn(d4 * 4u + 1u, j)
                + v.z * sgn(d4 * 4u + 2u, j) + v.w * sgn(d4 * 4u + 3u, j);
        }
    }
    for (var j = 0u; j < NP; j = j + 1u) { red[t * 32u + j] = acc[j]; }
    workgroupBarrier();
    if (t < NP) {
        var s = 0.0;
        for (var k = 0u; k < 64u; k = k + 1u) { s = s + red[k * 32u + t]; }
        wq[t] = s;
    }
    workgroupBarrier();
    if (t < NP) {
        var n = 0.0;
        for (var j = 0u; j < NP; j = j + 1u) { n = n + wq[j] * wq[j]; }
        let inv = select(0.0, 1.0 / sqrt(n), n > 0.0);
        index_f32[(row * 32u + t) & 0x7FFFFFu] = wq[t] * inv;
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let qs = q & 0xFFFFu;
    var acc: array<f32, 32>;
    for (var j = 0u; j < NP; j = j + 1u) { acc[j] = 0.0; }
    for (var i = 0u; i < 8u; i = i + 1u) {
        let d4 = t + 64u * i;
        let v = queries[qs * 512u + d4];
        for (var j = 0u; j < NP; j = j + 1u) {
            acc[j] = acc[j] + v.x * sgn(d4 * 4u, j) + v.y * sgn(d4 * 4u + 1u, j)
                + v.z * sgn(d4 * 4u + 2u, j) + v.w * sgn(d4 * 4u + 3u, j);
        }
    }
    for (var j = 0u; j < NP; j = j + 1u) { red[t * 32u + j] = acc[j]; }
    workgroupBarrier();
    if (t < NP) {
        var s = 0.0;
        for (var k = 0u; k < 64u; k = k + 1u) { s = s + red[k * 32u + t]; }
        wq[t] = s;
    }
    workgroupBarrier();
    var qp: array<f32, 32>;
    var n = 0.0;
    for (var j = 0u; j < NP; j = j + 1u) { qp[j] = wq[j]; n = n + wq[j] * wq[j]; }
    let inv = select(0.0, 1.0 / sqrt(n), n > 0.0);
    for (var j = 0u; j < NP; j = j + 1u) { qp[j] = qp[j] * inv; }

    var bs: array<f32, 8>;
    var br: array<u32, 8>;
    for (var e = 0u; e < 8u; e = e + 1u) { bs[e] = NONE; br[e] = PAD; }
    for (var i = 0u; i < 512u; i = i + 1u) {
        let r = t + 64u * i;
        if (r < cfg.arrived_end) {
            let base = (r * 32u) & 0x7FFFFFu;
            var s = 0.0;
            for (var j = 0u; j < NP; j = j + 1u) {
                s = s + qp[j] * index_f32[(base + j) & 0x7FFFFFu];
            }
            if (s > bs[7]) {
                var cs = s;
                var cr = r;
                for (var e = 0u; e < 8u; e = e + 1u) {
                    if (cs > bs[e]) {
                        let ts = bs[e];
                        let tr = br[e];
                        bs[e] = cs;
                        br[e] = cr;
                        cs = ts;
                        cr = tr;
                    }
                }
            }
        }
    }
    for (var e = 0u; e < 8u; e = e + 1u) {
        wscore[t * 8u + e] = bs[e];
        wrow[t * 8u + e] = br[e];
    }
    workgroupBarrier();
    if (q < cfg.n_queries) {
        for (var e = 0u; e < 8u; e = e + 1u) {
            let idx = t * 8u + e;
            let me = wscore[idx];
            let mr = wrow[idx];
            if (mr != PAD) {
                var rank = 0u;
                for (var k = 0u; k < 512u; k = k + 1u) {
                    let o = wscore[k];
                    if (o > me || (o == me && k < idx)) { rank = rank + 1u; }
                }
                if (rank < 64u) {
                    cands[q * 64u + rank] = mr;
                }
            }
        }
    }
}
