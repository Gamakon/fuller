// grid 16 16 1 1
// passes 2
// entry ingest grid 16 16 1 1
// entry search grid 16 16 1 1
struct Cfg { seed_slot: u32, stage: u32, arrived_begin: u32, arrived_end: u32, n_queries: u32, pass_index: u32, n_passes: u32, c_max: u32, };
@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;

var<workgroup> sc: array<f32, 64>;
var<workgroup> wtop: array<u32, 8>;
var<workgroup> wsc: array<f32, 256>;
var<workgroup> wrw: array<u32, 256>;

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let r = (cfg.arrived_begin + wid.x) & 0x7FFFFu;
    if (cfg.pass_index == 0u) {
        if (cfg.stage == 1u && wid.x < 64u && t == 0u) {
            var kn = 0.0;
            for (var d = 0u; d < D4; d = d + 1u) {
                let k = keys[r * D4 + d];
                kn = kn + dot(k, k);
            }
            var inv = 0.0;
            if (kn > 0.0) { inv = inverseSqrt(kn); }
            index_f32[wid.x & 63u] = inv;
        }
    } else {
        var s = NONE;
        // Fused: the row is dotted against centre t (a row of the first 64).
        var acc = 0.0;
        for (var d = 0u; d < D4; d = d + 1u) {
            acc = acc + dot(keys[r * D4 + d], keys[(t & 63u) * D4 + d]);
        }
        s = acc * index_f32[t & 63u];
        sc[t] = s;
        workgroupBarrier();
        if (t == 0u) {
            var bs = NONE;
            var bi = 0u;
            for (var c = 0u; c < 64u; c = c + 1u) {
                if (sc[c] > bs) { bs = sc[c]; bi = c; }
            }
            index_u32[r] = bi;
        }
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let qq = q & 0xFFFFu;
    var acc = 0.0;
    for (var d = 0u; d < D4; d = d + 1u) {
        acc = acc + dot(queries[qq * D4 + d], keys[(t & 63u) * D4 + d]);
    }
    sc[t] = acc * index_f32[t & 63u];
    workgroupBarrier();
    if (t == 0u) {
        for (var k = 0u; k < 8u; k = k + 1u) {
            var bs = NONE;
            var bi = 0u;
            for (var c = 0u; c < 64u; c = c + 1u) {
                if (sc[c] > bs) { bs = sc[c]; bi = c; }
            }
            wtop[k] = bi;
            sc[bi] = NONE;
        }
    }
    workgroupBarrier();
    var b0 = NONE; var b1 = NONE; var b2 = NONE; var b3 = NONE;
    var r0 = PAD; var r1 = PAD; var r2 = PAD; var r3 = PAD;
    for (var i = 0u; i < cfg.arrived_end; i = i + 64u) {
        let r = i + t;
        if (r < cfg.arrived_end) {
            let b = index_u32[r & 0x7FFFFFu];
            var hit = false;
            for (var k = 0u; k < 8u; k = k + 1u) {
                if (wtop[k] == b) { hit = true; }
            }
            if (hit) {
                var s = 0.0;
                var kn = 0.0;
                for (var d = 0u; d < D4; d = d + 1u) {
                    let kv = keys[(r & 0x7FFFFu) * D4 + d];
                    s = s + dot(kv, queries[qq * D4 + d]);
                    kn = kn + dot(kv, kv);
                }
                var score = NONE;
                if (kn > 0.0) { score = s * inverseSqrt(kn); }
                if (score > b3) {
                    var cs = score;
                    var cr = r;
                    if (cs > b0) { let ts = b0; let tr = r0; b0 = cs; r0 = cr; cs = ts; cr = tr; }
                    if (cs > b1) { let ts = b1; let tr = r1; b1 = cs; r1 = cr; cs = ts; cr = tr; }
                    if (cs > b2) { let ts = b2; let tr = r2; b2 = cs; r2 = cr; cs = ts; cr = tr; }
                    if (cs > b3) { b3 = cs; r3 = cr; }
                }
            }
        }
    }
    wsc[t * 4u] = b0; wrw[t * 4u] = r0;
    wsc[t * 4u + 1u] = b1; wrw[t * 4u + 1u] = r1;
    wsc[t * 4u + 2u] = b2; wrw[t * 4u + 2u] = r2;
    wsc[t * 4u + 3u] = b3; wrw[t * 4u + 3u] = r3;
    workgroupBarrier();
    if (q < cfg.n_queries) {
        for (var m = 0u; m < 4u; m = m + 1u) {
            let i = t * 4u + m;
            let si = wsc[i];
            let ri = wrw[i];
            if (ri != PAD) {
                var rank = 0u;
                for (var j = 0u; j < 256u; j = j + 1u) {
                    let sj = wsc[j];
                    if (wrw[j] != PAD && (sj > si || (sj == si && j < i))) {
                        rank = rank + 1u;
                    }
                }
                if (rank < 64u) {
                    cands[(q * 64u + rank) & 0x3FFFFFu] = ri;
                }
            }
        }
    }
}
