// passes 1
struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const C_MAX: u32 = 64u;
const D4: u32 = 512u;
const THREADS: u32 = 16u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;

var<workgroup> wscore: array<f32, 1024>;
var<workgroup> wrow: array<u32, 1024>;

@compute @workgroup_size(1)
fn ingest() {
}

@compute @workgroup_size(16)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let q = wid.x;
    let t = lid.x;
    var best: array<f32, 64>;
    var rows: array<u32, 64>;
    for (var j = 0u; j < C_MAX; j = j + 1u) {
        best[j] = NONE;
        rows[j] = PAD;
    }
    if (q < cfg.n_queries) {
        let qb = (q & 0xFFFFu) * D4;
        // The query norm does not change the ranking, so it is dropped; the
        // dot and key-norm accumulations are fused in one loop over rows.
        for (var i = 0u; i < cfg.arrived_end; i = i + 16u) {
            let r = i + t;
            if (r < cfg.arrived_end) {
                var s = 0.0;
                var kn = 0.0;
                let kb = (r & 0x7FFFFu) * D4;
                for (var d = 0u; d < D4; d = d + 1u) {
                    let k = keys[kb + d];
                    s = s + dot(k, queries[qb + d]);
                    kn = kn + dot(k, k);
                }
                var score = NONE;
                if (kn > 0.0) {
                    score = s * inverseSqrt(kn);
                }
                if (score > best[C_MAX - 1u]) {
                    var cs = score;
                    var cr = r;
                    for (var j = 0u; j < C_MAX; j = j + 1u) {
                        if (cs > best[j]) {
                            let ts = best[j];
                            let tr = rows[j];
                            best[j] = cs;
                            rows[j] = cr;
                            cs = ts;
                            cr = tr;
                        }
                    }
                }
            }
        }
    }
    for (var j = 0u; j < C_MAX; j = j + 1u) {
        wscore[t * C_MAX + j] = best[j];
        wrow[t * C_MAX + j] = rows[j];
    }
    workgroupBarrier();
    if (q < cfg.n_queries) {
        for (var j = 0u; j < C_MAX; j = j + 1u) {
            best[j] = NONE;
            rows[j] = PAD;
        }
        for (var i = 0u; i < THREADS * C_MAX; i = i + 1u) {
            let score = wscore[i];
            let r = wrow[i];
            if (r != PAD && score > best[C_MAX - 1u]) {
                var cs = score;
                var cr = r;
                for (var j = 0u; j < C_MAX; j = j + 1u) {
                    if (cs > best[j]) {
                        let ts = best[j];
                        let tr = rows[j];
                        best[j] = cs;
                        rows[j] = cr;
                        cs = ts;
                        cr = tr;
                    }
                }
            }
        }
        cands[q * C_MAX + t] = rows[t];
        cands[q * C_MAX + 16u + t] = rows[16u + t];
        cands[q * C_MAX + 32u + t] = rows[32u + t];
        cands[q * C_MAX + 48u + t] = rows[48u + t];
    }
}
