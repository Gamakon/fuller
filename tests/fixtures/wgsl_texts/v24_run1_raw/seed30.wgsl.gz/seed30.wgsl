// passes 5
// Count-then-splay, sign-hash variant with median-balanced hyperplanes.
// Twelve fixed pseudo-random +/-1 directions project every key. In stage 1
// each direction's split point is set to the median of the first
// microbatch's normalised projections, so every bit cuts the hotspots in
// half rather than cutting through empty space. A row's cell is its 12-bit
// code (4,096 cells).
// Ingest passes run per microbatch, and each microbatch has its own block:
//   0: project the row and keep its 12 normalised projections (index_f32)
//   1: stage 1 only, workgroup b < 12: bisect for direction b's median
//   2: hash the row to its cell, count it into the section's histogram
//   3: workgroup 0: exclusive prefix over the 4,096 counts (cell starts)
//   4: splay: each row takes a slot in its cell's run of the section array
// Search ranks the 256 probes (the query's cell with any subset of its 8
// least-confident bits flipped) by squared flip margin with a bitonic sort.
// It flattens the probed cells over all sections, takes up to 2,048 rows in
// cost order, scores them exactly and keeps the 64 best by a packed-key
// bitonic sort.

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const C_MAX: u32 = 64u;
const D4: u32 = 512u;
const NB: u32 = 12u;
const CMASK: u32 = 4095u;
const ROWM: u32 = 32767u;
const ARENA_MASK: u32 = 0x7FFFFFu;
const PROJ_MASK: u32 = 0x7FFFFu;
const SEC_BASE: u32 = 32768u;
const SEC_STRIDE: u32 = 32768u;
const OFF_COUNT: u32 = 0u;
const OFF_START: u32 = 4096u;
const OFF_CUR: u32 = 8192u;
const OFF_ROWS: u32 = 12288u;
const ROW_MASK: u32 = 16383u;
const THR_BASE: u32 = 524288u;
const SCAN_CAP: u32 = 2048u;
const PAD: u32 = 0xFFFFFFFFu;

var<workgroup> wu: array<u32, 2048>;
var<workgroup> wf: array<f32, 1024>;
var<workgroup> wcell: array<u32, 256>;
var<workgroup> woff: array<u32, 257>;

fn hsh(x: u32) -> u32 {
    var v = x * 747796405u + 2891336453u;
    v = ((v >> ((v >> 28u) + 4u)) ^ v) * 277803737u;
    return (v >> 22u) ^ v;
}

fn sec_base(s: u32) -> u32 {
    return SEC_BASE + (s & 7u) * SEC_STRIDE;
}

fn map_row(idx: u32, nsec: u32) -> u32 {
    var lo = 0u;
    var hi = 256u;
    for (var it = 0u; it < 8u; it = it + 1u) {
        let mid = (lo + hi) >> 1u;
        if (woff[mid & 255u] <= idx) {
            lo = mid;
        } else {
            hi = mid;
        }
    }
    let l = lo & 255u;
    var li = idx - woff[l];
    let cell = wcell[l] & CMASK;
    var row = PAD;
    var done = false;
    for (var s = 0u; s < 8u; s = s + 1u) {
        if (s < nsec && !done) {
            let sb = sec_base(s);
            let c = atomicLoad(&index_u32[(sb + OFF_COUNT + cell) & ARENA_MASK]);
            if (li < c) {
                let st = atomicLoad(&index_u32[(sb + OFF_START + cell) & ARENA_MASK]);
                row = atomicLoad(&index_u32[(sb + OFF_ROWS + ((st + li) & ROW_MASK)) & ARENA_MASK]);
                done = true;
            } else {
                li = li - c;
            }
        }
    }
    return row;
}

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let grow = cfg.arrived_begin + wid.x;
    let row = grow & ROWM;
    let live = grow < cfg.arrived_end;
    let sb = sec_base((cfg.stage + 7u) & 7u);

    if (cfg.pass_index == 0u) {
        var p: array<f32, 12>;
        for (var b = 0u; b < NB; b = b + 1u) {
            p[b] = 0.0;
        }
        var nrm = 0.0;
        if (live) {
            for (var i = 0u; i < D4; i = i + 64u) {
                let d = i + t;
                if (d < D4) {
                    let kv = keys[row * D4 + d];
                    nrm = nrm + dot(kv, kv);
                    for (var c = 0u; c < 4u; c = c + 1u) {
                        let h = hsh(d * 4u + c + 0x632BE5ABu);
                        let v = kv[c];
                        for (var b = 0u; b < NB; b = b + 1u) {
                            if (((h >> b) & 1u) == 1u) {
                                p[b] = p[b] + v;
                            } else {
                                p[b] = p[b] - v;
                            }
                        }
                    }
                }
            }
        }
        for (var b = 0u; b < NB; b = b + 1u) {
            wf[b * 64u + t] = p[b];
        }
        wf[NB * 64u + t] = nrm;
        workgroupBarrier();
        for (var k = 0u; k < 6u; k = k + 1u) {
            let s = 32u >> k;
            if (t < s) {
                for (var b = 0u; b < 13u; b = b + 1u) {
                    wf[b * 64u + t] = wf[b * 64u + t] + wf[b * 64u + t + s];
                }
            }
            workgroupBarrier();
        }
        if (t == 0u && live) {
            let den = sqrt(wf[NB * 64u] * 2048.0);
            for (var b = 0u; b < NB; b = b + 1u) {
                var v = 0.0;
                if (den > 0.0) {
                    v = wf[b * 64u] / den;
                }
                index_f32[(row * 16u + b) & PROJ_MASK] = v;
            }
        }
    }

    if (cfg.pass_index == 1u && cfg.stage == 1u && wid.x < NB) {
        let b = wid.x;
        let n = cfg.arrived_end;
        var lo = -1.0;
        var hi = 1.0;
        for (var it = 0u; it < 24u; it = it + 1u) {
            let mid = 0.5 * (lo + hi);
            var c = 0u;
            for (var i = 0u; i < n; i = i + 64u) {
                let r = i + t;
                if (r < n) {
                    if (index_f32[((r & ROWM) * 16u + b) & PROJ_MASK] > mid) {
                        c = c + 1u;
                    }
                }
            }
            wu[t] = c;
            workgroupBarrier();
            for (var k = 0u; k < 6u; k = k + 1u) {
                let s = 32u >> k;
                if (t < s) {
                    wu[t] = wu[t] + wu[t + s];
                }
                workgroupBarrier();
            }
            let tot = wu[0];
            workgroupBarrier();
            let above = tot * 2u > n;
            lo = select(lo, mid, above);
            hi = select(mid, hi, above);
        }
        if (t == 0u) {
            index_f32[THR_BASE + b] = 0.5 * (lo + hi);
        }
    }

    if (cfg.pass_index == 2u && live && t == 0u) {
        var code = 0u;
        for (var b = 0u; b < NB; b = b + 1u) {
            let v = index_f32[(row * 16u + b) & PROJ_MASK];
            if (v > index_f32[THR_BASE + b]) {
                code = code | (1u << b);
            }
        }
        atomicStore(&index_u32[row], code);
        atomicAdd(&index_u32[(sb + OFF_COUNT + code) & ARENA_MASK], 1u);
    }

    if (cfg.pass_index == 3u && wid.x == 0u) {
        var sum = 0u;
        for (var i = 0u; i < 64u; i = i + 1u) {
            sum = sum + atomicLoad(&index_u32[(sb + OFF_COUNT + t * 64u + i) & ARENA_MASK]);
        }
        wu[t] = sum;
        workgroupBarrier();
        if (t == 0u) {
            var acc = 0u;
            for (var i = 0u; i < 64u; i = i + 1u) {
                let v = wu[i];
                wu[i] = acc;
                acc = acc + v;
            }
        }
        workgroupBarrier();
        var acc = wu[t];
        for (var i = 0u; i < 64u; i = i + 1u) {
            let c = (t * 64u + i) & CMASK;
            atomicStore(&index_u32[(sb + OFF_START + c) & ARENA_MASK], acc);
            acc = acc + atomicLoad(&index_u32[(sb + OFF_COUNT + c) & ARENA_MASK]);
        }
    }

    if (cfg.pass_index == 4u && live && t == 0u) {
        let code = atomicLoad(&index_u32[row]) & CMASK;
        let slot = atomicAdd(&index_u32[(sb + OFF_CUR + code) & ARENA_MASK], 1u);
        let st = atomicLoad(&index_u32[(sb + OFF_START + code) & ARENA_MASK]);
        atomicStore(&index_u32[(sb + OFF_ROWS + ((st + slot) & ROW_MASK)) & ARENA_MASK], grow);
    }
}

@compute @workgroup_size(256)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let qv = q < cfg.n_queries;
    let qb = (q & 0xFFFFu) * D4;
    let nsec = min(cfg.stage, 8u);

    // Query projection on the first 64 threads.
    var p: array<f32, 12>;
    for (var b = 0u; b < NB; b = b + 1u) {
        p[b] = 0.0;
    }
    var nrm = 0.0;
    if (t < 64u && qv) {
        for (var i = 0u; i < D4; i = i + 64u) {
            let d = i + t;
            if (d < D4) {
                let kv = queries[qb + d];
                nrm = nrm + dot(kv, kv);
                for (var c = 0u; c < 4u; c = c + 1u) {
                    let h = hsh(d * 4u + c + 0x632BE5ABu);
                    let v = kv[c];
                    for (var b = 0u; b < NB; b = b + 1u) {
                        if (((h >> b) & 1u) == 1u) {
                            p[b] = p[b] + v;
                        } else {
                            p[b] = p[b] - v;
                        }
                    }
                }
            }
        }
    }
    if (t < 64u) {
        for (var b = 0u; b < NB; b = b + 1u) {
            wf[b * 64u + t] = p[b];
        }
        wf[NB * 64u + t] = nrm;
    }
    workgroupBarrier();
    for (var k = 0u; k < 6u; k = k + 1u) {
        let s = 32u >> k;
        if (t < s) {
            for (var b = 0u; b < 13u; b = b + 1u) {
                wf[b * 64u + t] = wf[b * 64u + t] + wf[b * 64u + t + s];
            }
        }
        workgroupBarrier();
    }
    let qn = wf[NB * 64u];
    let qden = sqrt(qn * 2048.0);
    var conf: array<f32, 12>;
    var code = 0u;
    for (var b = 0u; b < NB; b = b + 1u) {
        var pv = 0.0;
        if (qden > 0.0) {
            pv = wf[b * 64u] / qden;
        }
        let m = pv - index_f32[THR_BASE + b];
        if (m > 0.0) {
            code = code | (1u << b);
        }
        conf[b] = m * m;
    }
    workgroupBarrier();

    // The 8 least-confident bits, in rank order.
    var by_rank: array<u32, 8>;
    for (var j = 0u; j < 8u; j = j + 1u) {
        by_rank[j] = 0u;
    }
    for (var b = 0u; b < NB; b = b + 1u) {
        var r = 0u;
        for (var b2 = 0u; b2 < NB; b2 = b2 + 1u) {
            if (conf[b2] < conf[b] || (conf[b2] == conf[b] && b2 < b)) {
                r = r + 1u;
            }
        }
        if (r < 8u) {
            by_rank[r] = b;
        }
    }
    var mask = 0u;
    var cost = 0.0;
    for (var j = 0u; j < 8u; j = j + 1u) {
        if (((t >> j) & 1u) == 1u) {
            let b = by_rank[j];
            mask = mask | (1u << b);
            cost = cost + conf[b];
        }
    }
    wf[t] = cost;
    wcell[t] = (code ^ mask) & CMASK;
    workgroupBarrier();

    // Bitonic sort of the 256 probes by flip cost, ascending.
    for (var kk = 1u; kk <= 8u; kk = kk + 1u) {
        let k = 1u << kk;
        for (var jj = 0u; jj < kk; jj = jj + 1u) {
            let j = k >> (jj + 1u);
            let ixj = t ^ j;
            if (ixj > t && ixj < 256u) {
                let up = (t & k) == 0u;
                let a = wf[t];
                let bb = wf[ixj];
                if ((up && a > bb) || (!up && a < bb)) {
                    wf[t] = bb;
                    wf[ixj] = a;
                    let ca = wcell[t];
                    wcell[t] = wcell[ixj];
                    wcell[ixj] = ca;
                }
            }
            workgroupBarrier();
        }
    }

    // Probe sizes over all built sections, then the flattening prefix.
    let cell = wcell[t] & CMASK;
    var sz = 0u;
    for (var s = 0u; s < 8u; s = s + 1u) {
        if (s < nsec) {
            sz = sz + atomicLoad(&index_u32[(sec_base(s) + OFF_COUNT + cell) & ARENA_MASK]);
        }
    }
    woff[t] = sz;
    workgroupBarrier();
    if (t == 0u) {
        var acc = 0u;
        for (var i = 0u; i < 256u; i = i + 1u) {
            let v = woff[i];
            woff[i] = acc;
            acc = acc + v;
        }
        woff[256] = acc;
    }
    workgroupBarrier();
    let n = min(woff[256], SCAN_CAP);

    // Exact scoring of the flattened rows, packed as (score, index) keys.
    for (var i = 0u; i < SCAN_CAP; i = i + 256u) {
        let idx = i + t;
        var key = 0u;
        if (idx < n && qv) {
            let r = map_row(idx, nsec);
            if (r < cfg.arrived_end) {
                let kb = (r & ROWM) * D4;
                var s = 0.0;
                var kn = 0.0;
                for (var d = 0u; d < D4; d = d + 1u) {
                    let kv = keys[kb + d];
                    s = s + dot(kv, queries[qb + d]);
                    kn = kn + dot(kv, kv);
                }
                let den = sqrt(qn * kn);
                if (den > 0.0) {
                    let x = clamp((s / den + 1.0) * 0.5, 0.0, 1.0);
                    let qk = min(u32(x * 2097150.0) + 1u, 2097151u);
                    key = (qk << 11u) | (idx & 2047u);
                }
            }
        }
        wu[idx & 2047u] = key;
    }
    workgroupBarrier();

    // Bitonic sort of the 2,048 keys, descending.
    for (var kk = 1u; kk <= 11u; kk = kk + 1u) {
        let k = 1u << kk;
        for (var jj = 0u; jj < kk; jj = jj + 1u) {
            let j = k >> (jj + 1u);
            for (var e = 0u; e < SCAN_CAP; e = e + 256u) {
                let i = e + t;
                let ixj = i ^ j;
                if (ixj > i && ixj < SCAN_CAP) {
                    let dn = (i & k) == 0u;
                    let a = wu[i];
                    let bb = wu[ixj];
                    if ((dn && a < bb) || (!dn && a > bb)) {
                        wu[i] = bb;
                        wu[ixj] = a;
                    }
                }
            }
            workgroupBarrier();
        }
    }

    if (t < C_MAX && qv) {
        let key = wu[t];
        if (key != 0u) {
            let r = map_row(key & 2047u, nsec);
            if (r < cfg.arrived_end) {
                cands[q * C_MAX + t] = r;
            }
        }
    }
}
