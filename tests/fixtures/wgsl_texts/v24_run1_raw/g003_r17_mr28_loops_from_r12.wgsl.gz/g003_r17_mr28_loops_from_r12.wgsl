// grid 16 16 1 1
// entry ingest grid 16 16 1 1
// entry search grid 16 16 1 1
struct Cfg { seed_slot: u32, stage: u32, arrived_begin: u32, arrived_end: u32, n_queries: u32, pass_index: u32, n_passes: u32, c_max: u32, };
@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

var<workgroup> wbit: array<u32, 64>;
var<workgroup> wq: array<u32, 2>;
var<workgroup> wh: array<atomic<u32>, 65>;
var<workgroup> wthr: u32;
var<workgroup> wc: atomic<u32>;

fn sgn(h0: u32) -> f32 {
    var h = h0 * 2654435761u;
    h = h ^ (h >> 15u);
    h = h * 2246822519u;
    h = h ^ (h >> 13u);
    if ((h & 1u) == 1u) { return -1.0; }
    return 1.0;
}

fn sv(bit: u32, d4: u32) -> vec4<f32> {
    let b = (bit * 2048u + d4 * 4u);
    return vec4<f32>(sgn(b), sgn(b + 1u), sgn(b + 2u), sgn(b + 3u));
}

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = (cfg.arrived_begin + wid.x) & 0x7FFFFu;
    var s = 0.0;
    for (var d = 0u; d < 512u; d += 1u) {
        s += dot(keys[row * 512u + d], sv(t, d));
    }
    var b = 0u;
    if (s > 0.0) { b = 1u; }
    wbit[t] = b;
    workgroupBarrier();
    if (t < 2u) {
        var w = 0u;
        for (var i = 0u; i < 32u; i += 1u) {
            w = w | (wbit[t * 32u + i] << i);
        }
        index_u32[(row * 2u + t) & 0x7FFFFFu] = w;
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x & 0xFFFFu;
    var s = 0.0;
    for (var d = 0u; d < 512u; d += 1u) {
        s += dot(queries[q * 512u + d], sv(t, d));
    }
    var b = 0u;
    if (s > 0.0) { b = 1u; }
    wbit[t] = b;
    for (var i = 0u; i < 2u; i += 1u) {
        let j = t + i * 64u;
        if (j < 65u) { atomicStore(&wh[j], 0u); }
    }
    if (t == 0u) { atomicStore(&wc, 0u); }
    workgroupBarrier();
    if (t < 2u) {
        var w = 0u;
        for (var i = 0u; i < 32u; i += 1u) {
            w = w | (wbit[t * 32u + i] << i);
        }
        wq[t] = w;
    }
    workgroupBarrier();
    let qa = wq[0];
    let qb = wq[1];
    let n = cfg.arrived_end;
    for (var i = 0u; i < n; i += 64u) {
        let r = i + t;
        if (r < n) {
            let rr = r & 0x7FFFFu;
            let dist = countOneBits(index_u32[(rr * 2u) & 0x7FFFFFu] ^ qa) + countOneBits(index_u32[(rr * 2u + 1u) & 0x7FFFFFu] ^ qb);
            atomicAdd(&wh[min(dist, 64u)], 1u);
        }
    }
    workgroupBarrier();
    if (t == 0u) {
        var cum = 0u;
        var thr = 64u;
        for (var k = 0u; k < 65u; k += 1u) {
            cum += atomicLoad(&wh[k]);
            if (cum >= 64u && thr == 64u) { thr = k; }
        }
        wthr = thr;
    }
    workgroupBarrier();
    let thr = wthr;
    for (var i = 0u; i < n; i += 64u) {
        let r = i + t;
        if (r < n) {
            let rr = r & 0x7FFFFu;
            let dist = countOneBits(index_u32[(rr * 2u) & 0x7FFFFFu] ^ qa) + countOneBits(index_u32[(rr * 2u + 1u) & 0x7FFFFFu] ^ qb);
            if (dist < thr) {
                let slot = atomicAdd(&wc, 1u);
                if (slot < 64u) { cands[q * 64u + slot] = r; }
            }
        }
    }
    workgroupBarrier();
    for (var i = 0u; i < n; i += 64u) {
        let r = i + t;
        if (r < n) {
            let rr = r & 0x7FFFFu;
            let dist = countOneBits(index_u32[(rr * 2u) & 0x7FFFFFu] ^ qa) + countOneBits(index_u32[(rr * 2u + 1u) & 0x7FFFFFu] ^ qb);
            if (dist == thr) {
                let slot = atomicAdd(&wc, 1u);
                if (slot < 64u) { cands[q * 64u + slot] = r; }
            }
        }
    }
}
