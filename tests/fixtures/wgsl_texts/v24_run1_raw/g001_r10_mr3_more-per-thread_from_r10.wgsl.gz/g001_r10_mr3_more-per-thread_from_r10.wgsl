// passes 3

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> idx: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const MAXC: u32 = 1024u;
const CID: u32 = 16u;
const CNT: u32 = 2048u;
const PAR: u32 = 3072u;
const MEM: u32 = 4096u;
const FLAG: u32 = 270000u;
const SPLIT: u32 = 40u;
const PER: u32 = 80u;
const NB: u32 = 12u;

var<workgroup> wred: array<f32, 64>;
var<workgroup> wbi: array<u32, 64>;
var<workgroup> wslot: u32;
var<workgroup> wsc: array<f32, 1024>;
var<workgroup> wsel: array<u32, 12>;
var<workgroup> wcnt: array<u32, 12>;
var<workgroup> wn: u32;
var<workgroup> wcs: array<f32, 960>;
var<workgroup> wcr: array<u32, 960>;

fn rowdot(a: u32, b: u32) -> f32 {
    var s = 0.0;
    let ab = (a & 0x7FFFFu) * D4;
    let bb = (b & 0x7FFFFu) * D4;
    for (var d = 0u; d < D4; d = d + 1u) {
        s = s + dot(keys[ab + d], keys[bb + d]);
    }
    return s;
}

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let r = cfg.arrived_begin + wid.x;
    let p = cfg.pass_index;
    if (p == 1u) {
        let nc = min(atomicLoad(&idx[0]), MAXC);
        var best = NONE;
        var bi = 0u;
        for (var i = 0u; i < MAXC; i = i + 64u) {
            let j = i + t;
            if (j < nc) {
                let cid = atomicLoad(&idx[CID + j]);
                let sc = rowdot(r, cid) * index_f32[j];
                if (sc > best) {
                    best = sc;
                    bi = j;
                }
            }
        }
        wred[t] = best;
        wbi[t] = bi;
        workgroupBarrier();
        if (t == 0u && nc > 0u) {
            var b = NONE;
            var bj = 0u;
            for (var k = 0u; k < 64u; k = k + 1u) {
                if (wred[k] > b) {
                    b = wred[k];
                    bj = wbi[k];
                }
            }
            let slot = atomicAdd(&idx[(CNT + bj) & 0xFFFFu], 1u);
            if (slot < 256u) {
                atomicStore(&idx[(MEM + bj * 256u + slot) & 0x3FFFFFu], r);
            }
            if (slot == SPLIT) {
                atomicStore(&idx[FLAG + (r & 16383u)], bj + 1u);
            }
        }
    } else {
        var f = 0u;
        if (p == 0u) {
            if ((r & 31u) == 0u) { f = 1u; }
        } else {
            f = atomicLoad(&idx[FLAG + (r & 16383u)]);
        }
        if (t == 0u) {
            wslot = MAXC;
            if (f != 0u) {
                wslot = atomicAdd(&idx[0], 1u);
            }
        }
        workgroupBarrier();
        let c = wslot;
        var part = 0.0;
        if (c < MAXC) {
            let rb = (r & 0x7FFFFu) * D4;
            for (var i = 0u; i < D4; i = i + 64u) {
                let j = i + t;
                if (j < D4) {
                    let v = keys[rb + j];
                    part = part + dot(v, v);
                }
            }
        }
        wred[t] = part;
        workgroupBarrier();
        if (t == 0u && c < MAXC) {
            var n = 0.0;
            for (var k = 0u; k < 64u; k = k + 1u) { n = n + wred[k]; }
            index_f32[c] = 1.0 / sqrt(max(n, 1.0e-20));
            atomicStore(&idx[CID + c], r);
            if (p == 2u) {
                atomicStore(&idx[PAR + c], f);
            }
            atomicStore(&idx[CNT + c], 1u);
            atomicStore(&idx[MEM + c * 256u], r);
        }
    }
}

@compute @workgroup_size(32)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let qb = (q & 0xFFFFu) * D4;
    let nc = min(atomicLoad(&idx[0]), MAXC);
    for (var i = 0u; i < MAXC; i = i + 32u) {
        let j = i + t;
        if (j < MAXC) {
            var sc = NONE;
            if (j < nc) {
                let cb = (atomicLoad(&idx[CID + j]) & 0x7FFFFu) * D4;
                var s = 0.0;
                for (var d = 0u; d < D4; d = d + 1u) {
                    s = s + dot(keys[cb + d], queries[qb + d]);
                }
                sc = s * index_f32[j];
            }
            wsc[j] = sc;
        }
    }
    workgroupBarrier();
    if (t == 0u) {
        for (var k = 0u; k < NB; k = k + 1u) {
            wsel[k] = 0u;
            wcnt[k] = 0u;
        }
        var ns = 0u;
        for (var k = 0u; k < 6u; k = k + 1u) {
            var b = -2.0e38;
            var bi = MAXC;
            for (var j = 0u; j < MAXC; j = j + 1u) {
                if (j < nc && wsc[j] > b) {
                    b = wsc[j];
                    bi = j;
                }
            }
            if (bi < MAXC) {
                wsel[ns] = bi;
                ns = ns + 1u;
                wsc[bi] = NONE;
            }
        }
        let n0 = ns;
        for (var k = 0u; k < 6u; k = k + 1u) {
            if (k < n0) {
                let pr = atomicLoad(&idx[PAR + wsel[k]]);
                if (pr != 0u) {
                    let pb = pr - 1u;
                    var dup = false;
                    for (var m = 0u; m < NB; m = m + 1u) {
                        if (m < ns && wsel[m] == pb) { dup = true; }
                    }
                    if (!dup && ns < NB) {
                        wsel[ns] = pb;
                        ns = ns + 1u;
                    }
                }
            }
        }
        for (var k = 0u; k < NB; k = k + 1u) {
            if (k < ns) {
                wcnt[k] = min(atomicLoad(&idx[(CNT + wsel[k]) & 0xFFFFu]), PER);
            }
        }
        wn = ns;
    }
    workgroupBarrier();
    for (var i = 0u; i < 960u; i = i + 32u) {
        let s = i + t;
        if (s < 960u) {
            let b = s / PER;
            let k = s % PER;
            var row = PAD;
            var sc = NONE;
            if (b < wn && k < wcnt[b]) {
                row = atomicLoad(&idx[(MEM + wsel[b] * 256u + k) & 0x3FFFFFu]);
                if (row >= cfg.arrived_end) {
                    row = PAD;
                }
            }
            if (row != PAD) {
                let kb = (row & 0x7FFFFu) * D4;
                var d0 = 0.0;
                var kn = 0.0;
                for (var d = 0u; d < D4; d = d + 1u) {
                    let kv = keys[kb + d];
                    d0 = d0 + dot(kv, queries[qb + d]);
                    kn = kn + dot(kv, kv);
                }
                if (kn > 0.0) {
                    sc = d0 / sqrt(kn);
                } else {
                    row = PAD;
                }
            }
            wcs[s] = sc;
            wcr[s] = row;
        }
    }
    workgroupBarrier();
    for (var i = 0u; i < 960u; i = i + 32u) {
        let s = i + t;
        if (s < 960u && wcr[s] != PAD) {
            let me = wcs[s];
            var rank = 0u;
            for (var j = 0u; j < 960u; j = j + 1u) {
                if (wcr[j] != PAD) {
                    let o = wcs[j];
                    if (o > me || (o == me && j < s)) {
                        rank = rank + 1u;
                    }
                }
            }
            if (rank < 64u) {
                cands[q * 64u + rank] = wcr[s];
            }
        }
    }
}
