// passes 3

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const RMASK: u32 = 32767u;
const BUFSZ: u32 = 262144u;
const FAR0: u32 = 786432u;

var<workgroup> sc: array<f32, 128>;
var<workgroup> sid: array<u32, 128>;
var<workgroup> red: array<f32, 64>;

var<workgroup> rs: array<f32, 64>;
var<workgroup> rid: array<u32, 64>;
var<workgroup> rx: array<u32, 64>;
var<workgroup> cs: array<f32, 128>;
var<workgroup> cid: array<u32, 128>;
var<workgroup> fid: array<u32, 8>;

fn h(x: u32) -> u32 {
    var v = x * 747796405u + 2891336453u;
    v = ((v >> ((v >> 28u) + 4u)) ^ v) * 277803737u;
    return (v >> 22u) ^ v;
}

fn nearIdx(buf: u32, r: u32, k: u32) -> u32 {
    return (buf & 3u) * BUFSZ + (r & RMASK) * 8u + (k & 7u);
}

fn farIdx(r: u32, k: u32) -> u32 {
    return FAR0 + (r & RMASK) * 2u + (k & 1u);
}

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = cfg.arrived_begin + wid.x;
    let end = max(cfg.arrived_end, 1u);
    let p = cfg.pass_index;
    let rb = (row & 0x7FFFFu) * D4;

    for (var i = 0u; i < 2u; i += 1u) {
        sc[t + i * 64u] = NONE;
        sid[t + i * 64u] = PAD;
    }

    if (p == 0u) {
        var acc = 0.0;
        for (var i = 0u; i < 8u; i += 1u) {
            let v = keys[rb + i * 64u + t];
            acc += dot(v, v);
        }
        red[t] = acc;
        workgroupBarrier();
        if (t == 0u) {
            var tot = 0.0;
            for (var i = 0u; i < 64u; i += 1u) {
                tot += red[i];
            }
            var inv = 0.0;
            if (tot > 0.0) {
                inv = inverseSqrt(tot);
            }
            index_f32[row & RMASK] = inv;
        }
        if (t < 2u) {
            var f = h(row * 31u + t * 7919u + 12345u) % end;
            if (f == row) {
                f = (f + 1u) % end;
            }
            index_u32[farIdx(row, t)] = f;
        }
        for (var i = 0u; i < 4u; i += 1u) {
            let s = t + i * 64u;
            let c = h(row * 7u + s * 2654435u + 99u) % end;
            if (c != row) {
                let cb = (c & 0x7FFFFu) * D4;
                var d = 0.0;
                var kn = 0.0;
                for (var j = 0u; j < D4; j += 1u) {
                    let k = keys[cb + j];
                    d += dot(k, keys[rb + j]);
                    kn += dot(k, k);
                }
                if (kn > 0.0) {
                    sc[s & 127u] = d * inverseSqrt(kn);
                    sid[s & 127u] = c;
                }
            }
        }
    } else {
        for (var i = 0u; i < 2u; i += 1u) {
            let s = t + i * 64u;
            if (s < 96u) {
                let a = s / 12u;
                let b = s % 12u;
                let nbr = index_u32[nearIdx(p - 1u, row, a)] % end;
                var c = nbr;
                if (b < 8u) {
                    var bsel = 2u;
                    if (nbr >= cfg.arrived_begin) {
                        bsel = p - 1u;
                    }
                    c = index_u32[nearIdx(bsel, nbr, b)] % end;
                } else if (b < 10u) {
                    c = index_u32[farIdx(nbr, b - 8u)] % end;
                } else if (b == 11u) {
                    c = h(row * 13u + p * 1000003u + s) % end;
                }
                if (c != row) {
                    let cb = (c & 0x7FFFFu) * D4;
                    var d = 0.0;
                    for (var j = 0u; j < D4; j += 1u) {
                        d += dot(keys[cb + j], keys[rb + j]);
                    }
                    let inv = index_f32[c & RMASK];
                    if (inv > 0.0) {
                        sc[s] = d * inv;
                        sid[s] = c;
                    }
                }
            }
        }
    }
    workgroupBarrier();
    if (t == 0u) {
        for (var k = 0u; k < 8u; k += 1u) {
            var bi = 0u;
            var bs = NONE;
            for (var j = 0u; j < 128u; j += 1u) {
                if (sc[j] > bs) {
                    bs = sc[j];
                    bi = j;
                }
            }
            var id = (row + 1u + k) % end;
            if (bs > NONE) {
                id = sid[bi];
                for (var j = 0u; j < 128u; j += 1u) {
                    if (sid[j] == id) {
                        sc[j] = NONE;
                    }
                }
            }
            index_u32[nearIdx(p, row, k)] = id;
        }
    }
}

fn dotq(q: u32, c: u32) -> f32 {
    let qb = (q & 0x7FFFu) * D4;
    let cb = (c & 0x7FFFFu) * D4;
    var d = 0.0;
    for (var j = 0u; j < D4; j += 1u) {
        d += dot(keys[cb + j], queries[qb + j]);
    }
    return d * index_f32[c & RMASK];
}

fn merge(n: u32) {
    for (var i = 0u; i < n; i += 1u) {
        let id = cid[i];
        let s0 = cs[i];
        if (id != PAD && s0 > rs[63]) {
            var dup = false;
            for (var j = 0u; j < 64u; j += 1u) {
                if (rid[j] == id) {
                    dup = true;
                }
            }
            if (!dup) {
                var cs2 = s0;
                var cr = id;
                var cx = 0u;
                for (var j = 0u; j < 64u; j += 1u) {
                    if (cs2 > rs[j]) {
                        let ts = rs[j];
                        let tr = rid[j];
                        let tx = rx[j];
                        rs[j] = cs2;
                        rid[j] = cr;
                        rx[j] = cx;
                        cs2 = ts;
                        cr = tr;
                        cx = tx;
                    }
                }
            }
        }
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let q = wid.x;
    let t = lid.x;
    let end = max(cfg.arrived_end, 1u);

    rs[t] = NONE;
    rid[t] = PAD;
    rx[t] = 0u;
    cs[t] = NONE;
    cid[t] = PAD;
    cs[t + 64u] = NONE;
    cid[t + 64u] = PAD;
    if (t < 8u) {
        let c = h(q * 977u + t * 131u + cfg.seed_slot * 17u + 5u) % end;
        cid[t] = c;
        cs[t] = dotq(q, c);
    }
    workgroupBarrier();
    if (t == 0u) {
        merge(8u);
    }
    workgroupBarrier();

    for (var r = 0u; r < 14u; r += 1u) {
        if (t == 0u) {
            var nf = 0u;
            for (var j = 0u; j < 8u; j += 1u) {
                fid[j] = PAD;
            }
            for (var j = 0u; j < 64u; j += 1u) {
                if (nf < 8u && rid[j] != PAD && rx[j] == 0u) {
                    rx[j] = 1u;
                    fid[nf] = rid[j];
                    nf += 1u;
                }
            }
        }
        workgroupBarrier();
        for (var i = 0u; i < 2u; i += 1u) {
            let s = t + i * 64u;
            if (s < 80u) {
                let a = s / 10u;
                let b = s % 10u;
                let f = fid[a];
                var id = PAD;
                var scr = NONE;
                if (f != PAD) {
                    if (b < 8u) {
                        id = index_u32[nearIdx(2u, f, b)] % end;
                    } else {
                        id = index_u32[farIdx(f, b - 8u)] % end;
                    }
                    scr = dotq(q, id);
                }
                cid[s] = id;
                cs[s] = scr;
            }
        }
        workgroupBarrier();
        if (t == 0u) {
            merge(80u);
        }
        workgroupBarrier();
    }

    if (q < cfg.n_queries) {
        var out = rid[t];
        if (rs[t] <= NONE) {
            out = PAD;
        }
        cands[q * 64u + t] = out;
    }
}
