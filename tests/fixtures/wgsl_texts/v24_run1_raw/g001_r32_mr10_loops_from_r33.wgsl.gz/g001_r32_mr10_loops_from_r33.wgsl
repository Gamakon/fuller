// grid 16 16 1 1
// entry ingest grid 16 16 1 1
// entry search grid 16 16 1 1
struct Cfg { seed_slot: u32, stage: u32, arrived_begin: u32, arrived_end: u32, n_queries: u32, pass_index: u32, n_passes: u32, c_max: u32, };
@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;

var<workgroup> wsq: array<f32, 64>;
var<workgroup> wnorm: f32;
var<workgroup> cs: array<f32, 512>;
var<workgroup> cr: array<u32, 512>;

fn sgn(j: u32, d: u32) -> f32 {
    var h = (j * 2048u + d) * 2654435761u;
    h = h ^ (h >> 15u);
    h = h * 2246822519u;
    h = h ^ (h >> 13u);
    if ((h & 1u) == 0u) { return 1.0; }
    return -1.0;
}

fn sketch(src_is_query: bool, base: u32, j: u32) -> f32 {
    var s = 0.0;
    for (var d4 = 0u; d4 < 512u; d4 += 1u) {
        var v: vec4<f32>;
        if (src_is_query) {
            v = queries[(base & 0x1FFFu) * 512u + d4];
        } else {
            v = keys[(base & 0x7FFFFu) * 512u + d4];
        }
        let d = d4 * 4u;
        s += v.x * sgn(j, d) + v.y * sgn(j, d + 1u) + v.z * sgn(j, d + 2u) + v.w * sgn(j, d + 3u);
    }
    return s;
}

@compute @workgroup_size(64, 1, 1)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let r = cfg.arrived_begin + wid.x;
    let valid = r < cfg.arrived_end;
    var s = 0.0;
    if (valid) { s = sketch(false, r, t); }
    wsq[t] = s * s;
    workgroupBarrier();
    if (t == 0u) {
        var n = 0.0;
        for (var i = 0u; i < 64u; i += 1u) { n += wsq[i]; }
        wnorm = n;
    }
    workgroupBarrier();
    if (valid) {
        let b = (r & 0xFFFFu) * 65u;
        index_f32[b + t] = s;
        if (t == 0u) { index_f32[b + 64u] = wnorm; }
    }
}

var<workgroup> qs: array<f32, 64>;

@compute @workgroup_size(64, 1, 1)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let qv = q < cfg.n_queries;
    var s = 0.0;
    if (qv) { s = sketch(true, q, t); }
    qs[t] = s;
    wsq[t] = s * s;
    workgroupBarrier();
    if (t == 0u) {
        var n = 0.0;
        for (var i = 0u; i < 64u; i += 1u) { n += wsq[i]; }
        wnorm = n;
    }
    workgroupBarrier();
    let qn = wnorm;
    var bs: array<f32, 8>;
    var br: array<u32, 8>;
    for (var j = 0u; j < 8u; j += 1u) { bs[j] = NONE; br[j] = PAD; }
    if (qv) {
        for (var i = 0u; i < 25000u; i += 64u) {
            let r = i + t;
            if (r < cfg.arrived_end) {
                let b = (r & 0xFFFFu) * 65u;
                var dt = 0.0;
                for (var k = 0u; k < 64u; k += 1u) { dt += qs[k] * index_f32[b + k]; }
                let rn = index_f32[b + 64u];
                var sc = NONE;
                let den = qn * rn;
                if (den > 0.0) { sc = dt / sqrt(den); }
                if (sc > bs[7]) {
                    var cs2 = sc;
                    var cr2 = r;
                    for (var j = 0u; j < 8u; j += 1u) {
                        if (cs2 > bs[j]) {
                            let ts = bs[j];
                            let tr = br[j];
                            bs[j] = cs2;
                            br[j] = cr2;
                            cs2 = ts;
                            cr2 = tr;
                        }
                    }
                }
            }
        }
    }
    for (var j = 0u; j < 8u; j += 1u) {
        cs[t * 8u + j] = bs[j];
        cr[t * 8u + j] = br[j];
    }
    workgroupBarrier();
    if (qv) {
        for (var j = 0u; j < 8u; j += 1u) {
            let me = t * 8u + j;
            let ms = cs[me];
            if (cr[me] != PAD) {
                var rank = 0u;
                for (var o = 0u; o < 512u; o += 1u) {
                    let os = cs[o];
                    if (cr[o] != PAD && (os > ms || (os == ms && o < me))) {
                        rank += 1u;
                    }
                }
                if (rank < 64u) {
                    cands[q * 64u + rank] = cr[me];
                }
            }
        }
    }
}
