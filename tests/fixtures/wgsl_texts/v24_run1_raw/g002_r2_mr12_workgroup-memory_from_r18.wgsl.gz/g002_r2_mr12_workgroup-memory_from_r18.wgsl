// passes 1
struct Cfg { seed_slot: u32, stage: u32, arrived_begin: u32, arrived_end: u32, n_queries: u32, pass_index: u32, n_passes: u32, c_max: u32, };
@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;

var<workgroup> red: array<f32, 64>;
var<workgroup> wq: array<vec4<f32>, 512>;
var<workgroup> ws: array<f32, 512>;
var<workgroup> wr: array<u32, 512>;

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_index) lidx: u32, @builtin(workgroup_id) wid: vec3<u32>) {
    let row = (cfg.arrived_begin + wid.x) & 0x7FFFFu;
    var acc = 0.0;
    for (var i = 0u; i < 8u; i += 1u) {
        let d = i * 64u + lidx;
        let k = keys[row * 512u + d];
        acc += dot(k, k);
    }
    red[lidx] = acc;
    workgroupBarrier();
    for (var s = 32u; s > 0u; s = s >> 1u) {
        if (lidx < s) {
            red[lidx] = red[lidx] + red[lidx + s];
        }
        workgroupBarrier();
    }
    if (lidx == 0u) {
        var inv = 0.0;
        if (red[0] > 0.0) {
            inv = inverseSqrt(red[0]);
        }
        index_f32[row & 0xFFFFFu] = inv;
    }
}

@compute @workgroup_size(128)
fn search(@builtin(local_invocation_index) t: u32, @builtin(workgroup_id) wid: vec3<u32>) {
    let q = wid.x;
    let qc = q & 0xFFFFu;
    for (var i = 0u; i < 4u; i += 1u) {
        let d = i * 128u + t;
        wq[d] = queries[qc * 512u + d];
    }
    workgroupBarrier();
    var bs: array<f32, 4>;
    var br: array<u32, 4>;
    for (var j = 0u; j < 4u; j += 1u) {
        bs[j] = NONE;
        br[j] = PAD;
    }
    for (var i = 0u; i < cfg.arrived_end; i += 128u) {
        let r = i + t;
        if (r < cfg.arrived_end) {
            let rm = r & 0x7FFFFu;
            let inv = index_f32[rm & 0xFFFFFu];
            if (inv > 0.0) {
                var s = 0.0;
                for (var d = 0u; d < 512u; d += 1u) {
                    s += dot(keys[rm * 512u + d], wq[d]);
                }
                let score = s * inv;
                if (score > bs[3]) {
                    var cs = score;
                    var cr = r;
                    for (var j = 0u; j < 4u; j += 1u) {
                        if (cs > bs[j]) {
                            let ts = bs[j];
                            let tr = br[j];
                            bs[j] = cs;
                            br[j] = cr;
                            cs = ts;
                            cr = tr;
                        }
                    }
                }
            }
        }
    }
    for (var j = 0u; j < 4u; j += 1u) {
        ws[t * 4u + j] = bs[j];
        wr[t * 4u + j] = br[j];
    }
    workgroupBarrier();
    if (q < cfg.n_queries) {
        for (var j = 0u; j < 4u; j += 1u) {
            let me = t * 4u + j;
            let r0 = wr[me];
            if (r0 != PAD) {
                let s0 = ws[me];
                var rank = 0u;
                for (var o = 0u; o < 512u; o += 1u) {
                    let ro = wr[o];
                    if (ro != PAD) {
                        let so = ws[o];
                        if (so > s0 || (so == s0 && o < me)) {
                            rank += 1u;
                        }
                    }
                }
                if (rank < 64u) {
                    cands[q * 64u + rank] = r0;
                }
            }
        }
    }
}
