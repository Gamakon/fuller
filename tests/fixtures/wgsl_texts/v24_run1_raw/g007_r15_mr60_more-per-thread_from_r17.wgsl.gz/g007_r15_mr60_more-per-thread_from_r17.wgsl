// grid 16 16 1 1
// entry ingest grid 16 16 1 1
// entry search grid 16 16 1 1
struct Cfg { seed_slot: u32, stage: u32, arrived_begin: u32, arrived_end: u32, n_queries: u32, pass_index: u32, n_passes: u32, c_max: u32, };
@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;
@compute @workgroup_size(16, 16, 1)
fn ingest(@builtin(global_invocation_id) gid: vec3<u32>, @builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>, @builtin(local_invocation_index) lidx: u32, @builtin(num_workgroups) nwg: vec3<u32>) {
}
@compute @workgroup_size(16, 16, 1)
fn search(@builtin(global_invocation_id) gid: vec3<u32>, @builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>, @builtin(local_invocation_index) lidx: u32, @builtin(num_workgroups) nwg: vec3<u32>) {
    let q = wid.x;
    if (q < cfg.n_queries && lidx < 16u) {
        // Each of 16 threads handles four output slots (t, t+16, t+32, t+48).
        for (var i = 0u; i < 4u; i = i + 1u) {
            let slot = lidx + i * 16u;
            cands[((q * 64u) & 0x3FFFFFu) + slot] = 0xFFFFFFFFu;
        }
    }
}
