// passes 2

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> idx: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;
const MAXC: u32 = 768u;
const CAP: u32 = 128u;
const NP: u32 = 6u;
const CEN: u32 = 16u;
const BCNT: u32 = 1024u;
const BMEM: u32 = 2048u;

var<workgroup> wkey: array<vec4<f32>, 512>;
var<workgroup> red: array<f32, 256>;
var<workgroup> wa: array<f32, 512>;
var<workgroup> wi: array<u32, 512>;
var<workgroup> wcs: array<f32, 768>;
var<workgroup> wmem: array<u32, 768>;
var<workgroup> wsel: array<u32, 8>;

fn hash32(x: u32) -> u32 {
    var h = x;
    h = h ^ (h >> 16u);
    h = h * 0x7feb352du;
    h = h ^ (h >> 15u);
    h = h * 0x846ca68bu;
    h = h ^ (h >> 16u);
    return h;
}

@compute @workgroup_size(256)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = (cfg.arrived_begin + wid.x) & 0x7FFFFu;
    if (cfg.pass_index == 0u) {
        var ss = 0.0;
        for (var i = 0u; i < D4; i += 256u) {
            let j = i + t;
            if (j < D4) {
                let v = keys[row * D4 + j];
                ss += dot(v, v);
            }
        }
        red[t] = ss;
        workgroupBarrier();
        for (var k = 0u; k < 8u; k += 1u) {
            let s = 128u >> k;
            if (t < s) {
                red[t] = red[t] + red[t + s];
            }
            workgroupBarrier();
        }
        if (t == 0u) {
            let n = red[0];
            var inv = 0.0;
            if (n > 0.0) {
                inv = inverseSqrt(n);
            }
            index_f32[row] = inv;
            let h = hash32(row * 2654435761u + cfg.seed_slot * 97u + 12345u);
            if ((h & 31u) == 0u || row == 0u) {
                let slot = atomicAdd(&idx[0], 1u);
                if (slot < MAXC) {
                    atomicStore(&idx[CEN + slot], row);
                }
            }
        }
        return;
    }
    // pass 1: assign to the two nearest promoted centres
    for (var i = 0u; i < D4; i += 256u) {
        let j = i + t;
        if (j < D4) {
            wkey[j] = keys[row * D4 + j];
        }
    }
    workgroupBarrier();
    let nc = min(atomicLoad(&idx[0]), MAXC);
    var b1 = NONE;
    var i1 = PAD;
    var b2 = NONE;
    var i2 = PAD;
    for (var i = 0u; i < MAXC; i += 256u) {
        let c = i + t;
        if (c < nc) {
            let cr = atomicLoad(&idx[CEN + c]) & 0x7FFFFu;
            var s = 0.0;
            for (var d = 0u; d < D4; d += 1u) {
                s += dot(wkey[d], keys[cr * D4 + d]);
            }
            let sc = s * index_f32[cr];
            if (sc > b1) {
                b2 = b1;
                i2 = i1;
                b1 = sc;
                i1 = c;
            } else if (sc > b2) {
                b2 = sc;
                i2 = c;
            }
        }
    }
    wa[t * 2u] = b1;
    wa[t * 2u + 1u] = b2;
    wi[t * 2u] = i1;
    wi[t * 2u + 1u] = i2;
    workgroupBarrier();
    if (t == 0u) {
        var c1 = NONE;
        var j1 = PAD;
        var c2 = NONE;
        var j2 = PAD;
        for (var k = 0u; k < 512u; k += 1u) {
            let sc = wa[k];
            let ci = wi[k];
            if (ci != PAD) {
                if (sc > c1) {
                    c2 = c1;
                    j2 = j1;
                    c1 = sc;
                    j1 = ci;
                } else if (sc > c2) {
                    c2 = sc;
                    j2 = ci;
                }
            }
        }
        if (j1 != PAD) {
            let c = j1 & 1023u;
            let pos = atomicAdd(&idx[BCNT + c], 1u);
            if (pos < CAP) {
                atomicStore(&idx[(BMEM + c * CAP + pos) & 0x1FFFFFu], row);
            }
        }
        if (j2 != PAD) {
            let c = j2 & 1023u;
            let pos = atomicAdd(&idx[BCNT + c], 1u);
            if (pos < CAP) {
                atomicStore(&idx[(BMEM + c * CAP + pos) & 0x1FFFFFu], row);
            }
        }
    }
}

@compute @workgroup_size(256)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let qq = min(q, 4095u);
    for (var i = 0u; i < D4; i += 256u) {
        let j = i + t;
        if (j < D4) {
            wkey[j] = queries[qq * D4 + j];
        }
    }
    workgroupBarrier();
    let nc = min(atomicLoad(&idx[0]), MAXC);
    for (var i = 0u; i < MAXC; i += 256u) {
        let c = i + t;
        if (c < MAXC) {
            var sc = NONE;
            if (c < nc) {
                let cr = atomicLoad(&idx[CEN + c]) & 0x7FFFFu;
                var s = 0.0;
                for (var d = 0u; d < D4; d += 1u) {
                    s += dot(wkey[d], keys[cr * D4 + d]);
                }
                sc = s * index_f32[cr];
            }
            wcs[c] = sc;
        }
    }
    workgroupBarrier();
    if (t == 0u) {
        for (var p = 0u; p < NP; p += 1u) {
            var bs = NONE;
            var bi = PAD;
            for (var c = 0u; c < MAXC; c += 1u) {
                if (wcs[c] > bs) {
                    bs = wcs[c];
                    bi = c;
                }
            }
            wsel[p] = bi;
            if (bi != PAD) {
                wcs[bi] = NONE;
            }
        }
    }
    workgroupBarrier();
    // member scoring: NP * CAP slots
    var sc3: array<f32, 3>;
    for (var u = 0u; u < 3u; u += 1u) {
        let j = u * 256u + t;
        var sc = NONE;
        var rr = PAD;
        let p = j / CAP;
        let k = j % CAP;
        if (p < NP) {
            let c = wsel[p];
            if (c != PAD) {
                let cnt = min(atomicLoad(&idx[BCNT + (c & 1023u)]), CAP);
                if (k < cnt) {
                    rr = atomicLoad(&idx[(BMEM + (c & 1023u) * CAP + k) & 0x1FFFFFu]) & 0x7FFFFu;
                    var s = 0.0;
                    for (var d = 0u; d < D4; d += 1u) {
                        s += dot(wkey[d], keys[rr * D4 + d]);
                    }
                    sc = s * index_f32[rr];
                }
            }
        }
        sc3[u] = sc;
        wmem[j] = rr;
    }
    workgroupBarrier();
    for (var u = 0u; u < 3u; u += 1u) {
        let j = u * 256u + t;
        wcs[j] = sc3[u];
    }
    workgroupBarrier();
    // dedupe
    var dup: array<bool, 3>;
    for (var u = 0u; u < 3u; u += 1u) {
        let j = u * 256u + t;
        var d = false;
        let rj = wmem[j];
        if (rj != PAD) {
            for (var i = 0u; i < MAXC; i += 1u) {
                if (i < j && wmem[i] == rj) {
                    d = true;
                }
            }
        }
        dup[u] = d;
    }
    workgroupBarrier();
    for (var u = 0u; u < 3u; u += 1u) {
        if (dup[u]) {
            wcs[u * 256u + t] = NONE;
            wmem[u * 256u + t] = PAD;
        }
    }
    workgroupBarrier();
    if (q < cfg.n_queries) {
        for (var u = 0u; u < 3u; u += 1u) {
            let j = u * 256u + t;
            let rj = wmem[j];
            if (rj != PAD) {
                let sj = wcs[j];
                var rank = 0u;
                for (var i = 0u; i < MAXC; i += 1u) {
                    if (wmem[i] != PAD) {
                        let si = wcs[i];
                        if (si > sj || (si == sj && i < j)) {
                            rank += 1u;
                        }
                    }
                }
                if (rank < 64u) {
                    cands[q * 64u + rank] = rj;
                }
            }
        }
    }
}
