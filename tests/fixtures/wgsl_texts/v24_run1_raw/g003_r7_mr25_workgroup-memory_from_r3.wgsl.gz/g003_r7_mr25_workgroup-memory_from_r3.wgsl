// passes 1
struct Cfg { seed_slot: u32, stage: u32, arrived_begin: u32, arrived_end: u32, n_queries: u32, pass_index: u32, n_passes: u32, c_max: u32, };
@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const K: u32 = 64u;
const CAP: u32 = 4096u;
const NPROBE: u32 = 8u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;

var<workgroup> wvec: array<vec4<f32>, 512>;
var<workgroup> wsc: array<f32, 64>;
var<workgroup> wsel: array<u32, 8>;
var<workgroup> cs: array<f32, 256>;
var<workgroup> cr: array<u32, 256>;

fn centre_id(c: u32) -> u32 {
    let per = max(cfg.arrived_end / max(cfg.stage, 1u), 64u);
    return ((c & 63u) * (per / 64u)) & 0x7FFFFu;
}

fn centre_score(c: u32) -> f32 {
    let base = centre_id(c) * D4;
    var s = 0.0;
    var kn = 0.0;
    for (var d = 0u; d < D4; d = d + 1u) {
        let ck = keys[base + d];
        s = s + dot(wvec[d], ck);
        kn = kn + dot(ck, ck);
    }
    if (kn > 0.0) {
        return s / sqrt(kn);
    }
    return NONE;
}

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = (cfg.arrived_begin + wid.x) & 0x7FFFFu;
    for (var k = 0u; k < 8u; k = k + 1u) {
        let d = t + k * 64u;
        wvec[d] = keys[row * D4 + d];
    }
    workgroupBarrier();
    wsc[t] = centre_score(t);
    workgroupBarrier();
    if (t == 0u) {
        var best = NONE;
        var bc = 0u;
        for (var c = 0u; c < K; c = c + 1u) {
            if (wsc[c] > best) {
                best = wsc[c];
                bc = c;
            }
        }
        let slot = atomicAdd(&index_u32[bc & 63u], 1u);
        if (slot < CAP) {
            atomicStore(&index_u32[1024u + (bc & 63u) * CAP + (slot & 4095u)], row);
        }
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x & 0x3FFFu;
    for (var k = 0u; k < 8u; k = k + 1u) {
        let d = t + k * 64u;
        wvec[d] = queries[q * D4 + d];
    }
    workgroupBarrier();
    wsc[t] = centre_score(t);
    workgroupBarrier();
    if (t == 0u) {
        for (var p = 0u; p < NPROBE; p = p + 1u) {
            var best = NONE - 1.0;
            var bc = 0u;
            for (var c = 0u; c < K; c = c + 1u) {
                if (wsc[c] > best) {
                    best = wsc[c];
                    bc = c;
                }
            }
            wsel[p] = bc;
            wsc[bc] = NONE - 2.0;
        }
    }
    workgroupBarrier();
    var bs: array<f32, 4>;
    var br: array<u32, 4>;
    for (var j = 0u; j < 4u; j = j + 1u) {
        bs[j] = NONE;
        br[j] = PAD;
    }
    for (var p = 0u; p < NPROBE; p = p + 1u) {
        let c = wsel[p] & 63u;
        let n = min(atomicLoad(&index_u32[c]), CAP);
        for (var i = 0u; i < CAP; i = i + 64u) {
            let j = i + t;
            if (j < n) {
                let r = atomicLoad(&index_u32[1024u + c * CAP + (j & 4095u)]) & 0x7FFFFu;
                var s = 0.0;
                var kn = 0.0;
                for (var d = 0u; d < D4; d = d + 1u) {
                    let k = keys[r * D4 + d];
                    s = s + dot(k, wvec[d]);
                    kn = kn + dot(k, k);
                }
                var score = NONE;
                if (kn > 0.0) {
                    score = s / sqrt(kn);
                }
                if (score > bs[3]) {
                    var ns = score;
                    var nr = r;
                    for (var m = 0u; m < 4u; m = m + 1u) {
                        if (ns > bs[m]) {
                            let ts = bs[m];
                            let tr = br[m];
                            bs[m] = ns;
                            br[m] = nr;
                            ns = ts;
                            nr = tr;
                        }
                    }
                }
            }
        }
    }
    for (var j = 0u; j < 4u; j = j + 1u) {
        cs[t * 4u + j] = bs[j];
        cr[t * 4u + j] = br[j];
    }
    workgroupBarrier();
    for (var k = 0u; k < 4u; k = k + 1u) {
        let e = t + k * 64u;
        if (cr[e] != PAD) {
            let se = cs[e];
            var rank = 0u;
            for (var f = 0u; f < 256u; f = f + 1u) {
                if (cr[f] != PAD) {
                    let sf = cs[f];
                    if (sf > se || (sf == se && f < e)) {
                        rank = rank + 1u;
                    }
                }
            }
            if (rank < 64u) {
                cands[q * 64u + rank] = cr[e];
            }
        }
    }
}
