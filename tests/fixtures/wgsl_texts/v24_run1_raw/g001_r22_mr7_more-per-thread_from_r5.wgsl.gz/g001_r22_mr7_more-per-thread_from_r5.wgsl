// passes 2

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const D4: u32 = 512u;
const NC: u32 = 128u;
const CAP: u32 = 512u;
const MEM0: u32 = 1024u;
const NP: u32 = 6u;
const PAD: u32 = 0xFFFFFFFFu;
const NONE: f32 = -3.0e38;

var<workgroup> wscore: array<f32, 3072>;
var<workgroup> wbest: array<f32, 64>;
var<workgroup> widx: array<u32, 64>;
var<workgroup> wbk: array<u32, 8>;

@compute @workgroup_size(32)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let r = (cfg.arrived_begin + wid.x) & 0x7FFFFu;
    if (cfg.pass_index == 0u) {
        // level 1: register centres, a strided sample of the first microbatch
        if (t == 0u && cfg.stage == 1u) {
            let S = max(1u, (cfg.arrived_end - cfg.arrived_begin) / NC);
            if (r % S == 0u && (r / S) < NC) {
                atomicStore(&index_u32[(r / S) & 127u], r + 1u);
            }
        }
        return;
    }
    // level 0: assign the row to its nearest centre; four centres per thread
    var bs = NONE;
    var bc = PAD;
    for (var i = 0u; i < 4u; i += 1u) {
        let c = t + i * 32u;
        let cr1 = atomicLoad(&index_u32[c & 127u]);
        if (cr1 != 0u) {
            let cr = (cr1 - 1u) & 0x7FFFFu;
            var s = 0.0;
            var n = 0.0;
            for (var d = 0u; d < D4; d += 1u) {
                let cv = keys[cr * D4 + d];
                s += dot(cv, keys[r * D4 + d]);
                n += dot(cv, cv);
            }
            let sc = s * inverseSqrt(n + 1e-20);
            if (sc > bs) {
                bs = sc;
                bc = c;
            }
        }
    }
    wbest[t] = bs;
    widx[t] = bc;
    workgroupBarrier();
    for (var st = 16u; st > 0u; st = st >> 1u) {
        if (t < st) {
            if (wbest[t + st] > wbest[t]) {
                wbest[t] = wbest[t + st];
                widx[t] = widx[t + st];
            }
        }
        workgroupBarrier();
    }
    if (t == 0u) {
        let c = widx[0];
        if (c != PAD) {
            let pos = atomicAdd(&index_u32[(NC + (c & 127u)) & 1023u], 1u);
            if (pos < CAP) {
                atomicStore(&index_u32[(MEM0 + (c & 127u) * CAP + pos) & 0x7FFFFFu], r + 1u);
            }
        }
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    if (q >= cfg.n_queries) {
        return;
    }
    // centre scores
    for (var i = 0u; i < 2u; i += 1u) {
        let c = t + i * 64u;
        var sc = NONE;
        let cr1 = atomicLoad(&index_u32[c & 127u]);
        if (cr1 != 0u) {
            let cr = (cr1 - 1u) & 0x7FFFFu;
            var s = 0.0;
            var n = 0.0;
            for (var d = 0u; d < D4; d += 1u) {
                let cv = keys[cr * D4 + d];
                s += dot(cv, queries[q * D4 + d]);
                n += dot(cv, cv);
            }
            sc = s * inverseSqrt(n + 1e-20);
        }
        wscore[c & 127u] = sc;
    }
    workgroupBarrier();
    if (t == 0u) {
        for (var k = 0u; k < NP; k += 1u) {
            var b = NONE;
            var bi = PAD;
            for (var c = 0u; c < NC; c += 1u) {
                if (wscore[c] > b) {
                    b = wscore[c];
                    bi = c;
                }
            }
            wbk[k] = bi;
            if (bi != PAD) {
                wscore[bi & 127u] = NONE;
            }
        }
    }
    workgroupBarrier();
    var bk: array<u32, 6>;
    var cn: array<u32, 6>;
    for (var k = 0u; k < NP; k += 1u) {
        bk[k] = wbk[k];
        cn[k] = 0u;
        if (bk[k] != PAD) {
            cn[k] = min(CAP, atomicLoad(&index_u32[(NC + (bk[k] & 127u)) & 1023u]));
        }
    }
    workgroupBarrier();
    // score members of the probed buckets
    for (var i = 0u; i < 48u; i += 1u) {
        let s = i * 64u + t;
        let bi = s / CAP;
        let j = s % CAP;
        var sc = NONE;
        var bq = 0u;
        for (var k = 0u; k < NP; k += 1u) {
            if (k == bi) {
                bq = k;
            }
        }
        if (bi < NP && j < cn[bq]) {
            let m = atomicLoad(&index_u32[(MEM0 + (bk[bq] & 127u) * CAP + j) & 0x7FFFFFu]);
            if (m != 0u) {
                let row = (m - 1u) & 0x7FFFFu;
                var dt = 0.0;
                var n = 0.0;
                for (var d = 0u; d < D4; d += 1u) {
                    let kv = keys[row * D4 + d];
                    dt += dot(kv, queries[q * D4 + d]);
                    n += dot(kv, kv);
                }
                if (n > 0.0) {
                    sc = dt * inverseSqrt(n);
                }
            }
        }
        wscore[s] = sc;
    }
    workgroupBarrier();
    // top 64 by repeated argmax
    for (var rd = 0u; rd < 64u; rd += 1u) {
        var b = NONE;
        var bi = PAD;
        for (var i = 0u; i < 48u; i += 1u) {
            let s = i * 64u + t;
            if (wscore[s] > b) {
                b = wscore[s];
                bi = s;
            }
        }
        wbest[t] = b;
        widx[t] = bi;
        workgroupBarrier();
        for (var st = 32u; st > 0u; st = st >> 1u) {
            if (t < st) {
                if (wbest[t + st] > wbest[t]) {
                    wbest[t] = wbest[t + st];
                    widx[t] = widx[t + st];
                }
            }
            workgroupBarrier();
        }
        if (t == 0u) {
            let s = widx[0];
            if (s != PAD && wbest[0] > -1.0e38) {
                let bq = (s / CAP) % NP;
                let j = s % CAP;
                let m = atomicLoad(&index_u32[(MEM0 + (wbk[bq] & 127u) * CAP + j) & 0x7FFFFFu]);
                if (m != 0u) {
                    cands[q * 64u + rd] = m - 1u;
                }
                wscore[s] = NONE;
            }
        }
        workgroupBarrier();
    }
}
