// passes 1

struct Cfg {
    seed_slot: u32,
    stage: u32,
    arrived_begin: u32,
    arrived_end: u32,
    n_queries: u32,
    pass_index: u32,
    n_passes: u32,
    c_max: u32,
};

@group(0) @binding(0) var<storage, read> keys: array<f32>;
@group(0) @binding(1) var<storage, read> queries: array<f32>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const DIM: u32 = 2048u;
const PAD: u32 = 0xFFFFFFFFu;
const NB: u32 = 40u;
const CELLS: u32 = 1024u;
const CAP: u32 = 128u;
const BASE: u32 = 4096u;
const PCAP: u32 = 24u;
const MAXC: u32 = 480u;

var<workgroup> wsum: array<f32, 2560>;
var<workgroup> wproj: array<f32, 40>;
var<workgroup> wids: array<u32, 480>;
var<workgroup> wsc: array<f32, 480>;
var<workgroup> wcnt: atomic<u32>;

fn mix(x: u32) -> u32 {
    var h = x * 747796405u + 2891336453u;
    h = ((h >> ((h >> 28u) + 4u)) ^ h) * 277803737u;
    return (h >> 22u) ^ h;
}

fn accum(acc: ptr<function, array<f32, 40>>, x: f32, d: u32) {
    let h0 = mix(d * 2u + 1u);
    let h1 = mix(d * 2u + 8193u);
    for (var b = 0u; b < 32u; b = b + 1u) {
        let s = select(-x, x, ((h0 >> b) & 1u) == 1u);
        (*acc)[b] = (*acc)[b] + s;
    }
    for (var b = 0u; b < 8u; b = b + 1u) {
        let s = select(-x, x, ((h1 >> b) & 1u) == 1u);
        (*acc)[32u + b] = (*acc)[32u + b] + s;
    }
}

fn reduce_proj(acc: ptr<function, array<f32, 40>>, t: u32) {
    for (var b = 0u; b < NB; b = b + 1u) {
        wsum[b * 64u + t] = (*acc)[b];
    }
    workgroupBarrier();
    if (t < NB) {
        var s = 0.0;
        for (var i = 0u; i < 64u; i = i + 1u) {
            s = s + wsum[t * 64u + i];
        }
        wproj[t] = s;
    }
    workgroupBarrier();
}

@compute @workgroup_size(64)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = (cfg.arrived_begin + wid.x) & 0x7FFFFu;
    var acc: array<f32, 40>;
    for (var b = 0u; b < NB; b = b + 1u) {
        acc[b] = 0.0;
    }
    for (var i = 0u; i < 32u; i = i + 1u) {
        let d = i * 64u + t;
        accum(&acc, keys[row * DIM + d], d);
    }
    reduce_proj(&acc, t);
    if (t < 4u) {
        var code = 0u;
        for (var k = 0u; k < 10u; k = k + 1u) {
            if (wproj[t * 10u + k] > 0.0) {
                code = code | (1u << k);
            }
        }
        let cell = t * CELLS + code;
        let slot = atomicAdd(&index_u32[cell & 4095u], 1u);
        if (slot < CAP) {
            let pos = BASE + ((cell & 4095u) * CAP) + slot;
            atomicStore(&index_u32[pos & 0x7FFFFFu], row + 1u);
        }
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    if (t == 0u) {
        atomicStore(&wcnt, 0u);
    }
    var acc: array<f32, 40>;
    for (var b = 0u; b < NB; b = b + 1u) {
        acc[b] = 0.0;
    }
    let qb = (q & 0xFFFFu) * DIM;
    for (var i = 0u; i < 32u; i = i + 1u) {
        let d = i * 64u + t;
        accum(&acc, queries[qb + d], d);
    }
    reduce_proj(&acc, t);
    if (t < 20u) {
        let table = t / 5u;
        let f = t % 5u;
        var code = 0u;
        for (var k = 0u; k < 10u; k = k + 1u) {
            if (wproj[table * 10u + k] > 0.0) {
                code = code | (1u << k);
            }
        }
        if (f > 0u) {
            for (var i = 0u; i < 10u; i = i + 1u) {
                let ai = abs(wproj[table * 10u + i]);
                var rank = 0u;
                for (var j = 0u; j < 10u; j = j + 1u) {
                    let aj = abs(wproj[table * 10u + j]);
                    if (aj < ai || (aj == ai && j < i)) {
                        rank = rank + 1u;
                    }
                }
                if (rank == f - 1u) {
                    code = code ^ (1u << i);
                }
            }
        }
        let cell = (table * CELLS + code) & 4095u;
        let n = min(atomicLoad(&index_u32[cell]), PCAP);
        for (var i = 0u; i < PCAP; i = i + 1u) {
            if (i < n) {
                let v = atomicLoad(&index_u32[(BASE + cell * CAP + i) & 0x7FFFFFu]);
                if (v != 0u && v - 1u < cfg.arrived_end) {
                    let slot = atomicAdd(&wcnt, 1u);
                    if (slot < MAXC) {
                        wids[slot] = v - 1u;
                    }
                }
            }
        }
    }
    workgroupBarrier();
    let n = min(atomicLoad(&wcnt), MAXC);
    // dedupe
    var dup: array<u32, 8>;
    for (var k = 0u; k < 8u; k = k + 1u) {
        let i = k * 64u + t;
        var dflag = 0u;
        if (i < n) {
            let id = wids[i];
            for (var j = 0u; j < MAXC; j = j + 1u) {
                if (j < i && wids[j] == id) {
                    dflag = 1u;
                }
            }
        }
        dup[k] = dflag;
    }
    workgroupBarrier();
    // score
    for (var k = 0u; k < 8u; k = k + 1u) {
        let i = k * 64u + t;
        if (i < n) {
            if (dup[k] == 1u) {
                wids[i] = PAD;
                wsc[i] = -1.0e30;
            } else {
                let r = wids[i] & 0x7FFFFu;
                var s = 0.0;
                var kn = 0.0;
                for (var d = 0u; d < DIM; d = d + 1u) {
                    let kv = keys[r * DIM + d];
                    s = s + kv * queries[qb + d];
                    kn = kn + kv * kv;
                }
                var sc = -1.0e30;
                if (kn > 0.0) {
                    sc = s * inverseSqrt(kn);
                }
                wsc[i] = sc;
            }
        }
    }
    workgroupBarrier();
    for (var k = 0u; k < 8u; k = k + 1u) {
        let i = k * 64u + t;
        if (i < n && wids[i] != PAD) {
            let si = wsc[i];
            var rank = 0u;
            for (var j = 0u; j < MAXC; j = j + 1u) {
                if (j < n && wids[j] != PAD) {
                    let sj = wsc[j];
                    if (sj > si || (sj == si && j < i)) {
                        rank = rank + 1u;
                    }
                }
            }
            if (rank < 64u && q < cfg.n_queries) {
                cands[q * 64u + rank] = wids[i];
            }
        }
    }
}
