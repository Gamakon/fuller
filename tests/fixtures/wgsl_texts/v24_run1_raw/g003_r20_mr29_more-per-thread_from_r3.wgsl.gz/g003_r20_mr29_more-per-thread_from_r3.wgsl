// passes 1
struct Cfg { seed_slot: u32, stage: u32, arrived_begin: u32, arrived_end: u32, n_queries: u32, pass_index: u32, n_passes: u32, c_max: u32, };
@group(0) @binding(0) var<storage, read> keys: array<vec4<f32>>;
@group(0) @binding(1) var<storage, read> queries: array<vec4<f32>>;
@group(0) @binding(2) var<storage, read_write> index_u32: array<u32>;
@group(0) @binding(3) var<storage, read_write> index_f32: array<f32>;
@group(0) @binding(4) var<storage, read_write> cands: array<u32>;
@group(0) @binding(5) var<uniform> cfg: Cfg;

const PAD: u32 = 0xFFFFFFFFu;

var<workgroup> sig: array<atomic<u32>, 2>;
var<workgroup> hist: array<atomic<u32>, 65>;
var<workgroup> cnt: atomic<u32>;
var<workgroup> wT: u32;

fn sgn(idx: u32) -> f32 {
    var x = idx * 0x9E3779B1u;
    x = x ^ (x >> 15u);
    x = x * 0x85EBCA6Bu;
    x = x ^ (x >> 13u);
    x = x * 0xC2B2AE35u;
    x = x ^ (x >> 16u);
    return select(-1.0, 1.0, (x & 1u) == 1u);
}

// Each thread computes two output bits: b and b + 32.
fn proj2(base: u32, b: u32, isq: u32) -> vec2<f32> {
    var s0 = 0.0;
    var s1 = 0.0;
    for (var d = 0u; d < 512u; d = d + 1u) {
        var v: vec4<f32>;
        if (isq == 1u) {
            v = queries[(base + d) & 0x3FFFFFu];
        } else {
            v = keys[(base + d) & 0x3FFFFFFu];
        }
        let i0 = d * 4u * 64u + b;
        let w0 = vec4<f32>(sgn(i0), sgn(i0 + 64u), sgn(i0 + 128u), sgn(i0 + 192u));
        let i1 = i0 + 32u;
        let w1 = vec4<f32>(sgn(i1), sgn(i1 + 64u), sgn(i1 + 128u), sgn(i1 + 192u));
        s0 = s0 + dot(v, w0);
        s1 = s1 + dot(v, w1);
    }
    return vec2<f32>(s0, s1);
}

@compute @workgroup_size(32)
fn ingest(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let row = cfg.arrived_begin + wid.x;
    if (t == 0u) {
        atomicStore(&sig[0], 0u);
        atomicStore(&sig[1], 0u);
    }
    workgroupBarrier();
    if (row < cfg.arrived_end) {
        let s = proj2(row * 512u, t, 0u);
        if (s.x > 0.0) { atomicOr(&sig[0], 1u << t); }
        if (s.y > 0.0) { atomicOr(&sig[1], 1u << t); }
    }
    workgroupBarrier();
    if (t == 0u && row < cfg.arrived_end) {
        let o = (row & 0x7FFFFu) * 2u;
        index_u32[o] = atomicLoad(&sig[0]);
        index_u32[o + 1u] = atomicLoad(&sig[1]);
    }
}

@compute @workgroup_size(64)
fn search(@builtin(local_invocation_id) lid: vec3<u32>, @builtin(workgroup_id) wid: vec3<u32>) {
    let t = lid.x;
    let q = wid.x;
    let n = cfg.arrived_end;
    if (t == 0u) {
        atomicStore(&sig[0], 0u);
        atomicStore(&sig[1], 0u);
        atomicStore(&cnt, 0u);
        wT = 0u;
    }
    atomicStore(&hist[t], 0u);
    if (t == 0u) { atomicStore(&hist[64], 0u); }
    workgroupBarrier();
    if (t < 32u && q < cfg.n_queries) {
        let s = proj2(q * 512u, t, 1u);
        if (s.x > 0.0) { atomicOr(&sig[0], 1u << t); }
        if (s.y > 0.0) { atomicOr(&sig[1], 1u << t); }
    }
    workgroupBarrier();
    let qa = atomicLoad(&sig[0]);
    let qb = atomicLoad(&sig[1]);
    if (q < cfg.n_queries) {
        for (var i = 0u; i < n; i += 64u) {
            let j = i + t;
            if (j < n) {
                let o = (j & 0x7FFFFu) * 2u;
                let d = countOneBits(index_u32[o] ^ qa) + countOneBits(index_u32[o + 1u] ^ qb);
                atomicAdd(&hist[d], 1u);
            }
        }
    }
    workgroupBarrier();
    if (t == 0u) {
        var c = 0u;
        var th = 64u;
        for (var d = 0u; d < 65u; d = d + 1u) {
            c = c + atomicLoad(&hist[d]);
            if (c >= 64u) {
                th = d;
                break;
            }
        }
        wT = th;
    }
    workgroupBarrier();
    let T = wT;
    if (q < cfg.n_queries) {
        for (var i = 0u; i < n; i += 64u) {
            let j = i + t;
            if (j < n) {
                let o = (j & 0x7FFFFu) * 2u;
                let d = countOneBits(index_u32[o] ^ qa) + countOneBits(index_u32[o + 1u] ^ qb);
                if (d < T) {
                    let slot = atomicAdd(&cnt, 1u);
                    if (slot < 64u) {
                        cands[(q * 64u + slot) & 0x3FFFFFu] = j;
                    }
                }
            }
        }
    }
    workgroupBarrier();
    if (q < cfg.n_queries) {
        for (var i = 0u; i < n; i += 64u) {
            let j = i + t;
            if (j < n) {
                let o = (j & 0x7FFFFu) * 2u;
                let d = countOneBits(index_u32[o] ^ qa) + countOneBits(index_u32[o + 1u] ^ qb);
                if (d == T) {
                    let slot = atomicAdd(&cnt, 1u);
                    if (slot < 64u) {
                        cands[(q * 64u + slot) & 0x3FFFFFu] = j;
                    }
                }
            }
        }
    }
}
